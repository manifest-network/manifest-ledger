package helpers

import (
	"context"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/strangelove-ventures/interchaintest/v8/chain/cosmos"
	"github.com/strangelove-ventures/interchaintest/v8/ibc"

	sdk "github.com/cosmos/cosmos-sdk/types"

	billingtypes "github.com/manifest-network/manifest-ledger/x/billing/types"
)

const (
	billingModule     = "billing"
	closeLeaseCommand = "close-lease"
)

// LeaseItemJSON is a JSON-compatible version of LeaseItem.
// Quantity is a string in CLI JSON output.
type LeaseItemJSON struct {
	SkuUUID      string   `json:"sku_uuid,omitempty"`
	Quantity     string   `json:"quantity,omitempty"`
	LockedPrice  sdk.Coin `json:"locked_price"`
	ServiceName  string   `json:"service_name,omitempty"`
	CustomDomain string   `json:"custom_domain,omitempty"`
}

// LeaseReservationJSON is the JSON representation of a consumable v4 lease
// reservation. Its presence distinguishes initialized v4 state from v2/v3
// aggregate-only state.
type LeaseReservationJSON struct {
	RemainingAmounts sdk.Coins `json:"remaining_amounts"`
}

// LeaseJSON is a JSON-compatible version of Lease.
// State is output as a string by the CLI (e.g., "LEASE_STATE_ACTIVE"),
// not as the numeric enum value that the proto type expects.
type LeaseJSON struct {
	UUID                       string                `json:"uuid,omitempty"`
	Tenant                     string                `json:"tenant,omitempty"`
	ProviderUUID               string                `json:"provider_uuid,omitempty"`
	Items                      []LeaseItemJSON       `json:"items"`
	State                      string                `json:"state,omitempty"`
	CreatedAt                  time.Time             `json:"created_at"`
	ClosedAt                   *time.Time            `json:"closed_at,omitempty"`
	LastSettledAt              time.Time             `json:"last_settled_at"`
	AcknowledgedAt             *time.Time            `json:"acknowledged_at,omitempty"`
	RejectedAt                 *time.Time            `json:"rejected_at,omitempty"`
	RejectionReason            string                `json:"rejection_reason,omitempty"`
	ExpiredAt                  *time.Time            `json:"expired_at,omitempty"`
	ClosureReason              string                `json:"closure_reason,omitempty"`
	MetaHash                   []byte                `json:"meta_hash,omitempty"`
	MinLeaseDurationAtCreation string                `json:"min_lease_duration_at_creation,omitempty"`
	Reservation                *LeaseReservationJSON `json:"reservation,omitempty"`
}

// GetState returns the LeaseState enum value from the string state.
func (l *LeaseJSON) GetState() billingtypes.LeaseState {
	switch l.State {
	case "LEASE_STATE_PENDING":
		return billingtypes.LEASE_STATE_PENDING
	case "LEASE_STATE_ACTIVE":
		return billingtypes.LEASE_STATE_ACTIVE
	case "LEASE_STATE_CLOSED":
		return billingtypes.LEASE_STATE_CLOSED
	case "LEASE_STATE_REJECTED":
		return billingtypes.LEASE_STATE_REJECTED
	case "LEASE_STATE_EXPIRED":
		return billingtypes.LEASE_STATE_EXPIRED
	default:
		return billingtypes.LEASE_STATE_UNSPECIFIED
	}
}

// GetClosureReason returns the closure reason for the lease.
func (l *LeaseJSON) GetClosureReason() string {
	return l.ClosureReason
}

// Billing transaction helpers

// BillingFundCredit funds a tenant's credit account.
func BillingFundCredit(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, tenant, amount string, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{"tx", billingModule, "fund-credit", tenant, amount}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingCreateLease creates a new lease with the specified SKU items.
// items should be in the format "sku_uuid:quantity[:service_name]" (e.g., "uuid1:2", "uuid2:1:web")
func BillingCreateLease(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, items []string, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{"tx", billingModule, "create-lease"}
	cmd = append(cmd, items...)
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingCreateLeaseWithMetaHash creates a new lease with the specified SKU items and meta_hash.
// items should be in the format "sku_uuid:quantity[:service_name]" (e.g., "uuid1:2", "uuid2:1:web")
// metaHash should be a hex-encoded string (e.g., "a1b2c3d4...")
func BillingCreateLeaseWithMetaHash(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, items []string, metaHash string, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{"tx", billingModule, "create-lease"}
	cmd = append(cmd, items...)
	if metaHash != "" {
		cmd = append(cmd, "--meta-hash", metaHash)
	}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingCreateLeaseForTenant creates a new lease on behalf of a tenant (authority only).
// items should be in the format "sku_uuid:quantity[:service_name]" (e.g., "uuid1:2", "uuid2:1:web")
func BillingCreateLeaseForTenant(ctx context.Context, chain *cosmos.CosmosChain, authority ibc.Wallet, tenant string, items []string, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{"tx", billingModule, "create-lease-for-tenant", tenant}
	cmd = append(cmd, items...)
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, authority.KeyName(), flags...))
}

// BillingCloseLease closes an active lease.
func BillingCloseLease(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, leaseID string, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{"tx", billingModule, closeLeaseCommand, leaseID}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingCloseLeaseWithReason closes an active lease with a closure reason.
func BillingCloseLeaseWithReason(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, leaseID, reason string, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{"tx", billingModule, closeLeaseCommand, leaseID}
	if reason != "" {
		cmd = append(cmd, "--reason", reason)
	}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingCloseLeases closes multiple active leases atomically.
func BillingCloseLeases(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, leaseUUIDs []string, flags ...string) (sdk.TxResponse, error) {
	cmd := append([]string{"tx", billingModule, closeLeaseCommand}, leaseUUIDs...)
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingCloseLeasesWithReason closes multiple active leases atomically with a closure reason.
func BillingCloseLeasesWithReason(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, leaseUUIDs []string, reason string, flags ...string) (sdk.TxResponse, error) {
	cmd := append([]string{"tx", billingModule, closeLeaseCommand}, leaseUUIDs...)
	if reason != "" {
		cmd = append(cmd, "--reason", reason)
	}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingAcknowledgeLease acknowledges a pending lease (provider or module authority).
func BillingAcknowledgeLease(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, leaseUUID string, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{"tx", billingModule, "acknowledge-lease", leaseUUID}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingAcknowledgeLeases acknowledges multiple pending leases atomically.
// The provider or module authority may submit the acknowledgement.
func BillingAcknowledgeLeases(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, leaseUUIDs []string, flags ...string) (sdk.TxResponse, error) {
	cmd := append([]string{"tx", billingModule, "acknowledge-lease"}, leaseUUIDs...)
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingRejectLease rejects a pending lease (provider only).
func BillingRejectLease(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, leaseUUID string, reason string, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{"tx", billingModule, "reject-lease", leaseUUID}
	if reason != "" {
		cmd = append(cmd, "--reason", reason)
	}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingRejectLeases rejects multiple pending leases atomically (provider only).
func BillingRejectLeases(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, leaseUUIDs []string, reason string, flags ...string) (sdk.TxResponse, error) {
	cmd := append([]string{"tx", billingModule, "reject-lease"}, leaseUUIDs...)
	if reason != "" {
		cmd = append(cmd, "--reason", reason)
	}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingCancelLease cancels a pending lease (tenant only).
func BillingCancelLease(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, leaseUUID string, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{"tx", billingModule, "cancel-lease", leaseUUID}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingSetItemCustomDomain sets or clears the custom_domain on a
// specific LeaseItem. For a 1-item legacy lease, pass "" for serviceName.
// An empty domain clears the field; sender must be tenant, authority, or
// in params.allowed_list.
func BillingSetItemCustomDomain(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, leaseUUID, serviceName, domain string, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{"tx", billingModule, "set-item-custom-domain", leaseUUID, serviceName, domain}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingCreateAndAcknowledgeLease creates a new lease and immediately acknowledges it.
// This is a convenience function for tests where an active lease is needed.
// Returns the lease UUID and any error.
func BillingCreateAndAcknowledgeLease(ctx context.Context, chain *cosmos.CosmosChain, tenant ibc.Wallet, provider ibc.Wallet, items []string, flags ...string) (string, error) {
	// Create the lease
	res, err := BillingCreateLease(ctx, chain, tenant, items, flags...)
	if err != nil {
		return "", fmt.Errorf("failed to create lease: %w", err)
	}

	txRes, err := chain.GetTransaction(res.TxHash)
	if err != nil {
		return "", fmt.Errorf("failed to get create tx: %w", err)
	}
	if txRes.Code != 0 {
		return "", fmt.Errorf("lease creation failed: %s", txRes.RawLog)
	}

	// Get the lease UUID from the transaction
	leaseUUID, err := GetLeaseIDFromTxHash(ctx, chain, res.TxHash)
	if err != nil {
		return "", fmt.Errorf("failed to get lease UUID: %w", err)
	}

	// Acknowledge the lease
	ackRes, err := BillingAcknowledgeLease(ctx, chain, provider, leaseUUID)
	if err != nil {
		return leaseUUID, fmt.Errorf("failed to acknowledge lease: %w", err)
	}

	ackTxRes, err := chain.GetTransaction(ackRes.TxHash)
	if err != nil {
		return leaseUUID, fmt.Errorf("failed to get ack tx: %w", err)
	}
	if ackTxRes.Code != 0 {
		return leaseUUID, fmt.Errorf("lease acknowledgement failed: %s", ackTxRes.RawLog)
	}

	return leaseUUID, nil
}

// BillingWithdraw withdraws accrued funds from a specific lease.
func BillingWithdraw(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, leaseID string, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{"tx", billingModule, "withdraw", leaseID}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingWithdrawByProvider withdraws all accrued funds from all leases for a provider.
// Uses the --provider flag for provider-wide withdrawal mode.
// limit=0 uses the default limit (50).
func BillingWithdrawByProvider(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, providerUUID string, limit uint64, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{"tx", billingModule, "withdraw", "--provider", providerUUID}
	if limit > 0 {
		cmd = append(cmd, limitFlag, strconv.FormatUint(limit, 10))
	}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// BillingUpdateParams updates the billing module parameters using the v1
// field set only. ReservedDomainSuffixes is left untouched: the CLI's
// preserve-on-omit semantic keeps the existing on-chain value when the flag
// is absent. Callers that want to set or clear ReservedDomainSuffixes should
// use BillingUpdateParamsFull directly.
func BillingUpdateParams(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, maxLeasesPerTenant uint64, maxItemsPerLease uint64, minLeaseDuration uint64, maxPendingLeasesPerTenant uint64, pendingTimeout uint64, allowedList []string, flags ...string) (sdk.TxResponse, error) {
	return BillingUpdateParamsFull(ctx, chain, user, maxLeasesPerTenant, maxItemsPerLease, minLeaseDuration, maxPendingLeasesPerTenant, pendingTimeout, allowedList, nil, flags...)
}

// BillingUpdateParamsFull updates the billing module parameters including the
// reserved_domain_suffixes list.
//
// Slice arguments use Go nil-vs-empty distinction to match the CLI's
// preserve-on-omit semantic:
//   - nil slice: omit the corresponding flag → CLI preserves the existing on-chain value.
//   - non-nil slice (including length zero): pass the flag with the joined value
//     → CLI sets the value (an empty []string{} explicitly clears).
func BillingUpdateParamsFull(ctx context.Context, chain *cosmos.CosmosChain, user ibc.Wallet, maxLeasesPerTenant uint64, maxItemsPerLease uint64, minLeaseDuration uint64, maxPendingLeasesPerTenant uint64, pendingTimeout uint64, allowedList []string, reservedDomainSuffixes []string, flags ...string) (sdk.TxResponse, error) {
	cmd := []string{
		"tx", billingModule, "update-params",
		strconv.FormatUint(maxLeasesPerTenant, 10),
		strconv.FormatUint(maxItemsPerLease, 10),
		strconv.FormatUint(minLeaseDuration, 10),
		strconv.FormatUint(maxPendingLeasesPerTenant, 10),
		strconv.FormatUint(pendingTimeout, 10),
	}
	if allowedList != nil {
		cmd = append(cmd, "--allowed-list", strings.Join(allowedList, ","))
	}
	if reservedDomainSuffixes != nil {
		cmd = append(cmd, "--reserved-domain-suffixes", strings.Join(reservedDomainSuffixes, ","))
	}
	return ExecuteTransaction(ctx, chain, TxCommandBuilder(ctx, chain, cmd, user.KeyName(), flags...))
}

// Billing query helpers

// LeasesResponseJSON wraps lease queries that include pagination.
// Uses LeaseJSON because CLI outputs LeaseState as a string, not numeric enum.
type LeasesResponseJSON struct {
	Leases     []LeaseJSON       `json:"leases"`
	Pagination *PageResponseJSON `json:"pagination,omitempty"`
}

// LeaseResponseJSON wraps single lease queries.
// Uses LeaseJSON because CLI outputs LeaseState as a string, not numeric enum.
type LeaseResponseJSON struct {
	Lease LeaseJSON `json:"lease"`
}

// LeaseByCustomDomainResponseJSON wraps the LeaseByCustomDomain query response,
// which includes the service_name of the matching item alongside the lease.
type LeaseByCustomDomainResponseJSON struct {
	Lease       LeaseJSON `json:"lease"`
	ServiceName string    `json:"service_name,omitempty"`
}

// BillingQueryParams queries the billing module parameters.
func BillingQueryParams(ctx context.Context, chain *cosmos.CosmosChain) (*billingtypes.QueryParamsResponse, error) {
	var res billingtypes.QueryParamsResponse
	cmd := []string{queryCommand, billingModule, "params"}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// BillingQueryLease queries a lease by UUID.
func BillingQueryLease(ctx context.Context, chain *cosmos.CosmosChain, leaseUUID string) (*LeaseResponseJSON, error) {
	var res LeaseResponseJSON
	cmd := []string{queryCommand, billingModule, "lease", leaseUUID}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// BillingQueryLeaseByCustomDomain queries the lease and matching service_name
// for a given custom_domain.
func BillingQueryLeaseByCustomDomain(ctx context.Context, chain *cosmos.CosmosChain, domain string) (*LeaseByCustomDomainResponseJSON, error) {
	var res LeaseByCustomDomainResponseJSON
	cmd := []string{queryCommand, billingModule, "lease-by-domain", domain}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// BillingQueryLeases queries all leases with optional state filter.
// state can be "", "pending", "active", "closed", "rejected", or "expired".
// Empty string returns all leases.
func BillingQueryLeases(ctx context.Context, chain *cosmos.CosmosChain, state string) (*LeasesResponseJSON, error) {
	var res LeasesResponseJSON
	cmd := []string{queryCommand, billingModule, "leases"}
	if state != "" {
		cmd = append(cmd, "--state", state)
	}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// BillingQueryLeasesByTenant queries leases by tenant address with optional state filter.
func BillingQueryLeasesByTenant(ctx context.Context, chain *cosmos.CosmosChain, tenant, state string) (*LeasesResponseJSON, error) {
	var res LeasesResponseJSON
	cmd := []string{queryCommand, billingModule, "leases-by-tenant", tenant}
	if state != "" {
		cmd = append(cmd, "--state", state)
	}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// BillingQueryLeasesByProvider queries leases by provider UUID with optional state filter.
func BillingQueryLeasesByProvider(ctx context.Context, chain *cosmos.CosmosChain, providerUUID, state string) (*LeasesResponseJSON, error) {
	var res LeasesResponseJSON
	cmd := []string{queryCommand, billingModule, "leases-by-provider", providerUUID}
	if state != "" {
		cmd = append(cmd, "--state", state)
	}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// GetNextKeyString returns the base64-encoded next key for CLI pagination.
func (r *LeasesResponseJSON) GetNextKeyString() string {
	if r.Pagination != nil {
		return r.Pagination.NextKey
	}
	return ""
}

// BillingQueryLeasesPaginated queries leases with pagination.
func BillingQueryLeasesPaginated(ctx context.Context, chain *cosmos.CosmosChain, state string, limit uint64, key string) (*LeasesResponseJSON, string, error) {
	var res LeasesResponseJSON
	cmd := []string{queryCommand, billingModule, "leases", limitFlag, strconv.FormatUint(limit, 10)}
	if state != "" {
		cmd = append(cmd, "--state", state)
	}
	if key != "" {
		cmd = append(cmd, "--page-key", key)
	}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, "", err
	}
	return &res, res.GetNextKeyString(), nil
}

// BillingQueryLeasesByTenantPaginated queries leases by tenant with pagination.
func BillingQueryLeasesByTenantPaginated(ctx context.Context, chain *cosmos.CosmosChain, tenant, state string, limit uint64, key string) (*LeasesResponseJSON, string, error) {
	var res LeasesResponseJSON
	cmd := []string{queryCommand, billingModule, "leases-by-tenant", tenant, limitFlag, strconv.FormatUint(limit, 10)}
	if state != "" {
		cmd = append(cmd, "--state", state)
	}
	if key != "" {
		cmd = append(cmd, "--page-key", key)
	}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, "", err
	}
	return &res, res.GetNextKeyString(), nil
}

// BillingQueryLeasesByProviderPaginated queries leases by provider with pagination.
func BillingQueryLeasesByProviderPaginated(ctx context.Context, chain *cosmos.CosmosChain, providerUUID, state string, limit uint64, key string) (*LeasesResponseJSON, string, error) {
	var res LeasesResponseJSON
	cmd := []string{queryCommand, billingModule, "leases-by-provider", providerUUID, limitFlag, strconv.FormatUint(limit, 10)}
	if state != "" {
		cmd = append(cmd, "--state", state)
	}
	if key != "" {
		cmd = append(cmd, "--page-key", key)
	}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, "", err
	}
	return &res, res.GetNextKeyString(), nil
}

// CreditAccountResponseJSON wraps a credit-account query. CLI protobuf JSON
// renders pagination.total as a quoted uint64, which cannot be decoded into the
// SDK's query.PageResponse by encoding/json.
type CreditAccountResponseJSON struct {
	CreditAccount     billingtypes.CreditAccount `json:"credit_account"`
	Balances          sdk.Coins                  `json:"balances"`
	AvailableBalances sdk.Coins                  `json:"available_balances"`
	Pagination        *PageResponseJSON          `json:"pagination,omitempty"`
}

// BillingQueryCreditAccount queries a tenant's credit account.
func BillingQueryCreditAccount(ctx context.Context, chain *cosmos.CosmosChain, tenant string) (*CreditAccountResponseJSON, error) {
	var res CreditAccountResponseJSON
	cmd := []string{queryCommand, billingModule, "credit-account", tenant}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// BillingQueryCreditAddress derives the credit address for a tenant.
func BillingQueryCreditAddress(ctx context.Context, chain *cosmos.CosmosChain, tenant string) (*billingtypes.QueryCreditAddressResponse, error) {
	var res billingtypes.QueryCreditAddressResponse
	cmd := []string{queryCommand, billingModule, "credit-address", tenant}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// BillingQueryWithdrawable queries the withdrawable amount for a lease.
func BillingQueryWithdrawable(ctx context.Context, chain *cosmos.CosmosChain, leaseUUID string) (*billingtypes.QueryWithdrawableAmountResponse, error) {
	var res billingtypes.QueryWithdrawableAmountResponse
	cmd := []string{queryCommand, billingModule, "withdrawable", leaseUUID}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// ProviderWithdrawableResponseJSON wraps the provider-withdrawable query. It now
// returns a pagination block whose uint64 `total` is emitted as a JSON string by
// proto3 JSON; the SDK's query.PageResponse (no `,string` tag) cannot unmarshal
// that via encoding/json, so we use PageResponseJSON here (same reason the leases
// and credit-account paginated helpers do).
type ProviderWithdrawableResponseJSON struct {
	Amounts          sdk.Coins         `json:"amounts"`
	LeaseCount       uint64            `json:"lease_count,omitempty,string"`
	Pagination       *PageResponseJSON `json:"pagination,omitempty"`
	FailedLeaseUUIDs []string          `json:"failed_lease_uuids,omitempty"`
}

// BillingQueryProviderWithdrawable queries the total withdrawable amount for a provider.
func BillingQueryProviderWithdrawable(ctx context.Context, chain *cosmos.CosmosChain, providerUUID string) (*ProviderWithdrawableResponseJSON, error) {
	var res ProviderWithdrawableResponseJSON
	cmd := []string{queryCommand, billingModule, "provider-withdrawable", providerUUID}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// CreditAccountsResponseJSON wraps credit accounts query that includes pagination.
type CreditAccountsResponseJSON struct {
	CreditAccounts []billingtypes.CreditAccount `json:"credit_accounts"`
	Pagination     *PageResponseJSON            `json:"pagination,omitempty"`
}

// BillingQueryCreditAccounts queries all credit accounts with pagination.
func BillingQueryCreditAccounts(ctx context.Context, chain *cosmos.CosmosChain) (*CreditAccountsResponseJSON, error) {
	var res CreditAccountsResponseJSON
	cmd := []string{queryCommand, billingModule, "credit-accounts"}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// BillingQueryCreditAccountsPaginated queries all credit accounts with pagination.
func BillingQueryCreditAccountsPaginated(ctx context.Context, chain *cosmos.CosmosChain, limit uint64, key string) (*CreditAccountsResponseJSON, string, error) {
	var res CreditAccountsResponseJSON
	cmd := []string{queryCommand, billingModule, "credit-accounts", limitFlag, strconv.FormatUint(limit, 10)}
	if key != "" {
		cmd = append(cmd, "--page-key", key)
	}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, "", err
	}
	nextKey := ""
	if res.Pagination != nil {
		nextKey = res.Pagination.NextKey
	}
	return &res, nextKey, nil
}

// BillingQueryLeasesBySKU queries leases by SKU UUID with optional state filter.
func BillingQueryLeasesBySKU(ctx context.Context, chain *cosmos.CosmosChain, skuUUID, state string) (*LeasesResponseJSON, error) {
	var res LeasesResponseJSON
	cmd := []string{queryCommand, billingModule, "leases-by-sku", skuUUID}
	if state != "" {
		cmd = append(cmd, "--state", state)
	}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// BillingQueryLeasesBySKUPaginated queries leases by SKU UUID with pagination.
func BillingQueryLeasesBySKUPaginated(ctx context.Context, chain *cosmos.CosmosChain, skuUUID, state string, limit uint64, key string) (*LeasesResponseJSON, string, error) {
	var res LeasesResponseJSON
	cmd := []string{queryCommand, billingModule, "leases-by-sku", skuUUID, limitFlag, strconv.FormatUint(limit, 10)}
	if state != "" {
		cmd = append(cmd, "--state", state)
	}
	if key != "" {
		cmd = append(cmd, "--page-key", key)
	}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, "", err
	}
	return &res, res.GetNextKeyString(), nil
}

// BillingQueryCreditEstimate queries the credit estimate for a tenant.
func BillingQueryCreditEstimate(ctx context.Context, chain *cosmos.CosmosChain, tenant string) (*billingtypes.QueryCreditEstimateResponse, error) {
	var res billingtypes.QueryCreditEstimateResponse
	cmd := []string{queryCommand, billingModule, "credit-estimate", tenant}
	if err := executeQueryWithError(ctx, chain, cmd, &res); err != nil {
		return nil, err
	}
	return &res, nil
}

// Event extraction helpers

// GetLeaseIDFromTxHash queries a transaction and extracts the lease UUID from it.
func GetLeaseIDFromTxHash(_ context.Context, chain *cosmos.CosmosChain, txHash string) (string, error) {
	txRes, err := chain.GetTransaction(txHash)
	if err != nil {
		return "", err
	}

	if txRes.Code != 0 {
		return "", fmt.Errorf("tx %s failed with code %d: %s", txHash, txRes.Code, txRes.RawLog)
	}

	eventNames := []string{"lease_created", "liftedinit.billing.v1.EventLeaseCreated"}
	for _, event := range txRes.Events {
		for _, eventName := range eventNames {
			if event.Type == eventName {
				for _, attr := range event.Attributes {
					if attr.Key == "lease_uuid" {
						return attr.Value, nil
					}
				}
			}
		}
	}

	eventTypes := make([]string, 0, len(txRes.Events))
	for _, event := range txRes.Events {
		eventTypes = append(eventTypes, event.Type)
	}
	return "", fmt.Errorf("lease_uuid not found in tx %s events (found events: %v)", txHash, eventTypes)
}
