package keeper_test

import (
	"fmt"
	"strings"
	"testing"

	"github.com/stretchr/testify/require"

	"cosmossdk.io/collections"
	"cosmossdk.io/collections/indexes"
	sdkmath "cosmossdk.io/math"

	sdk "github.com/cosmos/cosmos-sdk/types"

	"github.com/manifest-network/manifest-ledger/x/sku/keeper"
	"github.com/manifest-network/manifest-ledger/x/sku/types"
)

func TestStateInvariant(t *testing.T) {
	f := initFixture(t)
	_, sku := seedInvariantState(t, f)

	message, broken := keeper.StateInvariant(f.App.SKUKeeper)(f.Ctx)
	require.False(t, broken, message)

	sku.ProviderUuid = testProvider2UUID
	require.NoError(t, f.App.SKUKeeper.SetSKU(f.Ctx, sku))
	message, broken = keeper.StateInvariant(f.App.SKUKeeper)(f.Ctx)
	require.True(t, broken)
	require.Contains(t, message, "references non-existent provider")
}

func TestStateInvariantReportsCorruptParamsWithoutPanicking(t *testing.T) {
	f := initFixture(t)
	f.Ctx.KVStore(f.App.GetKey(types.StoreKey)).Set(types.ParamsKey.Bytes(), []byte{0xff})

	message, broken := keeper.StateInvariant(f.App.SKUKeeper)(f.Ctx)
	require.True(t, broken)
	require.Contains(t, message, "failed to export SKU state")
	require.Contains(t, message, "read SKU params")
}

func TestStateInvariantReportsCorruptPrimaryRowWithContext(t *testing.T) {
	tests := []struct {
		name       string
		prefix     collections.Prefix
		primaryKey string
		seedDecoy  func(*testing.T, *testFixture)
		collection string
	}{
		{
			name:       "provider",
			prefix:     types.ProviderKey,
			primaryKey: testProviderUUID,
			collection: "provider",
			seedDecoy: func(t *testing.T, f *testFixture) {
				require.NoError(t, f.App.SKUKeeper.SetProvider(f.Ctx, types.Provider{
					Uuid:          testProvider2UUID,
					Address:       f.TestAccs[2].String(),
					PayoutAddress: f.TestAccs[3].String(),
					Active:        true,
				}))
				require.NoError(t, f.App.SKUKeeper.ProviderSequence.Set(f.Ctx, 2))
			},
		},
		{
			name:       "SKU",
			prefix:     types.SKUKey,
			primaryKey: testSKU2UUID,
			collection: "SKU",
			seedDecoy: func(t *testing.T, f *testFixture) {
				require.NoError(t, f.App.SKUKeeper.SetSKU(f.Ctx, types.SKU{
					Uuid:         testSKU2UUID,
					ProviderUuid: testProviderUUID,
					Name:         "storage",
					Unit:         types.Unit_UNIT_PER_HOUR,
					BasePrice:    sdk.NewInt64Coin("umfx", 3600),
					Active:       true,
				}))
				require.NoError(t, f.App.SKUKeeper.SKUSequence.Set(f.Ctx, 2))
			},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			f := initFixture(t)
			seedInvariantState(t, f)
			test.seedDecoy(t, f)

			key, err := collections.EncodeKeyWithPrefix(
				test.prefix.Bytes(),
				collections.StringKey,
				test.primaryKey,
			)
			require.NoError(t, err)
			f.Ctx.KVStore(f.App.GetKey(types.StoreKey)).Set(key, []byte{0xff})

			message, broken := keeper.StateInvariant(f.App.SKUKeeper)(f.Ctx)
			require.True(t, broken)
			require.Equal(
				t,
				sdk.FormatInvariant(
					types.ModuleName,
					"state",
					fmt.Sprintf(
						"%s collection row %q: decode value: unexpected EOF",
						test.collection,
						test.primaryKey,
					),
				),
				message,
			)
		})
	}
}

func TestStateInvariantValidatesRawStoredParams(t *testing.T) {
	tests := []struct {
		name   string
		params types.Params
		want   string
	}{
		{
			name: "duplicate decoded identity",
			params: func() types.Params {
				address := sdk.AccAddress([]byte("duplicate-identity__")).String()
				return types.Params{AllowedList: []string{address, strings.ToUpper(address)}}
			}(),
			want: "duplicate address in allowed list",
		},
		{
			name: "over cap equivalent aliases",
			params: func() types.Params {
				address := sdk.AccAddress([]byte("over-cap-identity___")).String()
				allowed := make([]string, types.MaxAllowedListEntries+1)
				for i := range allowed {
					allowed[i] = address
				}
				return types.Params{AllowedList: allowed}
			}(),
			want: "allowed list has 101 entries, maximum allowed is 100",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			f := initFixture(t)
			require.NoError(t, f.App.SKUKeeper.SetParams(f.Ctx, test.params))

			message, broken := keeper.StateInvariant(f.App.SKUKeeper)(f.Ctx)
			require.True(t, broken)
			require.Contains(t, message, "invalid stored SKU params")
			require.Contains(t, message, test.want)
		})
	}
}

func TestStateInvariant_DetectsSecondaryIndexCorruption(t *testing.T) {
	tests := []struct {
		name     string
		corrupt  func(*testing.T, *testFixture, types.Provider, types.SKU)
		contains string
	}{
		{
			name: "missing provider address row",
			corrupt: func(t *testing.T, f *testFixture, provider types.Provider, _ types.SKU) {
				require.NoError(t, f.App.SKUKeeper.Providers.Indexes.Address.Unreference(
					f.Ctx,
					provider.Uuid,
					func() (types.Provider, error) { return provider, nil },
				))
			},
			contains: "provider address index is missing derived key",
		},
		{
			name: "missing provider active row",
			corrupt: func(t *testing.T, f *testFixture, provider types.Provider, _ types.SKU) {
				require.NoError(t, f.App.SKUKeeper.Providers.Indexes.Active.Unreference(
					f.Ctx,
					provider.Uuid,
					func() (types.Provider, error) { return provider, nil },
				))
			},
			contains: "provider active index is missing derived key",
		},
		{
			name: "missing SKU provider row",
			corrupt: func(t *testing.T, f *testFixture, _ types.Provider, sku types.SKU) {
				require.NoError(t, f.App.SKUKeeper.SKUs.Indexes.Provider.Unreference(
					f.Ctx,
					sku.Uuid,
					func() (types.SKU, error) { return sku, nil },
				))
			},
			contains: "SKU provider index is missing derived key",
		},
		{
			name: "missing SKU active row",
			corrupt: func(t *testing.T, f *testFixture, _ types.Provider, sku types.SKU) {
				require.NoError(t, f.App.SKUKeeper.SKUs.Indexes.Active.Unreference(
					f.Ctx,
					sku.Uuid,
					func() (types.SKU, error) { return sku, nil },
				))
			},
			contains: "SKU active index is missing derived key",
		},
		{
			name: "missing SKU provider-active row",
			corrupt: func(t *testing.T, f *testFixture, _ types.Provider, sku types.SKU) {
				require.NoError(t, f.App.SKUKeeper.SKUs.Indexes.ProviderActive.Unreference(
					f.Ctx,
					sku.Uuid,
					func() (types.SKU, error) { return sku, nil },
				))
			},
			contains: "SKU provider-active index is missing derived key",
		},
		{
			name: "corrupt provider active marker",
			corrupt: func(t *testing.T, f *testFixture, provider types.Provider, _ types.SKU) {
				key, err := collections.EncodeKeyWithPrefix(
					types.ProviderByActiveIndexKey.Bytes(),
					collections.PairKeyCodec(collections.BoolKey, collections.StringKey),
					collections.Join(provider.Active, provider.Uuid),
				)
				require.NoError(t, err)
				f.Ctx.KVStore(f.App.GetKey(types.StoreKey)).Set(key, []byte{0xff})
			},
			contains: "walk provider active index:",
		},
		{
			name: "mismatched provider address row",
			corrupt: func(t *testing.T, f *testFixture, provider types.Provider, _ types.SKU) {
				mismatched := provider
				mismatched.Address = f.TestAccs[3].String()
				require.NoError(t, f.App.SKUKeeper.Providers.Indexes.Address.Reference(
					f.Ctx,
					provider.Uuid,
					mismatched,
					func() (types.Provider, error) { return types.Provider{}, collections.ErrNotFound },
				))
			},
			contains: "provider address index key",
		},
		{
			name: "orphaned SKU provider-active row",
			corrupt: func(t *testing.T, f *testFixture, _ types.Provider, sku types.SKU) {
				require.NoError(t, f.App.SKUKeeper.SKUs.Indexes.ProviderActive.Reference(
					f.Ctx,
					testSKU2UUID,
					sku,
					func() (types.SKU, error) { return types.SKU{}, collections.ErrNotFound },
				))
			},
			contains: "SKU provider-active index references missing primary key",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			f := initFixture(t)
			provider, sku := seedInvariantState(t, f)
			message, broken := keeper.StateInvariant(f.App.SKUKeeper)(f.Ctx)
			require.False(t, broken, message)

			test.corrupt(t, f, provider, sku)
			message, broken = keeper.StateInvariant(f.App.SKUKeeper)(f.Ctx)
			require.True(t, broken)
			require.Contains(t, message, test.contains)
			if strings.HasPrefix(test.name, "missing provider") {
				require.Contains(t, message, "for primary key "+provider.Uuid)
			} else if strings.HasPrefix(test.name, "missing SKU") {
				require.Contains(t, message, "for primary key "+sku.Uuid)
			}
		})
	}
}

func TestStateInvariant_FormatsSecondaryIndexKeys(t *testing.T) {
	tests := []struct {
		name     string
		corrupt  func(*testing.T, *testFixture, types.Provider, types.SKU)
		expected func(*testFixture, types.Provider, types.SKU) string
	}{
		{
			name: "provider address",
			corrupt: func(t *testing.T, f *testFixture, provider types.Provider, _ types.SKU) {
				indexed := provider
				indexed.Address = f.TestAccs[3].String()
				replaceMultiIndexReference(
					t, f.Ctx, f.App.SKUKeeper.Providers.Indexes.Address, provider.Uuid, provider, indexed,
				)
			},
			expected: func(f *testFixture, provider types.Provider, _ types.SKU) string {
				return fmt.Sprintf(
					"provider address index key %s for primary key %s does not match derived key %s",
					f.TestAccs[3],
					provider.Uuid,
					provider.Address,
				)
			},
		},
		{
			name: "provider active",
			corrupt: func(t *testing.T, f *testFixture, provider types.Provider, _ types.SKU) {
				indexed := provider
				indexed.Active = false
				replaceMultiIndexReference(
					t, f.Ctx, f.App.SKUKeeper.Providers.Indexes.Active, provider.Uuid, provider, indexed,
				)
			},
			expected: func(_ *testFixture, provider types.Provider, _ types.SKU) string {
				return fmt.Sprintf(
					"provider active index key false for primary key %s does not match derived key true",
					provider.Uuid,
				)
			},
		},
		{
			name: "SKU provider",
			corrupt: func(t *testing.T, f *testFixture, _ types.Provider, sku types.SKU) {
				indexed := sku
				indexed.ProviderUuid = testProvider2UUID
				replaceMultiIndexReference(
					t, f.Ctx, f.App.SKUKeeper.SKUs.Indexes.Provider, sku.Uuid, sku, indexed,
				)
			},
			expected: func(_ *testFixture, _ types.Provider, sku types.SKU) string {
				return fmt.Sprintf(
					"SKU provider index key %q for primary key %s does not match derived key %q",
					testProvider2UUID,
					sku.Uuid,
					sku.ProviderUuid,
				)
			},
		},
		{
			name: "SKU active",
			corrupt: func(t *testing.T, f *testFixture, _ types.Provider, sku types.SKU) {
				indexed := sku
				indexed.Active = false
				replaceMultiIndexReference(
					t, f.Ctx, f.App.SKUKeeper.SKUs.Indexes.Active, sku.Uuid, sku, indexed,
				)
			},
			expected: func(_ *testFixture, _ types.Provider, sku types.SKU) string {
				return fmt.Sprintf(
					"SKU active index key false for primary key %s does not match derived key true",
					sku.Uuid,
				)
			},
		},
		{
			name: "SKU provider-active",
			corrupt: func(t *testing.T, f *testFixture, _ types.Provider, sku types.SKU) {
				indexed := sku
				indexed.ProviderUuid = testProvider2UUID
				indexed.Active = false
				replaceMultiIndexReference(
					t, f.Ctx, f.App.SKUKeeper.SKUs.Indexes.ProviderActive, sku.Uuid, sku, indexed,
				)
			},
			expected: func(_ *testFixture, _ types.Provider, sku types.SKU) string {
				return fmt.Sprintf(
					"SKU provider-active index key (%q, false) for primary key %s does not match derived key (%q, true)",
					testProvider2UUID,
					sku.Uuid,
					sku.ProviderUuid,
				)
			},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			f := initFixture(t)
			provider, sku := seedInvariantState(t, f)
			test.corrupt(t, f, provider, sku)

			message, broken := keeper.StateInvariant(f.App.SKUKeeper)(f.Ctx)
			require.True(t, broken, message)
			require.Equal(
				t,
				sdk.FormatInvariant(types.ModuleName, "state", test.expected(f, provider, sku)),
				message,
			)
		})
	}
}

func replaceMultiIndexReference[ReferenceKey, Value any](
	t *testing.T,
	ctx sdk.Context,
	index *indexes.Multi[ReferenceKey, string, Value],
	primaryKey string,
	current,
	indexed Value,
) {
	t.Helper()
	require.NoError(t, index.Unreference(
		ctx,
		primaryKey,
		func() (Value, error) { return current, nil },
	))
	require.NoError(t, index.Reference(
		ctx,
		primaryKey,
		indexed,
		func() (Value, error) {
			var zero Value
			return zero, collections.ErrNotFound
		},
	))
}

func seedInvariantState(t *testing.T, f *testFixture) (types.Provider, types.SKU) {
	t.Helper()
	provider := types.Provider{
		Uuid:          testProviderUUID,
		Address:       f.TestAccs[0].String(),
		PayoutAddress: f.TestAccs[1].String(),
		Active:        true,
	}
	sku := types.SKU{
		Uuid:         testSKU1UUID,
		ProviderUuid: provider.Uuid,
		Name:         "compute",
		Unit:         types.Unit_UNIT_PER_HOUR,
		BasePrice:    sdk.NewCoin("umfx", sdkmath.NewInt(3600)),
		Active:       true,
	}
	require.NoError(t, f.App.SKUKeeper.SetProvider(f.Ctx, provider))
	require.NoError(t, f.App.SKUKeeper.SetSKU(f.Ctx, sku))
	require.NoError(t, f.App.SKUKeeper.ProviderSequence.Set(f.Ctx, 1))
	require.NoError(t, f.App.SKUKeeper.SKUSequence.Set(f.Ctx, 1))
	return provider, sku
}
