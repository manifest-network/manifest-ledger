package types

import (
	"net/url"
	"strconv"
	"strings"

	sdk "github.com/cosmos/cosmos-sdk/types"

	pkguuid "github.com/manifest-network/manifest-ledger/pkg/uuid"
)

var (
	_ sdk.Msg = &MsgCreateProvider{}
	_ sdk.Msg = &MsgUpdateProvider{}
	_ sdk.Msg = &MsgDeactivateProvider{}
	_ sdk.Msg = &MsgCreateSKU{}
	_ sdk.Msg = &MsgUpdateSKU{}
	_ sdk.Msg = &MsgDeactivateSKU{}
	_ sdk.Msg = &MsgUpdateParams{}
)

// NewMsgCreateProvider creates a new MsgCreateProvider instance.
func NewMsgCreateProvider(
	authority string,
	address string,
	payoutAddress string,
	metaHash []byte,
	apiURL string,
) *MsgCreateProvider {
	return &MsgCreateProvider{
		Authority:     authority,
		Address:       address,
		PayoutAddress: payoutAddress,
		MetaHash:      metaHash,
		ApiUrl:        apiURL,
	}
}

// Validate performs basic validation.
func (msg *MsgCreateProvider) Validate() error {
	if _, err := sdk.AccAddressFromBech32(msg.Authority); err != nil {
		return ErrUnauthorized.Wrapf("invalid authority address: %s", err)
	}

	if _, err := sdk.AccAddressFromBech32(msg.Address); err != nil {
		return ErrInvalidProvider.Wrapf("invalid provider address: %s", err)
	}

	if _, err := sdk.AccAddressFromBech32(msg.PayoutAddress); err != nil {
		return ErrInvalidProvider.Wrapf("invalid payout address: %s", err)
	}

	// Validate meta_hash length if provided
	if len(msg.MetaHash) > MaxMetaHashLength {
		return ErrInvalidProvider.Wrapf("meta_hash exceeds maximum length of %d bytes", MaxMetaHashLength)
	}

	// Validate api_url if provided
	if msg.ApiUrl != "" {
		if err := ValidateAPIURL(msg.ApiUrl); err != nil {
			return err
		}
	}

	return nil
}

// NewMsgUpdateProvider creates a new MsgUpdateProvider instance. An empty
// apiURL preserves the existing URL; callers can explicitly clear it by
// setting ClearApiUrl on the returned message.
func NewMsgUpdateProvider(
	authority string,
	uuid string,
	address string,
	payoutAddress string,
	metaHash []byte,
	active bool,
	apiURL string,
) *MsgUpdateProvider {
	return &MsgUpdateProvider{
		Authority:     authority,
		Uuid:          uuid,
		Address:       address,
		PayoutAddress: payoutAddress,
		MetaHash:      metaHash,
		Active:        active,
		ApiUrl:        apiURL,
	}
}

// Validate performs basic validation.
func (msg *MsgUpdateProvider) Validate() error {
	if _, err := sdk.AccAddressFromBech32(msg.Authority); err != nil {
		return ErrUnauthorized.Wrapf("invalid authority address: %s", err)
	}

	if err := pkguuid.ValidateUUIDv7(msg.Uuid); err != nil {
		return ErrInvalidProvider.Wrapf("invalid uuid: %s", err)
	}

	if _, err := sdk.AccAddressFromBech32(msg.Address); err != nil {
		return ErrInvalidProvider.Wrapf("invalid provider address: %s", err)
	}

	if _, err := sdk.AccAddressFromBech32(msg.PayoutAddress); err != nil {
		return ErrInvalidProvider.Wrapf("invalid payout address: %s", err)
	}

	// Validate meta_hash length if provided
	if len(msg.MetaHash) > MaxMetaHashLength {
		return ErrInvalidProvider.Wrapf("meta_hash exceeds maximum length of %d bytes", MaxMetaHashLength)
	}

	if msg.ClearApiUrl && msg.ApiUrl != "" {
		return ErrInvalidAPIURL.Wrap("clear_api_url cannot be true when api_url is non-empty")
	}

	// Validate api_url if provided (empty means keep existing unless clear_api_url is true)
	if msg.ApiUrl != "" {
		if err := ValidateAPIURL(msg.ApiUrl); err != nil {
			return err
		}
	}

	return nil
}

// NewMsgDeactivateProvider creates a new MsgDeactivateProvider instance.
func NewMsgDeactivateProvider(
	authority string,
	uuid string,
	limit uint64,
) *MsgDeactivateProvider {
	return &MsgDeactivateProvider{
		Authority: authority,
		Uuid:      uuid,
		Limit:     limit,
	}
}

// Validate performs basic validation.
func (msg *MsgDeactivateProvider) Validate() error {
	if _, err := sdk.AccAddressFromBech32(msg.Authority); err != nil {
		return ErrUnauthorized.Wrapf("invalid authority address: %s", err)
	}

	if err := pkguuid.ValidateUUIDv7(msg.Uuid); err != nil {
		return ErrInvalidProvider.Wrapf("invalid uuid: %s", err)
	}

	if msg.Limit > MaxDeactivateSKULimit {
		return ErrInvalidProvider.Wrapf("limit %d exceeds maximum allowed %d", msg.Limit, MaxDeactivateSKULimit)
	}

	return nil
}

// NewMsgCreateSKU creates a new MsgCreateSKU instance.
func NewMsgCreateSKU(
	authority string,
	providerUUID string,
	name string,
	unit Unit,
	basePrice sdk.Coin,
	metaHash []byte,
) *MsgCreateSKU {
	return &MsgCreateSKU{
		Authority:    authority,
		ProviderUuid: providerUUID,
		Name:         name,
		Unit:         unit,
		BasePrice:    basePrice,
		MetaHash:     metaHash,
	}
}

// Validate performs basic validation.
func (msg *MsgCreateSKU) Validate() error {
	if _, err := sdk.AccAddressFromBech32(msg.Authority); err != nil {
		return ErrUnauthorized.Wrapf("invalid authority address: %s", err)
	}

	if err := pkguuid.ValidateUUIDv7(msg.ProviderUuid); err != nil {
		return ErrInvalidSKU.Wrapf("invalid provider_uuid: %s", err)
	}

	if msg.Name == "" {
		return ErrInvalidSKU.Wrap("name cannot be empty")
	}

	if len(msg.Name) > MaxSKUNameLength {
		return ErrInvalidSKU.Wrapf("name exceeds maximum length of %d bytes", MaxSKUNameLength)
	}

	if msg.Unit == Unit_UNIT_UNSPECIFIED {
		return ErrInvalidSKU.Wrap("unit cannot be unspecified")
	}

	if !msg.BasePrice.IsValid() || msg.BasePrice.IsZero() {
		return ErrInvalidSKU.Wrap("base price must be valid and non-zero")
	}

	// Validate that price and unit combination produces a non-zero per-second rate
	if err := ValidatePriceAndUnit(msg.BasePrice, msg.Unit); err != nil {
		return ErrInvalidSKU.Wrapf("invalid price/unit combination: %s", err)
	}

	// Validate meta_hash length if provided
	if len(msg.MetaHash) > MaxMetaHashLength {
		return ErrInvalidSKU.Wrapf("meta_hash exceeds maximum length of %d bytes", MaxMetaHashLength)
	}

	return nil
}

// NewMsgUpdateSKU creates a new MsgUpdateSKU instance.
func NewMsgUpdateSKU(
	authority string,
	uuid string,
	providerUUID string,
	name string,
	unit Unit,
	basePrice sdk.Coin,
	metaHash []byte,
	active bool,
) *MsgUpdateSKU {
	return &MsgUpdateSKU{
		Authority:    authority,
		Uuid:         uuid,
		ProviderUuid: providerUUID,
		Name:         name,
		Unit:         unit,
		BasePrice:    basePrice,
		MetaHash:     metaHash,
		Active:       active,
	}
}

// Validate performs basic validation.
func (msg *MsgUpdateSKU) Validate() error {
	if _, err := sdk.AccAddressFromBech32(msg.Authority); err != nil {
		return ErrUnauthorized.Wrapf("invalid authority address: %s", err)
	}

	if err := pkguuid.ValidateUUIDv7(msg.Uuid); err != nil {
		return ErrInvalidSKU.Wrapf("invalid uuid: %s", err)
	}

	if err := pkguuid.ValidateUUIDv7(msg.ProviderUuid); err != nil {
		return ErrInvalidSKU.Wrapf("invalid provider_uuid: %s", err)
	}

	if msg.Name == "" {
		return ErrInvalidSKU.Wrap("name cannot be empty")
	}

	if len(msg.Name) > MaxSKUNameLength {
		return ErrInvalidSKU.Wrapf("name exceeds maximum length of %d bytes", MaxSKUNameLength)
	}

	if msg.Unit == Unit_UNIT_UNSPECIFIED {
		return ErrInvalidSKU.Wrap("unit cannot be unspecified")
	}

	if !msg.BasePrice.IsValid() || msg.BasePrice.IsZero() {
		return ErrInvalidSKU.Wrap("base price must be valid and non-zero")
	}

	// Validate that price and unit combination produces a non-zero per-second rate
	if err := ValidatePriceAndUnit(msg.BasePrice, msg.Unit); err != nil {
		return ErrInvalidSKU.Wrapf("invalid price/unit combination: %s", err)
	}

	// Validate meta_hash length if provided
	if len(msg.MetaHash) > MaxMetaHashLength {
		return ErrInvalidSKU.Wrapf("meta_hash exceeds maximum length of %d bytes", MaxMetaHashLength)
	}

	return nil
}

// NewMsgDeactivateSKU creates a new MsgDeactivateSKU instance.
func NewMsgDeactivateSKU(
	authority string,
	uuid string,
) *MsgDeactivateSKU {
	return &MsgDeactivateSKU{
		Authority: authority,
		Uuid:      uuid,
	}
}

// Validate performs basic validation.
func (msg *MsgDeactivateSKU) Validate() error {
	if _, err := sdk.AccAddressFromBech32(msg.Authority); err != nil {
		return ErrUnauthorized.Wrapf("invalid authority address: %s", err)
	}

	if err := pkguuid.ValidateUUIDv7(msg.Uuid); err != nil {
		return ErrInvalidSKU.Wrapf("invalid uuid: %s", err)
	}

	return nil
}

// NewMsgUpdateParams creates a new MsgUpdateParams instance.
func NewMsgUpdateParams(authority string, params Params) *MsgUpdateParams {
	return &MsgUpdateParams{
		Authority: authority,
		Params:    params,
	}
}

// Validate performs basic validation.
func (msg *MsgUpdateParams) Validate() error {
	if _, err := sdk.AccAddressFromBech32(msg.Authority); err != nil {
		return ErrUnauthorized.Wrapf("invalid authority address: %s", err)
	}

	return msg.Params.Validate()
}

// ValidateAPIURL validates that the API URL is a valid HTTPS URL.
func ValidateAPIURL(apiURL string) error {
	parsedURL, err := parseAPIURL(apiURL)
	if err != nil {
		return err
	}
	if parsedURL.Hostname() == "" {
		return ErrInvalidAPIURL.Wrap("api_url must have a valid host")
	}
	if port := parsedURL.Port(); port != "" {
		number, err := strconv.ParseUint(port, 10, 16)
		if err != nil || number == 0 {
			return ErrInvalidAPIURL.Wrap("api_url port must be between 1 and 65535")
		}
	} else if strings.HasSuffix(parsedURL.Host, ":") {
		return ErrInvalidAPIURL.Wrap("api_url port must be between 1 and 65535")
	}
	return nil
}

// parseAPIURL preserves the URL checks used for historical state. New messages
// additionally validate the hostname and explicit port through ValidateAPIURL.
func parseAPIURL(apiURL string) (*url.URL, error) {
	if len(apiURL) > MaxAPIURLLength {
		return nil, ErrInvalidAPIURL.Wrapf("api_url exceeds maximum length of %d bytes", MaxAPIURLLength)
	}

	parsedURL, err := url.Parse(apiURL)
	if err != nil {
		return nil, ErrInvalidAPIURL.Wrapf("failed to parse api_url: %s", err)
	}

	if parsedURL.Scheme != "https" {
		return nil, ErrInvalidAPIURL.Wrap("api_url must use HTTPS scheme")
	}

	if parsedURL.Host == "" {
		return nil, ErrInvalidAPIURL.Wrap("api_url must have a valid host")
	}

	// Reject URLs with user info (credentials in URL)
	if parsedURL.User != nil {
		return nil, ErrInvalidAPIURL.Wrap("api_url must not contain user credentials")
	}

	return parsedURL, nil
}
