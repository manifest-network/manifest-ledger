# Provider Setup Guide

This guide walks you through setting up a Provider in the x/sku module.

## Prerequisites

- Access to the Manifest Network chain (testnet or mainnet)
- A funded wallet for transaction fees
- Authorization: Either be the module authority or be added to the `allowed_list` parameter

## Overview

A Provider represents an entity (organization, business, or individual) that offers services through the Manifest Network billing system. Before you can create SKUs (billable items), you must first create a Provider.

Each Provider has:
- **UUID**: Auto-generated unique UUIDv7 identifier (deterministic for consensus)
- **Address**: Management address for the provider
- **Payout Address**: Where earned tokens are sent during withdrawals
- **API URL**: HTTPS endpoint for the provider's off-chain API (tenant authentication)
- **Meta Hash**: Optional hash of off-chain metadata
- **Active**: Whether the provider can have new SKUs created

## Step 1: Check Your Authorization

First, verify you have permission to create providers:

```bash
# Check the current allowed list
manifestd query sku params --output json
```

The response will show:
```json
{
  "params": {
    "allowed_list": ["manifest1abc...", "manifest1def..."]
  }
}
```

You can create providers if:
1. Your address is in the `allowed_list`, OR
2. You are the module authority (POA admin group)

### Adding Addresses to the Allowed List

Only the module authority can add addresses to the allowed list:

```bash
manifestd tx sku update-params \
  --allowed-list "manifest1existing...,manifest1newaddress..." \
  --from authority \
  --chain-id manifest-1
```

> **Note:** The allowed list is replaced entirely, so include all addresses you
> want authorized. It accepts at most 100 valid, distinct decoded account
> identities; equivalent Bech32 spellings are duplicates.

## Step 2: Prepare Provider Information

Before creating a provider, gather the following information:

| Field | Description | Example |
|-------|-------------|---------|
| **Address** | The provider's operational address (can be used for management) | `manifest1provider...` |
| **Payout Address** | Where earned tokens will be sent during withdrawals | `manifest1payout...` |
| **API URL** | HTTPS endpoint where tenants can authenticate to get connection details | `https://api.provider.com` |
| **Meta Hash** (optional) | Hex-encoded hash of off-chain metadata (e.g., business info, contact details) | `deadbeef` |

The payout address must be allowed by the bank module. Protected module accounts,
including the distribution account, are rejected on provider creation and update.
An authorized administrator can repair an existing blocked payout by updating it
to an allowed address while preserving the provider's current `active` value.
An inactive provider can be repaired with `false` even during an unfinished
deactivation cascade. Billing also checks the destination when settling funds.
Historical providers remain importable, so operators must perform the
[provider payout preflight](../../billing/docs/MIGRATION.md#provider-payout-policy-preflight)
before upgrading.

API URLs require a nonempty hostname and HTTPS. An explicit port must be between
1 and 65535; credentials and empty explicit ports are rejected. IPv6 literals use
brackets, for example `https://[2001:db8::1]:8443`.
Historical URLs remain importable and may be preserved on an unrelated update;
newly supplied URLs must satisfy the current checks.

### About Meta Hash

The `meta_hash` field stores a hash (e.g., SHA256) of off-chain metadata. This allows you to:
- Reference additional provider information stored off-chain (IPFS, database, etc.)
- Verify the integrity of off-chain data
- Keep on-chain data minimal

Example off-chain metadata:
```json
{
  "name": "Acme Cloud Services",
  "website": "https://acme.example.com",
  "support_email": "support@acme.example.com",
  "description": "Enterprise cloud computing solutions"
}
```

Hash this JSON and store the hex-encoded hash on-chain.

## Step 3: Create the Provider

```bash
manifestd tx sku create-provider \
  <address> \
  <payout_address> \
  --api-url <https_url> \
  --meta-hash <hex_encoded_hash> \
  --from <your_key> \
  --chain-id manifest-1 \
  --fees 5000upwr
```

### Example

```bash
manifestd tx sku create-provider \
  manifest1provideraddr123456789abcdef \
  manifest1payoutaddr987654321fedcba \
  --api-url https://api.myprovider.com \
  --meta-hash a1b2c3d4e5f6 \
  --from mykey \
  --chain-id manifest-1 \
  --fees 5000upwr
```

### Successful Response

```json
{
  "code": 0,
  "txhash": "ABC123...",
  "events": [
    {
      "type": "provider_created",
      "attributes": [
        {"key": "provider_uuid", "value": "01912345-6789-7abc-8def-0123456789ab"},
        {"key": "address", "value": "manifest1provideraddr..."},
        {"key": "payout_address", "value": "manifest1payoutaddr..."},
        {"key": "created_by", "value": "manifest1authority..."}
      ]
    }
  ]
}
```

Note the `provider_uuid` from the response - you'll need it when creating SKUs.

## Step 4: Verify the Provider

Query your newly created provider:

```bash
# By UUID
manifestd query sku provider 01912345-6789-7abc-8def-0123456789ab --output json
```

Response:
```json
{
  "provider": {
    "uuid": "01912345-6789-7abc-8def-0123456789ab",
    "address": "manifest1provideraddr...",
    "payout_address": "manifest1payoutaddr...",
    "api_url": "https://api.myprovider.com",
    "meta_hash": "obLD1OX2",
    "active": true
  }
}
```

> **Note:** `meta_hash` is a `bytes` field, so it is returned base64-encoded in JSON output even though it is supplied as hex on the CLI (`a1b2c3d4e5f6` becomes `obLD1OX2`).

List all providers:
```bash
manifestd query sku providers --output json
```

List active providers only:
```bash
manifestd query sku providers --active-only --output json
```

## Step 5: Update Provider (Optional)

If you need to update provider details:

```bash
manifestd tx sku update-provider \
  <provider_uuid> \
  <new_address> \
  <new_payout_address> \
  <active> \
  --api-url <new_api_url> \
  --meta-hash <new_meta_hash> \
  --from <your_key> \
  --chain-id manifest-1
```

> **Important:** `update-provider` is a full overwrite, not a partial update. Every field — `address`, `payout_address`, `meta_hash`, and `active` — must be re-supplied. Omitting `--meta-hash` clears the existing meta_hash; only `--api-url` is preserved when left empty. Use `--clear-api-url` to remove the existing URL. Do not combine it with a non-empty `--api-url`.
>
> The `<active>` argument cannot be used to deactivate a currently-active provider: passing `false` on an active provider fails with `cannot deactivate provider via UpdateProvider; use DeactivateProvider instead` — use `deactivate-provider` (Step 6) instead, which cascades to SKUs. Pass `true` to keep the provider active or to reactivate an inactive one after its SKU cascade finishes. (An already-inactive provider also accepts `false`, leaving it inactive.)

Payout changes apply to all existing unsettled accrual as well as future charges.
Withdraw before updating if the old recipient should receive that accrual. If
the old payout is blocked or collides with a paying tenant's credit address,
repair it first and withdraw to the new recipient. SKU allowed-list members
have the same provider-management powers as the authority.

### Example: Change Payout Address

```bash
manifestd tx sku update-provider \
  01912345-6789-7abc-8def-0123456789ab \
  manifest1provideraddr123456789abcdef \
  manifest1newpayoutaddr111222333 \
  true \
  --api-url https://api.myprovider.com \
  --meta-hash a1b2c3d4e5f6 \
  --from mykey \
  --chain-id manifest-1
```

### Clear the API URL

```bash
manifestd tx sku update-provider \
  01912345-6789-7abc-8def-0123456789ab \
  manifest1provideraddr123456789abcdef \
  manifest1payoutaddr987654321fedcba \
  true \
  --clear-api-url \
  --meta-hash [current-meta-hash-hex] \
  --from mykey \
  --chain-id manifest-1
```

## Step 6: Deactivate Provider (If Needed)

To deactivate a provider (soft delete):

```bash
manifestd tx sku deactivate-provider 01912345-6789-7abc-8def-0123456789ab \
  --limit 50 \
  --from mykey \
  --chain-id manifest-1
```

> **Important:** Deactivating a provider:
> - **Cascades to deactivate the provider's SKUs, up to `--limit` per call** (default 50, max 100). After each committed transaction succeeds, query `manifestd query sku skus-by-provider UUID --active-only --limit 1 -o json` at the transaction height. Repeat while it returns a SKU; the provider itself is deactivated on the first call only. See the [complete CLI workflow](API.md#complete-a-provider-deactivation-cascade), including transaction confirmation and restart handling.
> - Prevents creation of new SKUs for this provider
> - Does NOT affect existing leases (billing continues at locked prices)
> - The provider can still receive withdrawals from active leases
> - Can be reactivated via `update-provider` with `active=true` only after all cascade pages complete (no active SKUs remain)
> - SKUs must be individually reactivated via `update-sku` after provider reactivation

## Next Steps

Once your provider is created, you can:

1. **Create SKUs** - See [SKU Setup Guide](SKU_GUIDE.md) for creating billable items
2. **Monitor Activity** - Query provider's SKUs and associated leases
3. **Withdraw Earnings** - Use the billing module to withdraw accrued tokens

## Common Issues

### "unauthorized"

**Cause:** Your address is not authorized to manage providers.

**Solution:** 
- Ask the module authority to add your address to the allowed list
- Or submit the transaction through governance if you're using the authority

### "provider not found"

**Cause:** The provider UUID doesn't exist.

**Solution:** 
- List all providers: `manifestd query sku providers`
- Verify you're using the correct provider UUID

### "invalid provider" (invalid address)

**Cause:** The address format is invalid.

**Solution:**
- Ensure addresses start with `manifest1`
- Verify the address is the correct length (typically 47 characters for a `manifest`-prefixed account address)

## Provider Lifecycle

```
┌─────────────────────────────────────────────────────────────────┐
│                      Provider Lifecycle                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────┐    ┌──────────┐    ┌──────────────┐              │
│  │  Create  │───>│  Active  │───>│  Deactivated │              │
│  └──────────┘    └──────────┘    └──────────────┘              │
│                       │                  │                      │
│                       │                  │                      │
│                       v                  v                      │
│                  Can create         Cannot create               │
│                  new SKUs           new SKUs                    │
│                       │                  │                      │
│                       v                  v                      │
│                  SKUs active       SKUs cascade to INACTIVE     │
│                                    (paginated; repeat while     │
│                                     SKUs remain)                │
│                       │                  │                      │
│                       v                  v                      │
│                  Existing leases   Existing leases              │
│                  work normally     continue (locked price)      │
│                       │                  │                      │
│                       v                  v                      │
│                  Can receive       Can still receive            │
│                  withdrawals       withdrawals                  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

> **Note:** Complete all SKU deactivation pages before reactivating the provider; reactivation is rejected while active SKUs remain. After provider reactivation, its SKUs remain inactive and must be individually reactivated via `update-sku` with `active=true`.

## Related Documentation

- [SKU Setup Guide](SKU_GUIDE.md) - Creating and managing SKUs
- [API Reference](API.md) - Complete API documentation
- [Billing Module](../../billing/README.md) - Understanding the billing system
- [Billing Migration Guide](../../billing/docs/MIGRATION.md) - Migrating existing off-chain leases
