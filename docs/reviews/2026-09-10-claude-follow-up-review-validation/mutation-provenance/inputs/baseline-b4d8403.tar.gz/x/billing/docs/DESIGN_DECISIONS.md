# Billing Module Design Decisions

This document records key design decisions made during the development of the x/billing module, including the rationale and trade-offs considered.

## Decision 1: Pre-Funded Credit Account Model

**Decision:** Require tenants to pre-fund a credit account before creating leases, rather than billing post-usage.

**Alternatives Considered:**
1. Post-usage billing with invoices
2. Real-time deduction per block
3. Pre-funded credit account (chosen)

**Rationale:**
- **No Credit Risk:** Provider always paid from existing funds
- **Simple UX:** Mimics AWS credits model familiar to users
- **Off-Chain Top-Up:** Easy integration with fiat payment systems
- **No Collections:** No need for dispute resolution

**Trade-offs:**
- Users must pre-pay
- Unused credits locked in account (no withdrawal mechanism)
- Requires monitoring for low balance

**Issuer debit policy (2026-09-09):** The entire balance of every registered billing credit account is protected from tokenfactory administrator burn-from and force-transfer operations. Protecting only reserved amounts would permit administrator-assisted withdrawal of otherwise nonrefundable credit; lazy settlement can also make unreserved funds payable for accrued service. Issuer powers over ordinary wallets remain available. Deposits and minting into credit remain allowed, and billing retains its normal settlement/payout bank dependency.

**Vesting credit:** Billing values credit by per-denomination spendable bank
balance at block time, excluding locked coins. A vesting account pre-created
at a derived address remains fundable; unlocked top-ups are usable. Rejecting
all vesting account types would let address pre-creation disable funding, while
creating accounts inside a read-only address query would violate query semantics.
Strict reservation backing remains mandatory: arbitrary shortfalls cannot be
clamped in a way that silently spends sibling guarantees. The offline migration
preflight requires auth state and an explicit valuation time for the same rule.


The application injects a bank adapter only into the tokenfactory keeper. It checks the existing credit-address reverse index before a source debit and rejects the operation on lookup failure. This needs no tokenfactory fork or new state migration. Validators must activate the consensus behavior with the coordinated application upgrade. The tradeoff is an explicit clawback exception: tokens placed into registered billing credit cannot be seized by their issuer until they leave through billing payout. Registration is the boundary; simply calculating or sending to an unregistered derived address does not establish protection.

## Decision 2: Lazy Settlement vs Per-Block Processing

**Decision:** Settle leases lazily during write operations (withdrawal, close) rather than every block.

**Alternatives Considered:**
1. EndBlocker settlement of all leases
2. Per-block micro-transfers
3. Lazy settlement on write operations (chosen)

**Rationale:**
- **Chain Performance:** Settlement does not scan all active leases each block; bounded pending-lease expiration still runs in EndBlock
- **Scalability:** Settlement touches the requested leases and their items/denominations; production capacity still requires measured workload and hardware budgets
- **Gas Efficiency:** Settlement cost paid by user who triggers it
- **Simplicity:** No background job management

**Trade-offs:**
- Lease state queries (`Lease`, `Leases`, `LeasesByTenant`, `LeasesByProvider`) return stored state
- Use `WithdrawableAmount` for one lease or `ProviderWithdrawable` for an ordered page-local execution estimate. The provider query mirrors transaction best-effort semantics: it discards a failed lease simulation, reports its UUID in index order, and carries successful virtual effects into later leases, but commits no query state. Provider pages are not additive because separate pages can share tenant balances. Every forward query page is comparable to one provider-wide withdrawal because the query limit is capped at the transaction maximum of 100. At identical state and time their failure lists also match. After commit, advance the query with the prior query response's first-unread cursor and the transaction with the prior transaction response's last-processed cursor; never interchange them.
- Auto-close only happens during write operations (CloseLease, Withdraw)
- Provider withdrawal requires explicit action

**Implementation Note:** Queries do NOT trigger settlement or auto-close. This is intentional to ensure state changes are properly committed during transactions.

## Decision 3: Derived Credit Account Addresses

**Decision:** Derive credit account address deterministically from tenant address using module-specific derivation.

**Alternatives Considered:**
1. Separate account with stored mapping
2. Use tenant address directly
3. Derived address with reverse lookup (chosen)

**Rationale:**
- **Isolation:** Credit funds separate from spendable balance
- **O(1) Detection:** Can identify credit accounts without full scan via reverse lookup
- **Deterministic:** Same tenant always gets same credit address
- **No Key Management:** No private key needed for credit account

**Trade-offs:**
- Funds at derived address are controlled by module
- Requires reverse lookup for O(1) detection
- Migration complexity if derivation changes

**Derivation Formula:**
```go
// Uses Cosmos SDK's address.Module function for proper module account derivation
key := append([]byte("billing/credit/"), tenantAddr.Bytes()...)
hash := sha256.Sum256(key)
creditAddr = address.Module("billing", hash[:])
```

See `x/billing/types/credit.go` for the implementation.

## Decision 4: Price Locking at Lease Creation

**Decision:** Lock SKU prices when lease is created; price changes only affect new leases.

**Alternatives Considered:**
1. Dynamic pricing (current SKU price always used)
2. Price lock with term limits
3. Permanent price lock at creation (chosen)

**Rationale:**
- **Predictability:** Tenants know exact cost
- **Trust:** No surprise price increases
- **Simplicity:** No price update propagation
- **Business Model:** Matches reserved instances pattern

**Trade-offs:**
- Provider cannot increase prices for existing leases
- Long-running leases may have stale prices
- No volume discount adjustments
- **Price decrease gaming**: When a provider reduces SKU prices, savvy tenants may close existing leases and create new ones at the lower rate. This is acceptable behavior—tenants are not obligated to maintain leases, and providers should factor this into pricing decisions.

**Implementation Note:** The `locked_price` stored in `LeaseItem` is the pre-computed per-second rate (not the original SKU price), calculated at lease creation using `skutypes.CalculatePricePerSecond()`.

## Decision 5: Multi-Item Leases

**Decision:** Allow a single lease to contain multiple SKU items rather than one SKU per lease.

**Alternatives Considered:**
1. One SKU per lease
2. Multiple SKUs per lease (chosen)
3. SKU bundles as composite SKUs

**Rationale:**
- **User Experience:** Single lease for complete infrastructure
- **Atomic Operations:** All items start/stop together
- **Fewer Objects:** Less storage overhead
- **Cleaner Billing:** Single settlement per lease

**Trade-offs:**
- More complex lease structure
- Cannot close individual items
- Settlement must iterate all items
- All items must be from the same provider

## Decision 6: Single Provider Per Lease

**Decision:** All SKUs in a lease must belong to the same provider.

**Alternatives Considered:**
1. Allow mixed providers in one lease
2. Single provider per lease (chosen)

**Rationale:**
- **Simplified Settlement:** Only one payout destination per lease
- **Clear Ownership:** Provider can close their own leases
- **Authorization:** Provider permission applies to entire lease
- **Accounting:** No splitting of settlements

**Trade-offs:**
- Users need multiple leases for multi-provider setups
- More leases to manage for complex deployments

## Decision 7: Soft Delete for Leases

**Decision:** Keep closed leases with CLOSED state rather than deleting them.

**Alternatives Considered:**
1. Hard delete closed leases
2. Soft delete with state flag (chosen)
3. Move to archive storage

**Rationale:**
- **Audit Trail:** Complete history preserved
- **Queries:** Can show past leases to tenant
- **Referential Integrity:** Provider queries still work
- **Dispute Resolution:** Evidence available if needed

**Trade-offs:**
- Storage grows indefinitely
- Must filter by state in queries
- No built-in pruning

## Decision 8: Provider Payout Address at Provider Level

**Decision:** Payout address defined on Provider (in SKU module), not per-lease or per-SKU.

**Alternatives Considered:**
1. Per-lease payout address
2. Per-SKU payout address
3. Per-provider payout address (chosen)

**Rationale:**
- **Simplicity:** Single payout destination per provider
- **Security:** Fewer addresses to secure
- **Operations:** Easy to change payout address
- **Module Independence:** Billing module doesn't duplicate provider data

**Trade-offs:**
- All provider revenue goes to one address
- Cannot split by SKU type
- Provider must distribute internally

## Decision 9: Multi-Denom Support

**Decision:** Allow SKUs to use different token denominations for their base_price, with credit accounts supporting multiple denoms.

**Alternatives Considered:**
1. Single global denom for all billing (rejected)
2. Per-provider denom restriction (rejected)
3. Full multi-denom support (chosen)

**Rationale:**
- **Flexibility:** Different SKUs can be priced in different tokens
- **Provider Choice:** Providers select appropriate payment token per SKU
- **Market Integration:** Can price in stablecoins, native tokens, or custom tokens
- **Simple Architecture:** Credit accounts leverage bank module's multi-denom support

**Implementation:**
- Each SKU's `base_price` is a `Coin` with its own denom
- Lease items store `locked_price` as `Coin` (preserving denom)
- Credit validation checks each denom separately
- Settlement transfers happen per-denom
- Credit accounts are regular bank accounts that can hold any denom
- No send restrictions on credit accounts (any token can be sent)
- Bank balances remain unrestricted and cursor-paginated in queries. Separately,
  new leases may not grow the reservation aggregate beyond 1,000 denoms because
  that coin set is rewritten on every reservation lifecycle transition.

**Trade-offs:**
- Lease creation validation more complex (check each denom)
- Settlement must aggregate and transfer per-denom
- Users must fund credit with correct denoms for their desired SKUs
- No automatic denom conversion
- Historical v2 reservation aggregates above the new cardinality limit remain
  releasable and readable, but cannot grow through new lease denominations

**Example:**
```
# Lease with two SKUs using different denoms:
Item 1: SKU 1 (priced in 'upwr') - locked_price: 1000upwr/second
Item 2: SKU 2 (priced in 'umfx') - locked_price: 500umfx/second

# Credit account needs:
- Enough 'upwr' for Item 1 at min_lease_duration
- Enough 'umfx' for Item 2 at min_lease_duration

# Settlement transfers:
- Accrued upwr → provider payout address
- Accrued umfx → provider payout address
```

## Decision 10: Authority-Based Lease Creation for Migration

**Decision:** Allow authority and allow-listed addresses to create leases on behalf of tenants via `MsgCreateLeaseForTenant`.

**Alternatives Considered:**
1. Tenant-only lease creation
2. Delegation/authz pattern
3. Authority with allow-list (chosen)

**Rationale:**
- **Migration Support:** Essential for moving off-chain leases on-chain
- **No User Action:** Tenant doesn't need to sign
- **Controlled:** Authority or explicit allow-list
- **Transparent:** Events indicate who created lease

**Trade-offs:**
- Trust in authority/allow-list
- Potential for abuse
- Requires proper off-chain coordination

## Decision 11: Per-Second Rate Storage

**Decision:** Store pre-computed per-second rates (`locked_price`) rather than original unit-based prices.

**Alternatives Considered:**
1. Keep original units, convert at settlement
2. Store per-block rates
3. Pre-compute per-second rates at lease creation (chosen)

**Rationale:**
- **Precision:** Consistent calculation regardless of original unit
- **Performance:** No division at settlement time
- **Verification:** Easy to audit
- **Block Time Independence:** Not tied to block duration

**Trade-offs:**
- Requires price divisibility validation at SKU creation
- Integer math only (no fractions)
- Less intuitive stored values

## Decision 12: Exact Divisibility Requirement

**Decision:** Require SKU prices to be exactly divisible by unit seconds (no rounding).

**Alternatives Considered:**
1. Allow rounding with defined behavior
2. Use fixed-point decimals
3. Require exact divisibility (chosen)

**Rationale:**
- **Determinism:** Same calculation everywhere
- **Auditability:** Can verify exact amounts
- **No Rounding Disputes:** Eliminates edge cases
- **Security:** No rounding exploitation

**Trade-offs:**
- Less pricing flexibility
- Must use specific values (multiples of 3600 for hourly, 86400 for daily)
- May seem artificial to users

**Example:** For UNIT_PER_HOUR (3600 seconds), valid prices include 3600, 7200, 36000, etc.

## Decision 13: Maximum Limits as DoS Protection

**Decision:** Impose configurable limits on leases per tenant and items per lease, plus hard-coded (non-governable) batch/cursor limits.

**Alternatives Considered:**
1. No limits (rely on gas)
2. Hard-coded limits
3. Configurable parameter limits for the per-tenant/per-lease bounds (chosen), with compile-time constants for batch/cursor sizes

**Rationale:**
- **DoS Prevention:** Bounds computation
- **Flexibility:** Can adjust via governance
- **Predictability:** Known bounds for clients
- **Fair Resource Use:** Prevents single tenant monopolizing

**Trade-offs:**
- Must choose appropriate defaults
- Power users may hit limits
- Parameter updates affect existing users

**Default Limits:**
| Parameter | Default | Hard Limit |
|-----------|---------|------------|
| `max_leases_per_tenant` | 100 | 10,000 |
| `max_items_per_lease` | 20 | 100 |
| `min_lease_duration` | 3600s | 2,592,000s (30 days) |
| `max_pending_leases_per_tenant` | 10 | 1,000 |
| `pending_timeout` | 1800s | 60s – 86,400s (min–max) |

`pending_timeout` is the only param with a lower bound: 0 is rejected by the minimum check (`MinPendingTimeout` = 60s), not a separate zero check.

The provider withdraw batch limits are **not** governance parameters — they are compile-time constants (`DefaultProviderWithdrawLimit` = 50, `MaxBatchLeaseSize` = 100) and require a binary release to change, not a param update.

## Decision 14: Minimum Lease Duration

**Decision:** Reserve enough credit to cover `min_lease_duration` seconds at the lease's locked rates before creating it. This parameter determines the initial reservation, not a minimum elapsed lease duration or minimum charge.

**Alternatives Considered:**
1. No minimum (allow immediate exhaustion)
2. Fixed minimum credit amount
3. Duration-based minimum (chosen)

**Rationale:**
- **Credit Coverage:** Requires available credit before a lease can be created
- **Rate-Based:** Adapts to lease cost automatically
- **Reservation Isolation:** Other leases cannot spend the new lease's initial reservation
- **Provider Protection:** Backs accrued charges with reserved credit while the lease runs

Tenants may cancel a PENDING lease without a charge or close an ACTIVE lease
before `min_lease_duration` has elapsed. Closure charges only accrued whole
seconds and releases the unused reservation, so this policy does not guarantee
minimum provider revenue or prevent repeated short leases.

**Trade-offs:**
- More complex lease creation validation
- May prevent low-balance users from creating expensive leases
- Requires calculation at creation time

**Implementation:**
```go
reservation = totalRatePerSecond * minLeaseDuration              // sdk.Coins, per denom
availableCredit = creditBalance - creditAccount.reserved_amounts // per denom
for each denom in reservation:
    if availableCredit[denom] < reservation[denom] {
        return ErrInsufficientCredit
    }
```

The check is against *available* credit (balance minus existing reservations),
evaluated per denomination, not against the raw balance as a single scalar. On
success the nominal amount initializes `Lease.reservation.remaining_amounts`
and is added to `CreditAccount.reserved_amounts`.

The runtime model deliberately stores the consumable remainder rather than
recomputing a fixed nominal sum:

```
R = SUM(A for each live modern lease) + U
```

`A` is a modern lease's remaining tranche and `U` is the explicit shared
allocation for live historical leases whose individual guarantees cannot be
reconstructed. Settlement protects other leases by limiting this lease to
`B - (R - A)`, where `B` is the tenant balance. The amount funded from `A` is
subtracted from both `A` and `R`; a terminal transition releases exactly the
remaining `A`. This own-tranche-first design lets a lease use its guarantee and
genuinely unreserved credit without consuming another lease's guarantee.

The account also stores `unattributed_lease_count`, the exact number of live
historical leases sharing `U`. Historical terminal transitions decrement this
counter in O(1) and release the exact remaining `U` when it reaches zero. The
counter remains meaningful when `U` has been fully consumed, avoiding a
consensus-time scan or inference from coin emptiness.

`min_lease_duration_at_creation` remains the nominal cap and governance-change
snapshot. It is not the amount released after settlement has consumed part of
the tranche.

## Decision 15: UUIDv7 for Identifiers

**Decision:** Use deterministic UUIDv7 for providers, SKUs, and leases instead of auto-increment uint64.

**Alternatives Considered:**
1. Auto-increment uint64 IDs
2. Random UUIDs (UUIDv4)
3. Deterministic UUIDv7 (chosen)

**Rationale:**
- **Time-ordered:** Natural sorting by creation time
- **Deterministic:** All validators generate identical UUIDs for same block
- **External Integration:** Easier to correlate with off-chain systems
- **Future-proof:** No practical limit vs uint64 theoretical max
- **Debugging:** Easier to trace and timestamp from ID

**Implementation:**
```go
// UUIDv7 = timestamp (48 bits) + version (4 bits) + sequence (12 bits) + variant (2 bits) + node (62 bits)
// timestamp: block time in milliseconds
// sequence: monotonic per-module counter (collections.Sequence)
// node: FNV-1a(header-hash + chain-id + module name + sequence)
```

**Trade-offs:**
- Larger storage (16 bytes vs 8 bytes)
- Longer string representation in queries/logs

## Decision 16: PENDING State and Provider Acknowledgement

**Decision:** Leases start in PENDING state and require provider acknowledgement before billing begins.

**Alternatives Considered:**
1. Immediate ACTIVE state (billing starts at creation)
2. Optional acknowledgement
3. Required acknowledgement with PENDING state (chosen)

**Rationale:**
- **Fair Billing:** Tenants not charged until resources actually provisioned
- **Provider Control:** Provider can accept or reject leases
- **Off-chain Sync:** Time for provider to provision resources
- **Dispute Avoidance:** Clear demarcation of when service starts

**Implementation:**
- Create → PENDING (credit locked)
- AcknowledgeLease revalidates every lease's hard timeout, every tenant's
  post-batch active cap, and the current payout's eligibility before any writes.
  The payout must be permitted by bank policy and distinct from every batch
  tenant's derived credit address.
- AcknowledgeLease → ACTIVE (billing starts) only when `blockTime <= created_at + current pending_timeout`
- RejectLease → REJECTED (credit unlocked)
- EndBlocker expiration → EXPIRED (credit unlocked)

**Trade-offs:**
- Additional message (AcknowledgeLease) required
- Provider must monitor for pending leases
- Potential for lease expiration if provider slow

## Decision 17: EndBlocker for Pending Expiration

**Decision:** `created_at + current pending_timeout` is a hard provider-acknowledgement deadline;
use EndBlocker to automatically expire PENDING leases after that deadline.

**Alternatives Considered:**
1. No automatic expiration (manual only)
2. Per-query lazy expiration
3. EndBlocker with rate limiting (chosen)

**Rationale:**
- **Automatic Cleanup:** No manual intervention is needed while the derived
  index remains consistent; the registered invariant exposes corruption that
  requires operator repair
- **Predictable:** Consistent behavior based on timeout
- **Fair to Tenants:** In invariant-consistent state, credit is unlocked without
  waiting indefinitely
- **DoS Protected:** Successful expiration mutations are rate limited to 100
  per block and the normal-state scan is time-bounded

**Trade-offs:**
- EndBlocker overhead (mitigated by rate limiting)
- Cleanup can lag behind the hard deadline, but overdue PENDING leases cannot be acknowledged while waiting; they can still be rejected or cancelled
- Range-queries the StateCreatedAt index (prefix 11) for `created_at` before the timeout cutoff (`created_at < blockTime - pending_timeout`), so a consistent store visits only expirable pending leases rather than the full pending set (O(expired) instead of O(total pending)). A manual `collections.Range` over the compound `((state, created_at), uuid)` key is used because collections' `PairRange` helper cannot do partial-prefix ranges on the `Pair[int32, time.Time]` reference key; `sdk.TimeKey`'s sortable encoding makes the byte range match the `created_at` range. Primary UUID, state, and deadline checks skip stale references before they consume the expiration quota and missing versus unreadable primaries produce distinct diagnostics. Stale rows can still increase scan work and missing rows remain invisible; neither is auto-repaired, so invariant failures require operator remediation. Candidate pages close their iterator before expiring leases. A cursor local to the block resumes strictly after the last candidate key; failed expirations do not consume the successful-expiration quota, and their unchanged rows are retried next block. A separate total visit cap is intentionally avoided because an oldest corrupt or failing prefix would otherwise permanently starve valid expirations. In consistent state, with >100 expirable leases, the oldest 100 are expired first and the remainder wait for later blocks.
- Max pending leases per tenant limit needed

## Decision 18: Tenant Cancellation of Pending Leases

**Decision:** Allow tenants to cancel their own PENDING leases before provider acknowledgement.

**Alternatives Considered:**
1. No cancellation (wait for timeout)
2. Cancellation allowed (chosen)

**Rationale:**
- **User Experience:** Tenants can change their mind immediately
- **Flexibility:** No need to wait for timeout
- **Immediate Credit Unlock:** Funds available for other leases

**Trade-offs:**
- Additional message type (CancelLease)
- Provider may have started provisioning (off-chain race)

## Decision 19: Compute-Specific Lease Item Fields (service_name / custom_domain)

**Decision:** Carry the compute-specific `service_name` and `custom_domain` fields directly on the generic `LeaseItem` rather than in a dedicated deployment module.

**Alternatives Considered:**
1. Wait for a dedicated `x/deployment` module before shipping these fields
2. Generic key/value metadata bag on the lease item
3. Compute-specific fields on `LeaseItem` as a pragmatic shortcut (chosen)

**Rationale:**
- **Pragmatic Shortcut:** `service_name` (field 4) and `custom_domain` (field 5) are marked COMPUTE-SPECIFIC in the proto and conceptually belong in a future `x/deployment` module; they live on the generic lease item today to ship the feature without a new module. Migration path tracked as ENG-80.
- **Dual-Mode Uniqueness:** In legacy mode uniqueness is enforced on `sku_uuid` (each SKU unique per lease); in service-name mode all items must set `service_name` and uniqueness shifts to `service_name`, allowing the same SKU to appear multiple times (e.g., `web` and `db` both on `docker-small`).
- **Reverse Lookup:** `custom_domain` drives the `CustomDomainIndex` (prefix 12) for O(1) reverse lookup and uniqueness enforcement.

**Trade-offs:**
- **Multi-Item Legacy Leases Cannot Host a Custom Domain:** A multi-item lease created in legacy mode (no `service_name`) has no unambiguous way to address an item, so it is rejected from setting a `custom_domain` (`ErrAmbiguousLeaseItem`).
- **`reserved_domain_suffixes` Ships Empty:** `Params.ReservedDomainSuffixes` defaults to `nil` on purpose and `Migrate1to2` is a no-op. Once a hostname is baked into a release tag it cannot be unshipped from chains that already ran the upgrade, so operators seed provider wildcard zones via genesis or post-upgrade `MsgUpdateParams` instead. (ENG-82 tracks provider-declared zones in `x/sku`.)

## Future Considerations

### Potential Future Enhancements

1. **Lease Pruning:** Archive old leases to reduce state size
2. **Tiered Pricing:** Volume discounts based on usage
3. **Grace Period:** Short overdraw allowance
4. **Credit Withdrawal:** Allow extracting unused credits
5. **Batch Operations:** Bulk lease creation
6. **Scheduled Closure:** Lease with end date
7. **Usage Reports:** Periodic settlement with receipts
8. **Multi-Provider Leases:** Items from different providers
9. **Credit Transfers:** Move credits between accounts
10. **Provider Disputes:** On-chain dispute resolution
11. **Provider Response Metrics:** Track acknowledgement times

### Known Limitations

1. **No Partial Credit Withdrawal:** Credits locked until spent
2. **No Dispute Mechanism:** Trust-based provider relationship  
3. **No Grace Period:** Immediate closure on exhaustion
4. **No Lease Modification:** Cannot add/remove items after creation
5. **Linear Provider Withdraw:** O(n) for many leases (capped at 100)
6. **Single Provider Per Lease:** Cannot mix providers in one lease
7. **Lease Queries Return Stored State:** `Lease`, `Leases`, etc. return stored `last_settled_at` (use `WithdrawableAmount` for real-time)
8. **No Denom Conversion:** Must fund credit with exact denoms required by target SKUs
9. **PENDING Lease Timeout:** Fixed timeout for all providers (governance parameter)
10. **Closed Lease State Bloat:** Soft-deleted leases (CLOSED, REJECTED, EXPIRED) remain in state indefinitely. High-volume deployments will accumulate state over time. See "Lease Pruning" in Future Considerations for the planned mitigation.
11. **No SKU Deactivation Cascade to Billing:** Deactivating a provider or SKU in the SKU module does not automatically close active leases in the billing module. Existing leases continue at their locked prices until explicitly closed or credit is exhausted. This is intentional — tenants should not lose running services due to provider-side changes.
12. **No Credit Withdrawal:** Tenants cannot withdraw unused credits from their credit account. Credits are locked until consumed by leases. This prevents gaming (deposit to block, withdraw immediately) and simplifies the accounting model. See "Credit Withdrawal" in Future Considerations for the planned enhancement.

### Migration Considerations

When implementing breaking changes:
- Preserve credit account balances
- Maintain lease history
- Update indexes atomically
- Version proto messages appropriately
- Handle PENDING leases during upgrade (either expire or migrate to new state)
- For the v2→v3→v4 reservation cutover, do not settle or mint implicitly:
  v2→v3 repairs byte identity, counts, and the provable aggregate floor;
  v3→v4 preserves a tenant's complete modern PENDING cohort only when every
  denomination is bank-backed, otherwise expires the whole cohort, and then
  distributes the remaining bank-backed historical budget across ACTIVE and
  historical claims with deterministic Hamilton allocation, recording the
  exact historical cohort size for O(1) terminal release.
- Preflight every tenant/denomination before v4. A repaired aggregate below the
  complete PENDING nominal sum is corruption and fails closed. A bank-only
  shortfall is reachable under v2 and deterministically expires every modern
  PENDING lease for that tenant; identify the affected clients before cutover.

## Related Documentation

- [README](../README.md) - Module overview
- [API Reference](API.md) - CLI and gRPC/REST API
- [Architecture](ARCHITECTURE.md) - Technical architecture details
- [Capabilities](CAPABILITIES.md) - Feature overview and roadmap
- [Comparison](COMPARISON.md) - Comparison with Akash and architectural trade-offs
- [Migration Guide](MIGRATION.md) - Migrating off-chain leases
- [Troubleshooting](TROUBLESHOOTING.md) - Common issues and solutions
- [SKU Module Design Decisions](../../sku/docs/DESIGN_DECISIONS.md) - Related SKU design choices
