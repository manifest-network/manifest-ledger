/*
Package keeper_test contains unit tests for the billing module message server.

Test Coverage:
- MsgFundCredit: funding credit accounts, denom validation, balance tracking
- MsgUpdateParams: parameter updates, authority validation
- MsgCreateLease: lease creation with SKU validation, credit checks, max lease limits
- MsgCreateLeaseForTenant: authority-only lease creation on behalf of tenants
- MsgAcknowledgeLease: provider acknowledgement of pending leases
- MsgCloseLease: lease closure by tenant, provider, or authority
- MsgWithdraw: provider withdrawal from specific leases or all provider's leases

NOTE: With the new lease lifecycle (PENDING -> ACTIVE), tests that need an ACTIVE
lease must call createAndAcknowledgeLease helper instead of just CreateLease.
*/
package keeper_test

import (
	"fmt"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/require"

	"cosmossdk.io/collections"
	errorsmod "cosmossdk.io/errors"
	sdkmath "cosmossdk.io/math"

	sdk "github.com/cosmos/cosmos-sdk/types"

	"github.com/manifest-network/manifest-ledger/x/billing/keeper"
	"github.com/manifest-network/manifest-ledger/x/billing/types"
	skutypes "github.com/manifest-network/manifest-ledger/x/sku/types"
)

// createAndAcknowledgeLease is a helper that creates a lease and acknowledges it,
// returning the lease in ACTIVE state ready for testing.
func (f *testFixture) createAndAcknowledgeLease(
	t *testing.T,
	msgServer types.MsgServer,
	tenant sdk.AccAddress,
	providerAddr sdk.AccAddress,
	items []types.LeaseItemInput,
) string {
	t.Helper()

	// Create the lease
	createResp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  items,
	})
	require.NoError(t, err)
	require.NotNil(t, createResp)

	// Acknowledge the lease as the provider
	ackResp, err := msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
		Sender:     providerAddr.String(),
		LeaseUuids: []string{createResp.LeaseUuid},
	})
	require.NoError(t, err)
	require.NotNil(t, ackResp)

	// Verify lease is now ACTIVE
	lease, err := f.App.BillingKeeper.GetLease(f.Ctx, createResp.LeaseUuid)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_ACTIVE, lease.State)

	return createResp.LeaseUuid
}

type acknowledgementTestSetup struct {
	f            *testFixture
	msgServer    types.MsgServer
	tenants      []sdk.AccAddress
	providerAddr sdk.AccAddress
	skuUUID      string
}

func newAcknowledgementTestSetup(
	t *testing.T,
	tenantCount int,
	configureParams func(*types.Params),
) *acknowledgementTestSetup {
	t.Helper()

	f := initFixture(t)
	params, err := f.App.BillingKeeper.GetParams(f.Ctx)
	require.NoError(t, err)
	configureParams(&params)
	require.NoError(t, f.App.BillingKeeper.SetParams(f.Ctx, params))

	providerAddr := f.TestAccs[tenantCount]
	payoutAddr := f.TestAccs[tenantCount+1]
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	tenants := f.TestAccs[:tenantCount]
	for _, tenant := range tenants {
		creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
		require.NoError(t, err)
		f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(testDenom, sdkmath.NewInt(1_000_000_000))))
		require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
			Tenant:        tenant.String(),
			CreditAddress: creditAddr.String(),
		}))
	}

	return &acknowledgementTestSetup{
		f:            f,
		msgServer:    keeper.NewMsgServerImpl(f.App.BillingKeeper),
		tenants:      tenants,
		providerAddr: providerAddr,
		skuUUID:      sku.Uuid,
	}
}

func (s *acknowledgementTestSetup) createPendingLease(t *testing.T, tenant sdk.AccAddress) string {
	t.Helper()

	resp, err := s.msgServer.CreateLease(s.f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: s.skuUUID, Quantity: 1}},
	})
	require.NoError(t, err)
	require.NotNil(t, resp)

	return resp.LeaseUuid
}

func TestMsgFundCredit(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	sender := f.TestAccs[0]
	tenant := f.TestAccs[1]
	denom := testDenom

	// Fund sender with tokens
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, sender, sdk.NewCoins(fundAmount))

	tests := []struct {
		name      string
		msg       *types.MsgFundCredit
		expectErr bool
		errMsg    string
	}{
		{
			name: "success: fund credit account",
			msg: &types.MsgFundCredit{
				Sender: sender.String(),
				Tenant: tenant.String(),
				Amount: sdk.NewCoin(denom, sdkmath.NewInt(5000000)),
			},
			expectErr: false,
		},
		{
			name: "success: fund own credit account",
			msg: &types.MsgFundCredit{
				Sender: sender.String(),
				Tenant: sender.String(),
				Amount: sdk.NewCoin(denom, sdkmath.NewInt(1000000)),
			},
			expectErr: false,
		},
		{
			name: "fail: insufficient balance - wrong denom",
			msg: &types.MsgFundCredit{
				Sender: sender.String(),
				Tenant: tenant.String(),
				Amount: sdk.NewCoin("wrongdenom", sdkmath.NewInt(1000000)),
			},
			expectErr: true,
			errMsg:    "insufficient funds", // No module-level denom restriction anymore; fails due to insufficient balance
		},
		{
			name: "fail: insufficient balance",
			msg: &types.MsgFundCredit{
				Sender: sender.String(),
				Tenant: tenant.String(),
				Amount: sdk.NewCoin(denom, sdkmath.NewInt(100000000000)), // Way more than funded
			},
			expectErr: true,
			errMsg:    "failed to transfer tokens",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			resp, err := msgServer.FundCredit(f.Ctx, tc.msg)
			if tc.expectErr {
				require.Error(t, err)
				require.Contains(t, err.Error(), tc.errMsg)
				require.Nil(t, resp)
			} else {
				require.NoError(t, err)
				require.NotNil(t, resp)
				require.NotEmpty(t, resp.CreditAddress)
				require.Equal(t, tc.msg.Amount.Denom, resp.NewBalance.Denom)
			}
		})
	}
}

func TestMsgFundCreditCreatesAccount(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	sender := f.TestAccs[0]
	tenant := f.TestAccs[1]
	denom := testDenom

	// Fund sender with tokens
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, sender, sdk.NewCoins(fundAmount))

	// Verify credit account doesn't exist
	_, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.ErrorIs(t, err, types.ErrCreditAccountNotFound)

	// Fund credit account
	msg := &types.MsgFundCredit{
		Sender: sender.String(),
		Tenant: tenant.String(),
		Amount: sdk.NewCoin(denom, sdkmath.NewInt(5000000)),
	}
	resp, err := msgServer.FundCredit(f.Ctx, msg)
	require.NoError(t, err)
	require.NotNil(t, resp)

	// Verify credit account was created
	ca, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, tenant.String(), ca.Tenant)
	require.Equal(t, resp.CreditAddress, ca.CreditAddress)

	// Verify the balance is tracked in bank module
	creditAddr, err := sdk.AccAddressFromBech32(resp.CreditAddress)
	require.NoError(t, err)
	balance := f.App.BankKeeper.GetBalance(f.Ctx, creditAddr, denom)
	require.Equal(t, msg.Amount, balance)

	// Verify the credit address account exists in the account keeper
	acc := f.App.AccountKeeper.GetAccount(f.Ctx, creditAddr)
	require.NotNil(t, acc)
}

func TestMsgFundCreditAdditionalFunding(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	sender := f.TestAccs[0]
	tenant := f.TestAccs[1]
	denom := testDenom

	// Fund sender with tokens
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, sender, sdk.NewCoins(fundAmount))

	// First funding
	firstAmount := sdk.NewCoin(denom, sdkmath.NewInt(3000000))
	resp1, err := msgServer.FundCredit(f.Ctx, &types.MsgFundCredit{
		Sender: sender.String(),
		Tenant: tenant.String(),
		Amount: firstAmount,
	})
	require.NoError(t, err)
	require.Equal(t, firstAmount, resp1.NewBalance)

	// Second funding
	secondAmount := sdk.NewCoin(denom, sdkmath.NewInt(2000000))
	resp2, err := msgServer.FundCredit(f.Ctx, &types.MsgFundCredit{
		Sender: sender.String(),
		Tenant: tenant.String(),
		Amount: secondAmount,
	})
	require.NoError(t, err)

	// New balance should be sum of both fundings
	expectedBalance := firstAmount.Add(secondAmount)
	require.Equal(t, expectedBalance, resp2.NewBalance)

	// Verify balance in bank module
	creditAddr, err := sdk.AccAddressFromBech32(resp2.CreditAddress)
	require.NoError(t, err)
	balance := f.App.BankKeeper.GetBalance(f.Ctx, creditAddr, denom)
	require.Equal(t, expectedBalance, balance)
}

func TestMsgFundCreditEvents(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	sender := f.TestAccs[0]
	tenant := f.TestAccs[1]
	denom := testDenom

	// Fund sender with tokens
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, sender, sdk.NewCoins(fundAmount))

	// Fund credit account
	_, err := msgServer.FundCredit(f.Ctx, &types.MsgFundCredit{
		Sender: strings.ToUpper(sender.String()),
		Tenant: strings.ToUpper(tenant.String()),
		Amount: sdk.NewCoin(denom, sdkmath.NewInt(5000000)),
	})
	require.NoError(t, err)

	// Equivalent uppercase wire spellings must not leak into address-valued
	// attributes: indexers should see one stable identity for each account.
	event := findEvent(t, f.Ctx, types.EventTypeCreditFunded)
	require.Equal(t, tenant.String(), attrValue(t, event, types.AttributeKeyTenant))
	require.Equal(t, sender.String(), attrValue(t, event, types.AttributeKeySender))
	require.Contains(t, attrValue(t, event, types.AttributeKeyAmount), denom)
}

func TestMsgUpdateParams(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	authority := f.Authority
	nonAuthority := f.TestAccs[0]

	tests := []struct {
		name      string
		msg       *types.MsgUpdateParams
		expectErr bool
		errMsg    string
	}{
		{
			name: "success: update params",
			msg: &types.MsgUpdateParams{
				Authority: authority.String(),
				Params: types.NewParams(
					50,
					[]string{},
					20,
					3600,
					10,
					1800,
				),
			},
			expectErr: false,
		},
		{
			name: "success: all-uppercase authority alias",
			msg: &types.MsgUpdateParams{
				Authority: strings.ToUpper(authority.String()),
				Params:    types.DefaultParams(),
			},
			expectErr: false,
		},
		{
			name: "fail: non-authority",
			msg: &types.MsgUpdateParams{
				Authority: nonAuthority.String(),
				Params:    types.DefaultParams(),
			},
			expectErr: true,
			errMsg:    "unauthorized",
		},
		{
			name: "fail: invalid params - zero max leases",
			msg: &types.MsgUpdateParams{
				Authority: authority.String(),
				Params: types.NewParams(
					0, // invalid: zero max leases
					[]string{},
					20,
					3600,
					10,
					1800,
				),
			},
			expectErr: true,
			errMsg:    "max_leases_per_tenant must be greater than zero",
		},
		{
			name: "fail: max_leases_per_tenant exceeds upper bound",
			msg: &types.MsgUpdateParams{
				Authority: authority.String(),
				Params: types.NewParams(
					types.MaxLeasesPerTenantUpperBound+1,
					[]string{},
					20,
					3600,
					10,
					1800,
				),
			},
			expectErr: true,
			errMsg:    "exceeds upper bound",
		},
		{
			name: "fail: min_lease_duration exceeds upper bound",
			msg: &types.MsgUpdateParams{
				Authority: authority.String(),
				Params: types.NewParams(
					100,
					[]string{},
					20,
					types.MaxMinLeaseDuration+1,
					10,
					1800,
				),
			},
			expectErr: true,
			errMsg:    "exceeds upper bound",
		},
		{
			name: "fail: max_pending_leases_per_tenant exceeds upper bound",
			msg: &types.MsgUpdateParams{
				Authority: authority.String(),
				Params: types.NewParams(
					100,
					[]string{},
					20,
					3600,
					types.MaxPendingLeasesPerTenantUpperBound+1,
					1800,
				),
			},
			expectErr: true,
			errMsg:    "exceeds upper bound",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			resp, err := msgServer.UpdateParams(f.Ctx, tc.msg)
			if tc.expectErr {
				require.Error(t, err)
				require.Contains(t, err.Error(), tc.errMsg)
				require.Nil(t, resp)
			} else {
				require.NoError(t, err)
				require.NotNil(t, resp)

				// Verify params were updated
				params, err := f.App.BillingKeeper.GetParams(f.Ctx)
				require.NoError(t, err)
				require.Equal(t, tc.msg.Params.MaxLeasesPerTenant, params.MaxLeasesPerTenant)
			}
		})
	}
}

func TestMsgUpdateParamsEvents(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	authority := f.Authority

	_, err := msgServer.UpdateParams(f.Ctx, &types.MsgUpdateParams{
		Authority: authority.String(),
		Params:    types.DefaultParams(),
	})
	require.NoError(t, err)

	// Check events
	events := f.Ctx.EventManager().Events()
	foundParamsUpdatedEvent := false
	for _, event := range events {
		if event.Type == types.EventTypeParamsUpdated {
			foundParamsUpdatedEvent = true
		}
	}
	require.True(t, foundParamsUpdatedEvent, "params_updated event should be emitted")
}

func TestMsgCreateLease(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	// Create credit account
	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	tests := []struct {
		name      string
		msg       *types.MsgCreateLease
		expectErr bool
		errMsg    string
	}{
		{
			name: "success: create lease",
			msg: &types.MsgCreateLease{
				Tenant: tenant.String(),
				Items: []types.LeaseItemInput{
					{
						SkuUuid:  sku.Uuid,
						Quantity: 2,
					},
				},
			},
			expectErr: false,
		},
		{
			name: "fail: SKU not found",
			msg: &types.MsgCreateLease{
				Tenant: tenant.String(),
				Items: []types.LeaseItemInput{
					{
						SkuUuid:  "01912345-6789-7abc-8def-999999999999",
						Quantity: 1,
					},
				},
			},
			expectErr: true,
			errMsg:    "sku not found",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			resp, err := msgServer.CreateLease(f.Ctx, tc.msg)
			if tc.expectErr {
				require.Error(t, err)
				require.Contains(t, err.Error(), tc.errMsg)
				require.Nil(t, resp)
			} else {
				require.NoError(t, err)
				require.NotNil(t, resp)
				require.NotEmpty(t, resp.LeaseUuid)

				// Verify lease was created in PENDING state (awaiting provider acknowledgement)
				lease, err := f.App.BillingKeeper.GetLease(f.Ctx, resp.LeaseUuid)
				require.NoError(t, err)
				require.Equal(t, tc.msg.Tenant, lease.Tenant)
				require.Equal(t, provider.Uuid, lease.ProviderUuid)
				require.Equal(t, types.LEASE_STATE_PENDING, lease.State)
				require.Len(t, lease.Items, len(tc.msg.Items))
			}
		})
	}
}

func TestMsgCreateLease_ArithmeticOverflowReturnsModuleErrorWithoutState(t *testing.T) {
	f := initFixture(t)
	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)
	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	provider := f.createTestProvider(t, providerAddr.String(), providerAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Use the largest valid hourly price divisible by 3600. Conversion remains
	// valid, but multiplying the resulting per-second rate by MaxQuantityPerItem
	// exceeds math.Int's 256-bit representation.
	perSecond := maxBillingTestInt().QuoRaw(3600)
	basePriceAmount, err := perSecond.SafeMul(sdkmath.NewInt(3600))
	require.NoError(t, err)
	sku.BasePrice = sdk.NewCoin(testDenom, basePriceAmount)
	require.NoError(t, f.App.SKUKeeper.SetSKU(f.Ctx, sku))

	creditAddr := types.DeriveCreditAddress(tenant)
	f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(testDenom, sdkmath.OneInt())))
	require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	}))

	var resp *types.MsgCreateLeaseResponse
	require.NotPanics(t, func() {
		resp, err = msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{{
				SkuUuid:  sku.Uuid,
				Quantity: types.MaxQuantityPerItem,
			}},
		})
	})
	require.Nil(t, resp)
	require.ErrorIs(t, err, types.ErrArithmeticOverflow)
	codespace, code, _ := errorsmod.ABCIInfo(err, false)
	require.Equal(t, types.ModuleName, codespace)
	require.Equal(t, uint32(20), code)

	leases, getErr := f.App.BillingKeeper.GetAllLeases(f.Ctx)
	require.NoError(t, getErr)
	require.Empty(t, leases)
	account, getErr := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, getErr)
	require.True(t, account.ReservedAmounts.IsZero())
}

func TestMsgCreateLeaseRejectsReservedDenomCardinalityGrowth(t *testing.T) {
	f := initFixture(t)
	k := f.App.BillingKeeper
	msgServer := keeper.NewMsgServerImpl(k)
	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	provider := f.createTestProvider(t, providerAddr.String(), providerAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)
	creditAddr := types.DeriveCreditAddress(tenant)

	existing := make([]sdk.Coin, 0, types.MaxReservedDenomsPerCreditAccount)
	for index := range types.MaxReservedDenomsPerCreditAccount {
		existing = append(existing, sdk.NewInt64Coin(fmt.Sprintf("a%04d", index), 1))
	}
	reserved := sdk.NewCoins(existing...)
	require.NoError(t, k.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:          tenant.String(),
		CreditAddress:   creditAddr.String(),
		ReservedAmounts: reserved,
	}))
	f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewInt64Coin(testDenom, 1_000_000)))

	_, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.ErrorIs(t, err, types.ErrReservationDenomLimitExceeded)

	account, err := k.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, reserved, account.ReservedAmounts)
	require.Zero(t, account.PendingLeaseCount)
}

func TestMsgCreateLeaseInsufficientCredit(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 100)

	// Do NOT fund the tenant - they should have no credit account
	msg := &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items: []types.LeaseItemInput{
			{
				SkuUuid:  sku.Uuid,
				Quantity: 1,
			},
		},
	}

	resp, err := msgServer.CreateLease(f.Ctx, msg)
	require.Error(t, err)
	require.Contains(t, err.Error(), "credit account not found")
	require.Nil(t, resp)
}

func TestMsgCreateLeaseMaxLeasesReached(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Set max pending leases to 2 (leases start in PENDING state)
	params := types.DefaultParams()
	params.MaxPendingLeasesPerTenant = 2
	err := f.App.BillingKeeper.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create max number of pending leases
	for i := 0; i < 2; i++ {
		msg := &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{
					SkuUuid:  sku.Uuid,
					Quantity: 1,
				},
			},
		}
		_, err := msgServer.CreateLease(f.Ctx, msg)
		require.NoError(t, err)
	}

	// Try to create one more - should fail (max pending leases reached)
	msg := &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items: []types.LeaseItemInput{
			{
				SkuUuid:  sku.Uuid,
				Quantity: 1,
			},
		},
	}
	resp, err := msgServer.CreateLease(f.Ctx, msg)
	require.Error(t, err)
	require.Contains(t, err.Error(), "maximum pending leases per tenant reached")
	require.Nil(t, resp)
}

func TestMsgCreateLeaseWithMetaHash(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a SHA-256 hash (32 bytes) as meta_hash
	metaHash := []byte{
		0xa1, 0xb2, 0xc3, 0xd4, 0xe5, 0xf6, 0x01, 0x12,
		0x23, 0x34, 0x45, 0x56, 0x67, 0x78, 0x89, 0x9a,
		0xab, 0xbc, 0xcd, 0xde, 0xef, 0xf0, 0x01, 0x12,
		0x23, 0x34, 0x45, 0x56, 0x67, 0x78, 0x89, 0x9a,
	}

	t.Run("success: create lease with meta_hash", func(t *testing.T) {
		msg := &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{
					SkuUuid:  sku.Uuid,
					Quantity: 1,
				},
			},
			MetaHash: metaHash,
		}

		resp, err := msgServer.CreateLease(f.Ctx, msg)
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.NotEmpty(t, resp.LeaseUuid)

		// Verify meta_hash was stored
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, resp.LeaseUuid)
		require.NoError(t, err)
		require.Equal(t, metaHash, lease.MetaHash)
	})

	t.Run("success: create lease without meta_hash", func(t *testing.T) {
		msg := &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{
					SkuUuid:  sku.Uuid,
					Quantity: 1,
				},
			},
			// MetaHash not set - should be nil/empty
		}

		resp, err := msgServer.CreateLease(f.Ctx, msg)
		require.NoError(t, err)
		require.NotNil(t, resp)

		// Verify meta_hash is empty
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, resp.LeaseUuid)
		require.NoError(t, err)
		require.Empty(t, lease.MetaHash)
	})

	t.Run("success: create lease with max length meta_hash", func(t *testing.T) {
		maxMetaHash := make([]byte, types.MaxMetaHashLength)
		for i := range maxMetaHash {
			maxMetaHash[i] = byte(i)
		}

		msg := &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{
					SkuUuid:  sku.Uuid,
					Quantity: 1,
				},
			},
			MetaHash: maxMetaHash,
		}

		resp, err := msgServer.CreateLease(f.Ctx, msg)
		require.NoError(t, err)
		require.NotNil(t, resp)

		// Verify max length meta_hash was stored
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, resp.LeaseUuid)
		require.NoError(t, err)
		require.Equal(t, maxMetaHash, lease.MetaHash)
	})
}

func TestMsgCreateLeaseForTenantWithMetaHash(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	authority := f.App.BillingKeeper.GetAuthority()
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	metaHash := []byte{0xde, 0xad, 0xbe, 0xef, 0xca, 0xfe, 0xba, 0xbe}

	t.Run("success: authority creates lease with meta_hash", func(t *testing.T) {
		msg := &types.MsgCreateLeaseForTenant{
			Authority: authority,
			Tenant:    tenant.String(),
			Items: []types.LeaseItemInput{
				{
					SkuUuid:  sku.Uuid,
					Quantity: 1,
				},
			},
			MetaHash: metaHash,
		}

		resp, err := msgServer.CreateLeaseForTenant(f.Ctx, msg)
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.NotEmpty(t, resp.LeaseUuid)

		// Verify meta_hash was stored
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, resp.LeaseUuid)
		require.NoError(t, err)
		require.Equal(t, metaHash, lease.MetaHash)
	})
}

func TestMsgCreateLeaseForTenant(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	nonAuthority := f.TestAccs[3]
	authority := f.App.BillingKeeper.GetAuthority()
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	// Create credit account
	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	tests := []struct {
		name      string
		msg       *types.MsgCreateLeaseForTenant
		expectErr bool
		errMsg    string
	}{
		{
			name: "success: authority creates lease for tenant",
			msg: &types.MsgCreateLeaseForTenant{
				Authority: authority,
				Tenant:    tenant.String(),
				Items: []types.LeaseItemInput{
					{
						SkuUuid:  sku.Uuid,
						Quantity: 2,
					},
				},
			},
			expectErr: false,
		},
		{
			name: "fail: non-authority creates lease",
			msg: &types.MsgCreateLeaseForTenant{
				Authority: nonAuthority.String(),
				Tenant:    tenant.String(),
				Items: []types.LeaseItemInput{
					{
						SkuUuid:  sku.Uuid,
						Quantity: 1,
					},
				},
			},
			expectErr: true,
			errMsg:    "unauthorized",
		},
		{
			name: "fail: SKU not found",
			msg: &types.MsgCreateLeaseForTenant{
				Authority: authority,
				Tenant:    tenant.String(),
				Items: []types.LeaseItemInput{
					{
						SkuUuid:  "01912345-6789-7abc-8def-999999999999",
						Quantity: 1,
					},
				},
			},
			expectErr: true,
			errMsg:    "sku not found",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			resp, err := msgServer.CreateLeaseForTenant(f.Ctx, tc.msg)
			if tc.expectErr {
				require.Error(t, err)
				require.Contains(t, err.Error(), tc.errMsg)
				require.Nil(t, resp)
			} else {
				require.NoError(t, err)
				require.NotNil(t, resp)
				require.NotEmpty(t, resp.LeaseUuid)

				// Verify lease was created
				lease, err := f.App.BillingKeeper.GetLease(f.Ctx, resp.LeaseUuid)
				require.NoError(t, err)
				require.Equal(t, tc.msg.Tenant, lease.Tenant)
				require.Equal(t, provider.Uuid, lease.ProviderUuid)
				require.Equal(t, types.LEASE_STATE_PENDING, lease.State) // Leases start in PENDING state
				require.Len(t, lease.Items, len(tc.msg.Items))
			}
		})
	}
}

func TestMsgCreateLeaseForTenantWithAllowedList(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	allowedUser := f.TestAccs[3]
	notAllowed := f.TestAccs[4]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	// Create credit account
	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Update params to add allowedUser to allowed list
	params := types.NewParams(
		types.DefaultMaxLeasesPerTenant,
		[]string{allowedUser.String()},
		types.DefaultMaxItemsPerLease,
		types.DefaultMinLeaseDuration,
		types.DefaultMaxPendingLeasesPerTenant,
		types.DefaultPendingTimeout,
	)
	err = f.App.BillingKeeper.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Test: allowed user can create lease for tenant
	resp, err := msgServer.CreateLeaseForTenant(f.Ctx, &types.MsgCreateLeaseForTenant{
		Authority: allowedUser.String(),
		Tenant:    tenant.String(),
		Items: []types.LeaseItemInput{
			{
				SkuUuid:  sku.Uuid,
				Quantity: 1,
			},
		},
	})
	require.NoError(t, err)
	require.NotNil(t, resp)
	require.NotEmpty(t, resp.LeaseUuid)

	// Test: non-allowed user cannot create lease for tenant
	_, err = msgServer.CreateLeaseForTenant(f.Ctx, &types.MsgCreateLeaseForTenant{
		Authority: notAllowed.String(),
		Tenant:    tenant.String(),
		Items: []types.LeaseItemInput{
			{
				SkuUuid:  sku.Uuid,
				Quantity: 1,
			},
		},
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "not the authority or in the allowed list")
}

func TestMsgCloseLease(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease and acknowledge it
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{
			SkuUuid:  sku.Uuid,
			Quantity: 1,
		},
	})

	tests := []struct {
		name      string
		msg       *types.MsgCloseLease
		expectErr bool
		errMsg    string
	}{
		{
			name: "success: tenant closes lease",
			msg: &types.MsgCloseLease{
				Sender:     tenant.String(),
				LeaseUuids: []string{leaseID},
			},
			expectErr: false,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			resp, err := msgServer.CloseLease(f.Ctx, tc.msg)
			if tc.expectErr {
				require.Error(t, err)
				require.Contains(t, err.Error(), tc.errMsg)
				require.Nil(t, resp)
			} else {
				require.NoError(t, err)
				require.NotNil(t, resp)
				require.Equal(t, uint64(1), resp.ClosedCount)

				// Verify lease is now inactive
				lease, err := f.App.BillingKeeper.GetLease(f.Ctx, tc.msg.LeaseUuids[0])
				require.NoError(t, err)
				require.Equal(t, types.LEASE_STATE_CLOSED, lease.State)
				require.NotNil(t, lease.ClosedAt)
			}
		})
	}
}

func TestMsgCloseLeaseUnauthorized(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	randomAddr := f.TestAccs[3]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease and acknowledge it
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{
			SkuUuid:  sku.Uuid,
			Quantity: 1,
		},
	})

	// Try to close with random address
	resp, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
		Sender:     randomAddr.String(),
		LeaseUuids: []string{leaseID},
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "unauthorized")
	require.Nil(t, resp)
}

func TestMsgWithdraw(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU with 1 unit per second rate
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	// Fund tenant's credit account generously
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease and acknowledge it
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{
			SkuUuid:  sku.Uuid,
			Quantity: 1,
		},
	})

	// Advance block time by 100 seconds
	newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
	f.Ctx = newCtx

	// Provider withdraws
	resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
		Sender:     providerAddr.String(),
		LeaseUuids: []string{leaseID},
	})
	require.NoError(t, err)
	require.NotNil(t, resp)
	require.Equal(t, payoutAddr.String(), resp.PayoutAddress)
	require.False(t, resp.TotalAmounts.IsZero())
	require.Equal(t, uint64(1), resp.WithdrawalCount)

	// Verify payout address received funds
	payoutBalance := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom)
	require.True(t, payoutBalance.Amount.IsPositive())
}

func TestMsgWithdraw_RejectsPayoutToTenantCreditAddressWithoutStateChange(t *testing.T) {
	f := initFixture(t)
	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	creditAddr := types.DeriveCreditAddress(tenant)
	// Use an equivalent uppercase Bech32 spelling to pin byte-identity comparison
	// through the SDK parser rather than raw string equality.
	payoutAddress := strings.ToUpper(creditAddr.String())
	require.NotEqual(t, creditAddr.String(), payoutAddress)
	decodedPayout, err := sdk.AccAddressFromBech32(payoutAddress)
	require.NoError(t, err)
	require.True(t, decodedPayout.Equals(creditAddr))
	provider := f.createTestProvider(t, providerAddr.String(), providerAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	initialBalance := sdk.NewCoin(testDenom, sdkmath.NewInt(100_000_000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(initialBalance))
	require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	}))

	leaseUUID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{{
		SkuUuid:  sku.Uuid,
		Quantity: 1,
	}})
	// Model a payout changed after activation; admission and acknowledgement
	// now reject self-payout before an ACTIVE lease can be created.
	provider.PayoutAddress = payoutAddress
	require.NoError(t, f.App.SKUKeeper.SetProvider(f.Ctx, provider))
	leaseBefore, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseUUID)
	require.NoError(t, err)

	f.Ctx = f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second)).
		WithEventManager(sdk.NewEventManager())
	resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
		Sender:     providerAddr.String(),
		LeaseUuids: []string{leaseUUID},
	})
	require.ErrorIs(t, err, types.ErrInvalidCreditOperation)
	require.Nil(t, resp)

	require.Equal(t, initialBalance, f.App.BankKeeper.GetBalance(f.Ctx, creditAddr, testDenom))
	leaseAfter, getErr := f.App.BillingKeeper.GetLease(f.Ctx, leaseUUID)
	require.NoError(t, getErr)
	require.Equal(t, leaseBefore.LastSettledAt, leaseAfter.LastSettledAt)
	for _, event := range f.Ctx.EventManager().Events() {
		require.NotEqual(t, types.EventTypeProviderWithdraw, event.Type)
		require.NotEqual(t, types.EventTypeBatchWithdraw, event.Type)
	}
}

type selfPayoutBatchFixture struct {
	f                 *testFixture
	msgServer         types.MsgServer
	providerAddr      sdk.AccAddress
	normalTenant      sdk.AccAddress
	selfPayoutTenant  sdk.AccAddress
	normalCreditAddr  sdk.AccAddress
	selfCreditAddr    sdk.AccAddress
	normalLeaseUUID   string
	selfLeaseUUID     string
	initialCreditCoin sdk.Coin
}

func newSelfPayoutBatchFixture(t *testing.T) *selfPayoutBatchFixture {
	t.Helper()
	f := initFixture(t)
	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)
	normalTenant := f.TestAccs[0]
	selfPayoutTenant := f.TestAccs[1]
	providerAddr := f.TestAccs[2]
	normalCreditAddr := types.DeriveCreditAddress(normalTenant)
	selfCreditAddr := types.DeriveCreditAddress(selfPayoutTenant)

	payoutAddress := strings.ToUpper(selfCreditAddr.String())
	require.NotEqual(t, selfCreditAddr.String(), payoutAddress)
	decodedPayout, err := sdk.AccAddressFromBech32(payoutAddress)
	require.NoError(t, err)
	require.True(t, decodedPayout.Equals(selfCreditAddr))
	provider := f.createTestProvider(t, providerAddr.String(), providerAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	initialCreditCoin := sdk.NewCoin(testDenom, sdkmath.NewInt(100_000_000))
	accounts := [...]struct {
		tenant     sdk.AccAddress
		creditAddr sdk.AccAddress
	}{
		{tenant: normalTenant, creditAddr: normalCreditAddr},
		{tenant: selfPayoutTenant, creditAddr: selfCreditAddr},
	}
	for _, account := range accounts {
		f.fundAccount(t, account.creditAddr, sdk.NewCoins(initialCreditCoin))
		require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
			Tenant:        account.tenant.String(),
			CreditAddress: account.creditAddr.String(),
		}))
	}

	normalLeaseUUID := f.createAndAcknowledgeLease(t, msgServer, normalTenant, providerAddr, []types.LeaseItemInput{{
		SkuUuid:  sku.Uuid,
		Quantity: 1,
	}})
	selfLeaseUUID := f.createAndAcknowledgeLease(t, msgServer, selfPayoutTenant, providerAddr, []types.LeaseItemInput{{
		SkuUuid:  sku.Uuid,
		Quantity: 1,
	}})
	// Settlement must still defend against provider changes after activation.
	provider.PayoutAddress = payoutAddress
	require.NoError(t, f.App.SKUKeeper.SetProvider(f.Ctx, provider))

	return &selfPayoutBatchFixture{
		f:                 f,
		msgServer:         msgServer,
		providerAddr:      providerAddr,
		normalTenant:      normalTenant,
		selfPayoutTenant:  selfPayoutTenant,
		normalCreditAddr:  normalCreditAddr,
		selfCreditAddr:    selfCreditAddr,
		normalLeaseUUID:   normalLeaseUUID,
		selfLeaseUUID:     selfLeaseUUID,
		initialCreditCoin: initialCreditCoin,
	}
}

func TestMsgWithdraw_SpecificBatchSelfPayoutRollsBackEarlierLease(t *testing.T) {
	s := newSelfPayoutBatchFixture(t)
	normalLeaseBefore, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.normalLeaseUUID)
	require.NoError(t, err)
	selfLeaseBefore, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.selfLeaseUUID)
	require.NoError(t, err)

	s.f.Ctx = s.f.Ctx.WithBlockTime(s.f.Ctx.BlockTime().Add(100 * time.Second)).
		WithEventManager(sdk.NewEventManager())
	resp, err := s.msgServer.Withdraw(s.f.Ctx, &types.MsgWithdraw{
		Sender: s.providerAddr.String(),
		// The normal lease transfers first inside the batch cache. The self-payout
		// lease must reject second and discard that earlier transfer as well.
		LeaseUuids: []string{s.normalLeaseUUID, s.selfLeaseUUID},
	})
	require.ErrorIs(t, err, types.ErrInvalidCreditOperation)
	require.Nil(t, resp)

	require.Equal(t, s.initialCreditCoin, s.f.App.BankKeeper.GetBalance(s.f.Ctx, s.normalCreditAddr, testDenom))
	require.Equal(t, s.initialCreditCoin, s.f.App.BankKeeper.GetBalance(s.f.Ctx, s.selfCreditAddr, testDenom))
	normalLeaseAfter, getErr := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.normalLeaseUUID)
	require.NoError(t, getErr)
	selfLeaseAfter, getErr := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.selfLeaseUUID)
	require.NoError(t, getErr)
	require.Equal(t, normalLeaseBefore.LastSettledAt, normalLeaseAfter.LastSettledAt)
	require.Equal(t, selfLeaseBefore.LastSettledAt, selfLeaseAfter.LastSettledAt)
	require.Empty(t, s.f.Ctx.EventManager().Events())
}

func TestMsgCloseLease_BatchSelfPayoutRollsBackEarlierLease(t *testing.T) {
	s := newSelfPayoutBatchFixture(t)
	normalLeaseBefore, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.normalLeaseUUID)
	require.NoError(t, err)
	selfLeaseBefore, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.selfLeaseUUID)
	require.NoError(t, err)
	normalAccountBefore, err := s.f.App.BillingKeeper.GetCreditAccount(s.f.Ctx, s.normalTenant.String())
	require.NoError(t, err)
	selfAccountBefore, err := s.f.App.BillingKeeper.GetCreditAccount(s.f.Ctx, s.selfPayoutTenant.String())
	require.NoError(t, err)
	require.Equal(t, uint64(1), normalAccountBefore.ActiveLeaseCount)
	require.Equal(t, uint64(1), selfAccountBefore.ActiveLeaseCount)
	require.False(t, normalAccountBefore.ReservedAmounts.IsZero())
	require.False(t, selfAccountBefore.ReservedAmounts.IsZero())

	s.f.Ctx = s.f.Ctx.WithBlockTime(s.f.Ctx.BlockTime().Add(100 * time.Second)).
		WithEventManager(sdk.NewEventManager())
	resp, err := s.msgServer.CloseLease(s.f.Ctx, &types.MsgCloseLease{
		Sender: s.providerAddr.String(),
		// As in the withdrawal regression, make the normal lease mutate the batch
		// cache before the self-payout lease rejects.
		LeaseUuids: []string{s.normalLeaseUUID, s.selfLeaseUUID},
		Reason:     "atomic self-payout regression",
	})
	require.ErrorIs(t, err, types.ErrInvalidCreditOperation)
	require.Nil(t, resp)

	require.Equal(t, s.initialCreditCoin, s.f.App.BankKeeper.GetBalance(s.f.Ctx, s.normalCreditAddr, testDenom))
	require.Equal(t, s.initialCreditCoin, s.f.App.BankKeeper.GetBalance(s.f.Ctx, s.selfCreditAddr, testDenom))
	normalLeaseAfter, getErr := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.normalLeaseUUID)
	require.NoError(t, getErr)
	selfLeaseAfter, getErr := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.selfLeaseUUID)
	require.NoError(t, getErr)
	require.Equal(t, normalLeaseBefore, normalLeaseAfter)
	require.Equal(t, selfLeaseBefore, selfLeaseAfter)
	normalAccountAfter, getErr := s.f.App.BillingKeeper.GetCreditAccount(s.f.Ctx, s.normalTenant.String())
	require.NoError(t, getErr)
	selfAccountAfter, getErr := s.f.App.BillingKeeper.GetCreditAccount(s.f.Ctx, s.selfPayoutTenant.String())
	require.NoError(t, getErr)
	require.Equal(t, normalAccountBefore, normalAccountAfter)
	require.Equal(t, selfAccountBefore, selfAccountAfter)
	require.Empty(t, s.f.Ctx.EventManager().Events())
}

// TestMsgWithdrawBatch tests batch withdrawal operations.
func TestMsgWithdrawBatch(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 1 umfx/sec

	// Fund tenant's credit account generously
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(1000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	t.Run("success: batch withdraw from multiple leases", func(t *testing.T) {
		// Create and acknowledge 3 leases
		lease1 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})
		lease2 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})
		lease3 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		// Advance block time by 100 seconds
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
		f.Ctx = newCtx

		// Get initial balance
		initialBalance := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom)

		// Withdraw from all 3 leases in one transaction
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{lease1, lease2, lease3},
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, payoutAddr.String(), resp.PayoutAddress)
		require.Equal(t, uint64(3), resp.WithdrawalCount)
		require.False(t, resp.TotalAmounts.IsZero())

		// Verify total balance increased
		newBalance := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom)
		require.True(t, newBalance.Amount.GT(initialBalance.Amount))
	})

	t.Run("fail: mixed providers not allowed", func(t *testing.T) {
		// Create another provider
		provider2Addr := f.TestAccs[3]
		provider2 := f.createTestProvider(t, provider2Addr.String(), provider2Addr.String())
		sku2 := f.createTestSKU(t, provider2.Uuid, 3600)

		// Create lease for provider 1
		lease1 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		// Create lease for provider 2
		lease2 := f.createAndAcknowledgeLease(t, msgServer, tenant, provider2Addr, []types.LeaseItemInput{
			{SkuUuid: sku2.Uuid, Quantity: 1},
		})

		// Advance time
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
		f.Ctx = newCtx

		// Try to withdraw from both - should fail (mixed providers)
		_, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{lease1, lease2},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "all leases must belong to same provider")
	})

	t.Run("fail: duplicate UUIDs in request", func(t *testing.T) {
		lease := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		_, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{lease, lease},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "duplicate")
	})
}

// TestMsgWithdraw_ErrorCases tests error scenarios for Withdraw.
func TestMsgWithdraw_ErrorCases(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	unauthorizedUser := f.TestAccs[3]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease and acknowledge it
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{
			SkuUuid:  sku.Uuid,
			Quantity: 1,
		},
	})

	t.Run("fail: withdraw from non-existent lease", func(t *testing.T) {
		_, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{"01912345-6789-7abc-8def-999999999999"},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not found")
	})

	t.Run("fail: unauthorized user cannot withdraw", func(t *testing.T) {
		_, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:     unauthorizedUser.String(),
			LeaseUuids: []string{leaseID},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "unauthorized")
	})

	t.Run("fail: tenant cannot withdraw (not provider or authority)", func(t *testing.T) {
		_, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:     tenant.String(),
			LeaseUuids: []string{leaseID},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "unauthorized")
	})
}

// TestMsgWithdraw_PartialCreditExhaustion tests withdrawal when credit is partially exhausted.
func TestMsgWithdraw_PartialCreditExhaustion(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Set params with short min lease duration for testing
	params := types.DefaultParams()
	params.MaxLeasesPerTenant = 100
	params.MaxItemsPerLease = 20
	params.MinLeaseDuration = 10 // 10 seconds for testing
	err := f.App.BillingKeeper.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create provider and SKU with 1 unit per second rate
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	// Fund tenant's credit account with enough for minimum duration + some extra
	// Min duration is 10 seconds at 1/second = 10 units minimum
	// We fund with 50 units (enough to create lease, but less than 100 accrued)
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	limitedFund := sdk.NewCoin(denom, sdkmath.NewInt(50))
	f.fundAccount(t, creditAddr, sdk.NewCoins(limitedFund))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease and acknowledge it
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{
			SkuUuid:  sku.Uuid,
			Quantity: 1,
		},
	})

	// Advance block time by 100 seconds (should accrue 100 units, but only 50 available)
	newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
	f.Ctx = newCtx

	// Provider withdraws - should only get up to 50 (the available credit)
	resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
		Sender:     providerAddr.String(),
		LeaseUuids: []string{leaseID},
	})
	require.NoError(t, err)
	require.NotNil(t, resp)

	// Verify provider's payout address received funds
	payoutBalance := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom)
	require.True(t, payoutBalance.Amount.IsPositive(), "provider should have received some funds")
	require.True(t, payoutBalance.Amount.LTE(sdkmath.NewInt(50)), "provider should not receive more than credit balance")

	// Verify credit balance decreased
	creditBalance := f.App.BankKeeper.GetBalance(f.Ctx, creditAddr, denom)
	require.True(t, creditBalance.Amount.LT(sdkmath.NewInt(50)), "credit balance should have decreased")
}

// TestMsgWithdraw_ZeroDuration tests withdrawal with zero elapsed time.
func TestMsgWithdraw_ZeroDuration(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease
	createResp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items: []types.LeaseItemInput{
			{
				SkuUuid:  sku.Uuid,
				Quantity: 1,
			},
		},
	})
	require.NoError(t, err)

	// DO NOT advance block time - withdraw immediately
	// With zero duration, there's nothing to withdraw, so it should error
	_, err = msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
		Sender:     providerAddr.String(),
		LeaseUuids: []string{createResp.LeaseUuid},
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "no withdrawable amount")
}

// TestMsgCloseLease_WithSettlement tests lease closure with settlement.
func TestMsgCloseLease_WithSettlement(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU with 1 unit per second rate
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	// Fund tenant's credit account generously
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Get initial payout balance
	initialPayoutBalance := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom)

	// Create a lease and acknowledge it
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{
			SkuUuid:  sku.Uuid,
			Quantity: 1,
		},
	})

	// Advance block time by 100 seconds
	newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
	f.Ctx = newCtx

	// Close lease (should settle outstanding amount)
	closeResp, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
		Sender:     tenant.String(),
		LeaseUuids: []string{leaseID},
	})
	require.NoError(t, err)
	require.NotNil(t, closeResp)
	require.Equal(t, uint64(1), closeResp.ClosedCount)

	// Verify lease is closed
	lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_CLOSED, lease.State)
	require.NotNil(t, lease.ClosedAt)

	// Verify provider received settled funds during closure
	finalPayoutBalance := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom)
	require.True(t, finalPayoutBalance.Amount.GT(initialPayoutBalance.Amount),
		"provider should have received settlement during close")
}

// TestMsgCloseLease_PartialSettlement tests lease closure with partial credit.
func TestMsgCloseLease_PartialSettlement(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Set params with short min lease duration for testing
	params := types.DefaultParams()
	params.MaxLeasesPerTenant = 100
	params.MaxItemsPerLease = 20
	params.MinLeaseDuration = 10 // 10 seconds for testing
	err := f.App.BillingKeeper.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create provider and SKU with 1 unit per second rate
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	// Fund tenant's credit account with LIMITED funds (only 30 units)
	// Min duration is 10 seconds at 1/second = 10 units minimum
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	limitedFund := sdk.NewCoin(denom, sdkmath.NewInt(30))
	f.fundAccount(t, creditAddr, sdk.NewCoins(limitedFund))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease and acknowledge it
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{
			SkuUuid:  sku.Uuid,
			Quantity: 1,
		},
	})

	// Advance block time by 100 seconds (should accrue 100 units, but only 30 available)
	newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
	f.Ctx = newCtx

	// Close lease (should settle only what's available)
	closeResp, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
		Sender:     tenant.String(),
		LeaseUuids: []string{leaseID},
	})
	require.NoError(t, err)
	require.NotNil(t, closeResp)
	require.Equal(t, uint64(1), closeResp.ClosedCount)

	// Verify provider received 30 (all available credit)
	payoutBalance := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom)
	require.Equal(t, sdkmath.NewInt(30), payoutBalance.Amount)

	// Verify credit balance is now zero
	creditBalance := f.App.BankKeeper.GetBalance(f.Ctx, creditAddr, denom)
	require.True(t, creditBalance.Amount.IsZero())
}

// TestMsgCloseLease_CreditExhaustionLabelling verifies that a voluntary close is
// only recorded as credit_exhausted on a genuine shortfall. When the tenant's
// credit exactly covers the accrued charges — the accrued == balance case that
// ShouldAutoCloseLease's GTE boundary also treats as exhaustion — the caller's
// reason and role must be preserved. Regression for ENG-577.
func TestMsgCloseLease_CreditExhaustionLabelling(t *testing.T) {
	f := initFixture(t)
	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Short min duration so a small credit balance can back a lease.
	params := types.DefaultParams()
	params.MinLeaseDuration = 10
	require.NoError(t, f.App.BillingKeeper.SetParams(f.Ctx, params))

	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600/hour = 1 umfx/second

	// fundTenant funds a tenant's credit account with exactly `amount` units.
	fundTenant := func(t *testing.T, tenant sdk.AccAddress, amount int64) {
		t.Helper()
		creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
		require.NoError(t, err)
		f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(denom, sdkmath.NewInt(amount))))
		require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
			Tenant:        tenant.String(),
			CreditAddress: creditAddr.String(),
		}))
	}

	// closedEventBy returns the closed_by attribute of the lease_closed event for leaseID.
	closedEventBy := func(leaseID string) string {
		for _, ev := range f.Ctx.EventManager().Events() {
			if ev.Type != types.EventTypeLeaseClosed {
				continue
			}
			var uuid, by string
			for _, a := range ev.Attributes {
				switch a.Key {
				case types.AttributeKeyLeaseUUID:
					uuid = a.Value
				case types.AttributeKeyClosedBy:
					by = a.Value
				}
			}
			if uuid == leaseID {
				return by
			}
		}
		return ""
	}

	t.Run("exact balance keeps caller reason (accrued == balance)", func(t *testing.T) {
		tenant := f.TestAccs[0]
		fundTenant(t, tenant, 100) // rate 1/s -> exactly 100s of runway

		leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		// Advance exactly 100s: accrued (100) == balance (100).
		f.Ctx = f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))

		const reason = "migrating-to-new-provider"
		_, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{leaseID},
			Reason:     reason,
		})
		require.NoError(t, err)

		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_CLOSED, lease.State)
		require.Equal(t, reason, lease.ClosureReason,
			"a fully-paid voluntary close must keep the caller's reason, not credit_exhausted")
		require.Equal(t, types.AttributeValueRoleTenant, closedEventBy(leaseID),
			"closed_by must be the caller role, not credit_exhaustion")

		// Full payment: provider received all 100 units.
		require.Equal(t, sdkmath.NewInt(100), f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom).Amount)
	})

	t.Run("genuine shortfall is recorded as credit_exhausted (accrued > balance)", func(t *testing.T) {
		tenant := f.TestAccs[3]
		fundTenant(t, tenant, 30) // only 30 units of runway

		leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		// Advance 100s: accrued (100) > balance (30) -> genuine exhaustion.
		f.Ctx = f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))

		_, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{leaseID},
			Reason:     "should-be-overridden",
		})
		require.NoError(t, err)

		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_CLOSED, lease.State)
		require.Equal(t, types.ClosureReasonCreditExhausted, lease.ClosureReason,
			"an under-funded close is a genuine credit exhaustion")
	})

	t.Run("batch: earlier lease drawdown does not mislabel a fully-paid later lease", func(t *testing.T) {
		tenant := f.TestAccs[4]
		fundTenant(t, tenant, 200) // exactly enough for two 1/s leases over 100s

		leaseA := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})
		leaseB := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		f.Ctx = f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))

		const reason = "planned-teardown"
		_, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{leaseA, leaseB},
			Reason:     reason,
		})
		require.NoError(t, err)

		// Both leases are fully paid (200 credit == 200 accrued total). Closing A
		// first drains the shared balance so B settles at exactly zero remaining,
		// which must NOT be relabelled as credit exhaustion.
		for _, id := range []string{leaseA, leaseB} {
			lease, err := f.App.BillingKeeper.GetLease(f.Ctx, id)
			require.NoError(t, err)
			require.Equal(t, types.LEASE_STATE_CLOSED, lease.State)
			require.Equal(t, reason, lease.ClosureReason,
				"lease %s: batch drawdown must not relabel a fully-paid close", id)
		}
	})

	t.Run("representational overflow is still credit_exhausted", func(t *testing.T) {
		// tenant0's earlier lease is already closed; reuse and re-fund it.
		tenant := f.TestAccs[0]
		fundTenant(t, tenant, 5000)

		leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		// Simulate a migrated historical locked rate whose two-second accrued charge
		// exceeds the SDK integer representation. Its cutover allocation is capped to
		// the bank-backed 5000 units, so R/A/B remain coherent. Silent settlement
		// drains that allocation, but its explicit overflow metadata must still
		// classify the close as exhaustion.
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
		require.NoError(t, err)
		lease.Items[0].Quantity = 1
		lease.Items[0].LockedPrice = sdk.NewCoin(testDenom, highBitBillingTestInt())
		lease.MinLeaseDurationAtCreation = 1
		lease.LastSettledAt = f.Ctx.BlockTime().Add(-2 * time.Second)
		backedReservation := sdk.NewCoins(sdk.NewCoin(testDenom, sdkmath.NewInt(5000)))
		lease.Reservation = &types.LeaseReservation{
			RemainingAmounts: append(sdk.Coins(nil), backedReservation...),
		}
		require.NoError(t, f.App.BillingKeeper.SetLease(f.Ctx, lease))
		creditAccount, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
		require.NoError(t, err)
		creditAccount.ReservedAmounts = backedReservation
		require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, creditAccount))

		_, err = msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{leaseID},
			Reason:     "should-be-credit-exhausted",
		})
		require.NoError(t, err)

		closed, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_CLOSED, closed.State)
		require.Equal(t, types.ClosureReasonCreditExhausted, closed.ClosureReason,
			"an overflow-driven close (accrued beyond representable range) is genuine exhaustion")
	})

	t.Run("zero balance with zero elapsed time is still credit_exhausted", func(t *testing.T) {
		// tenant3's earlier lease is already closed; reuse and re-fund it.
		tenant := f.TestAccs[3]
		fundTenant(t, tenant, 100)
		creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
		require.NoError(t, err)

		leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		// Model a fully consumed reservation before draining the remaining unreserved
		// balance. This keeps R/A/B coherent at zero without advancing block time, so the
		// close sees duration == 0 and a zero balance. ShouldAutoCloseLease flags
		// this via its zero-balance branch, but PerformSettlementSilent accrues and
		// transfers nothing (duration == 0), so there is no unpaid remainder — the
		// close must still be recorded as genuine credit exhaustion, not the reason.
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
		require.NoError(t, err)
		lease.Reservation.RemainingAmounts = sdk.NewCoins()
		require.NoError(t, f.App.BillingKeeper.SetLease(f.Ctx, lease))
		creditAccount, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
		require.NoError(t, err)
		creditAccount.ReservedAmounts = sdk.NewCoins()
		require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, creditAccount))
		bal := f.App.BankKeeper.GetBalance(f.Ctx, creditAddr, denom)
		require.NoError(t, f.App.BankKeeper.SendCoins(f.Ctx, creditAddr, payoutAddr, sdk.NewCoins(bal)))

		_, err = msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{leaseID},
			Reason:     "should-be-credit-exhausted",
		})
		require.NoError(t, err)

		lease, err = f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_CLOSED, lease.State)
		require.Equal(t, types.ClosureReasonCreditExhausted, lease.ClosureReason,
			"a zero-balance lease closed with no time elapsed is genuine exhaustion")
	})
}

func TestMsgCloseLease_EventReportsExactDurationBeyondTimeDurationRange(t *testing.T) {
	f := initFixture(t)
	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)
	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	provider := f.createTestProvider(t, providerAddr.String(), providerAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	creditAddr := types.DeriveCreditAddress(tenant)
	f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(testDenom, sdkmath.NewInt(20_000_000_000))))
	require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	}))
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{{
		SkuUuid:  sku.Uuid,
		Quantity: 1,
	}})

	lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
	require.NoError(t, err)
	lastSettledAt := time.Date(1600, time.January, 1, 0, 0, 0, f.Ctx.BlockTime().Nanosecond(), time.UTC)
	lease.CreatedAt = lastSettledAt
	lease.LastSettledAt = lastSettledAt
	require.NoError(t, f.App.BillingKeeper.SetLease(f.Ctx, lease))

	expectedSeconds := f.Ctx.BlockTime().Unix() - lastSettledAt.Unix()
	require.Greater(t, expectedSeconds, int64((time.Duration(1<<63-1))/time.Second))
	f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())
	_, err = msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
		Sender:     tenant.String(),
		LeaseUuids: []string{leaseID},
		Reason:     "long-running lease",
	})
	require.NoError(t, err)

	closedEvent := findEvent(t, f.Ctx, types.EventTypeLeaseClosed)
	require.Equal(t, fmt.Sprintf("%d", expectedSeconds), attrValue(t, closedEvent, types.AttributeKeyDuration))
}

// TestMsgCloseLease_ProviderClose tests that provider can close a lease.
func TestMsgCloseLease_ProviderClose(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease and acknowledge it
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{
			SkuUuid:  sku.Uuid,
			Quantity: 1,
		},
	})

	// Advance block time
	newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(50 * time.Second))
	f.Ctx = newCtx

	// Provider closes the lease
	closeResp, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
		Sender:     providerAddr.String(),
		LeaseUuids: []string{leaseID},
	})
	require.NoError(t, err)
	require.NotNil(t, closeResp)
	require.Equal(t, uint64(1), closeResp.ClosedCount)

	// Verify lease is closed
	lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_CLOSED, lease.State)
}

// TestMsgCloseLease_AuthorityClose tests that authority can close any lease.
func TestMsgCloseLease_AuthorityClose(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease and acknowledge it
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{
			SkuUuid:  sku.Uuid,
			Quantity: 1,
		},
	})

	// Authority closes the lease
	closeResp, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
		Sender:     f.Authority.String(),
		LeaseUuids: []string{leaseID},
	})
	require.NoError(t, err)
	require.NotNil(t, closeResp)
	require.Equal(t, uint64(1), closeResp.ClosedCount)

	// Verify lease is closed
	lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_CLOSED, lease.State)
}

// TestMsgCloseLease_ErrorCases tests error scenarios for CloseLease.
func TestMsgCloseLease_ErrorCases(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	unauthorizedUser := f.TestAccs[3]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease and acknowledge it (needed for close tests)
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{
			SkuUuid:  sku.Uuid,
			Quantity: 1,
		},
	})

	t.Run("fail: close non-existent lease", func(t *testing.T) {
		_, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{"01912345-6789-7abc-8def-999999999999"},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not found")
	})

	t.Run("fail: unauthorized user cannot close", func(t *testing.T) {
		_, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     unauthorizedUser.String(),
			LeaseUuids: []string{leaseID},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "unauthorized")
	})

	t.Run("fail: close already closed lease", func(t *testing.T) {
		// First close the lease
		_, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{leaseID},
		})
		require.NoError(t, err)

		// Try to close again
		_, err = msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{leaseID},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not active")
	})
}

// TestMsgCloseLeaseBatch tests batch closure of multiple active leases.
func TestMsgCloseLeaseBatch(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	tenant2 := f.TestAccs[1]
	providerAddr := f.TestAccs[2]
	payoutAddr := f.TestAccs[3]
	provider2Addr := f.TestAccs[4]
	denom := testDenom

	// Create providers and SKUs (provider2 uses same addr for payout)
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 1 unit per second

	provider2 := f.createTestProvider(t, provider2Addr.String(), provider2Addr.String())
	sku2 := f.createTestSKU(t, provider2.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Fund tenant2's credit account
	creditAddr2, err := types.DeriveCreditAddressFromBech32(tenant2.String())
	require.NoError(t, err)
	f.fundAccount(t, creditAddr2, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant2.String(),
		CreditAddress: creditAddr2.String(),
	})
	require.NoError(t, err)

	t.Run("success: tenant closes multiple leases at once", func(t *testing.T) {
		// Create and acknowledge 3 leases
		lease1 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})
		lease2 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 2},
		})
		lease3 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 3},
		})

		// Advance time to accrue some billing
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(10 * time.Second))
		f.Ctx = newCtx

		// Clear event manager to isolate close events
		f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())

		// Close all 3 at once
		resp, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{lease1, lease2, lease3},
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, uint64(3), resp.ClosedCount)
		require.False(t, resp.ClosedAt.IsZero())
		require.False(t, resp.TotalSettledAmounts.IsZero(), "should have settled amounts")

		// Verify all leases are now CLOSED
		for _, uuid := range []string{lease1, lease2, lease3} {
			lease, err := f.App.BillingKeeper.GetLease(f.Ctx, uuid)
			require.NoError(t, err)
			require.Equal(t, types.LEASE_STATE_CLOSED, lease.State)
			require.NotNil(t, lease.ClosedAt)
		}

		// Verify events: 3 per-lease events + 1 batch summary event
		events := f.Ctx.EventManager().Events()
		perLeaseEventCount := 0
		batchEventCount := 0
		for _, event := range events {
			switch event.Type {
			case types.EventTypeLeaseClosed:
				perLeaseEventCount++
			case types.EventTypeBatchClosed:
				batchEventCount++
				// Verify batch event attributes
				for _, attr := range event.Attributes {
					if attr.Key == types.AttributeKeyLeaseCount {
						require.Equal(t, "3", attr.Value)
					}
				}
			}
		}
		require.Equal(t, 3, perLeaseEventCount, "should emit 3 per-lease events")
		require.Equal(t, 1, batchEventCount, "should emit 1 batch summary event")
	})

	t.Run("success: provider closes multiple leases", func(t *testing.T) {
		// Create and acknowledge leases for the same provider but different tenants
		lease1 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})
		lease2 := f.createAndAcknowledgeLease(t, msgServer, tenant2, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		// Provider closes both leases
		resp, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{lease1, lease2},
		})
		require.NoError(t, err)
		require.Equal(t, uint64(2), resp.ClosedCount)
	})

	t.Run("success: authority closes any leases", func(t *testing.T) {
		// Create leases for different providers
		lease1 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})
		lease2 := f.createAndAcknowledgeLease(t, msgServer, tenant, provider2Addr, []types.LeaseItemInput{
			{SkuUuid: sku2.Uuid, Quantity: 1},
		})

		// Authority can close leases from different providers
		resp, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     f.Authority.String(),
			LeaseUuids: []string{lease1, lease2},
		})
		require.NoError(t, err)
		require.Equal(t, uint64(2), resp.ClosedCount)
	})

	t.Run("fail: tenant cannot close other tenant's lease in batch", func(t *testing.T) {
		// Create leases for different tenants
		lease1 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})
		lease2 := f.createAndAcknowledgeLease(t, msgServer, tenant2, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		// Tenant1 tries to close both (includes tenant2's lease) - should fail
		_, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{lease1, lease2},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "unauthorized")

		// Verify both leases are still ACTIVE (atomic rollback)
		l1, _ := f.App.BillingKeeper.GetLease(f.Ctx, lease1)
		require.Equal(t, types.LEASE_STATE_ACTIVE, l1.State)

		l2, _ := f.App.BillingKeeper.GetLease(f.Ctx, lease2)
		require.Equal(t, types.LEASE_STATE_ACTIVE, l2.State)
	})

	t.Run("fail: one lease not active (atomicity)", func(t *testing.T) {
		// Create one active lease
		activeLease := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		// Create one pending lease
		pendingResp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		// Try to close both (one is pending) - should fail
		_, err = msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{activeLease, pendingResp.LeaseUuid},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not active")

		// Verify the active lease is still ACTIVE (atomic - no partial success)
		lease, _ := f.App.BillingKeeper.GetLease(f.Ctx, activeLease)
		require.Equal(t, types.LEASE_STATE_ACTIVE, lease.State)
	})

	t.Run("fail: empty lease list", func(t *testing.T) {
		_, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "cannot be empty")
	})

	t.Run("fail: duplicate UUIDs", func(t *testing.T) {
		lease := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		_, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{lease, lease},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "duplicate")
	})

	t.Run("success: aggregates settled amounts across denoms", func(t *testing.T) {
		// Create SKUs with different denoms
		sku3 := f.createTestSKUWithDenom(t, provider.Uuid, 3600, testDenom2)

		// Fund tenant with second denom
		f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(testDenom2, sdkmath.NewInt(100000000))))

		// Create two leases with different denoms
		lease1 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})
		lease2 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku3.Uuid, Quantity: 1},
		})

		// Advance time
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(10 * time.Second))
		f.Ctx = newCtx

		// Close both leases
		resp, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{lease1, lease2},
		})
		require.NoError(t, err)
		require.Equal(t, uint64(2), resp.ClosedCount)

		// TotalSettledAmounts should contain entries for both denoms
		require.True(t, len(resp.TotalSettledAmounts) >= 1, "should have at least one settled denom")
	})
}

// TestMsgWithdraw_FromClosedLease tests withdrawal from a closed lease.
func TestMsgWithdraw_FromClosedLease(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease and acknowledge it, then close it
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{
			SkuUuid:  sku.Uuid,
			Quantity: 1,
		},
	})

	// Close the lease
	_, err = msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
		Sender:     tenant.String(),
		LeaseUuids: []string{leaseID},
	})
	require.NoError(t, err)

	// Verify the lease is closed
	lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_CLOSED, lease.State)

	// Try to withdraw from closed lease - should fail (no withdrawable amount since already closed)
	_, err = msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
		Sender:     providerAddr.String(),
		LeaseUuids: []string{leaseID},
	})
	require.Error(t, err, "should fail to withdraw from closed lease")
}

// =============================================================================
// Multi-Denom Tests
// =============================================================================

// createTestSKUWithDenom creates a SKU with a specific denom for testing multi-denom scenarios.
func (f *testFixture) createTestSKUWithDenom(t *testing.T, providerUUID string, priceAmount int64, denom string) skutypes.SKU {
	t.Helper()

	skuUUID, err := f.App.SKUKeeper.GenerateSKUUUID(f.Ctx)
	require.NoError(t, err)

	sku := skutypes.SKU{
		Uuid:         skuUUID,
		ProviderUuid: providerUUID,
		Name:         "Test SKU " + denom,
		Unit:         skutypes.Unit_UNIT_PER_HOUR,
		BasePrice:    sdk.NewCoin(denom, sdkmath.NewInt(priceAmount)),
		Active:       true,
	}
	err = f.App.SKUKeeper.SetSKU(f.Ctx, sku)
	require.NoError(t, err)
	return sku
}

// TestMsgCreateLease_MultiDenom tests lease creation with SKUs using different denoms.
func TestMsgCreateLease_MultiDenom(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]

	// Create provider and two SKUs with different denoms
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku1 := f.createTestSKUWithDenom(t, provider.Uuid, 3600, testDenom)  // 1 per second in testDenom
	sku2 := f.createTestSKUWithDenom(t, provider.Uuid, 7200, testDenom2) // 2 per second in testDenom2

	// Fund tenant's credit account with BOTH denoms
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount1 := sdk.NewCoin(testDenom, sdkmath.NewInt(10000000))  // 10M testDenom
	fundAmount2 := sdk.NewCoin(testDenom2, sdkmath.NewInt(20000000)) // 20M testDenom2
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount1, fundAmount2))

	// Create credit account
	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	t.Run("success: create lease with multiple SKUs using different denoms", func(t *testing.T) {
		msg := &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{SkuUuid: sku1.Uuid, Quantity: 1}, // uses denom1
				{SkuUuid: sku2.Uuid, Quantity: 1}, // uses denom2
			},
		}
		resp, err := msgServer.CreateLease(f.Ctx, msg)
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.NotEmpty(t, resp.LeaseUuid)

		// Verify lease was created with correct items
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, resp.LeaseUuid)
		require.NoError(t, err)
		require.Len(t, lease.Items, 2)

		// Verify each item has the correct denom in its locked price
		require.Equal(t, testDenom, lease.Items[0].LockedPrice.Denom)
		require.Equal(t, testDenom2, lease.Items[1].LockedPrice.Denom)
	})
}

// TestMsgCreateLease_MultiDenom_InsufficientOneDenom tests that lease creation fails
// when the tenant has insufficient credit for one of the denoms.
func TestMsgCreateLease_MultiDenom_InsufficientOneDenom(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]

	// Create provider and two SKUs with different denoms
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku1 := f.createTestSKUWithDenom(t, provider.Uuid, 3600, testDenom)  // 1 per second in testDenom
	sku2 := f.createTestSKUWithDenom(t, provider.Uuid, 7200, testDenom2) // 2 per second in testDenom2

	// Fund tenant's credit account with ONLY testDenom (missing testDenom2)
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount1 := sdk.NewCoin(testDenom, sdkmath.NewInt(10000000)) // 10M testDenom
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount1))
	// NO testDenom2 funded!

	// Create credit account
	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	t.Run("fail: insufficient credit for one denom", func(t *testing.T) {
		msg := &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{SkuUuid: sku1.Uuid, Quantity: 1}, // uses testDenom - has enough
				{SkuUuid: sku2.Uuid, Quantity: 1}, // uses testDenom2 - insufficient!
			},
		}
		resp, err := msgServer.CreateLease(f.Ctx, msg)
		require.Error(t, err)
		require.Contains(t, err.Error(), "insufficient credit")
		require.Contains(t, err.Error(), testDenom2) // Should mention the missing denom
		require.Nil(t, resp)
	})
}

// TestMsgWithdraw_MultiDenom tests withdrawal from a multi-denom lease.
func TestMsgWithdraw_MultiDenom(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]

	// Create provider and two SKUs with different denoms
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku1 := f.createTestSKUWithDenom(t, provider.Uuid, 3600, testDenom)  // 1 per second in testDenom
	sku2 := f.createTestSKUWithDenom(t, provider.Uuid, 7200, testDenom2) // 2 per second in testDenom2

	// Fund tenant's credit account with BOTH denoms
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount1 := sdk.NewCoin(testDenom, sdkmath.NewInt(100000000))  // 100M testDenom
	fundAmount2 := sdk.NewCoin(testDenom2, sdkmath.NewInt(200000000)) // 200M testDenom2
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount1, fundAmount2))

	// Create credit account
	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create lease with both SKUs and acknowledge it
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{SkuUuid: sku1.Uuid, Quantity: 1},
		{SkuUuid: sku2.Uuid, Quantity: 1},
	})

	// Advance block time by 100 seconds
	// testDenom: 1/sec * 100 = 100
	// testDenom2: 2/sec * 100 = 200
	newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
	f.Ctx = newCtx

	t.Run("success: provider withdraws multiple denoms", func(t *testing.T) {
		// Get initial balances
		initialBalance1 := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, testDenom)
		initialBalance2 := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, testDenom2)

		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{leaseID},
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, payoutAddr.String(), resp.PayoutAddress)

		// Verify provider received both denoms
		require.False(t, resp.TotalAmounts.IsZero())

		// Check actual balances increased
		newBalance1 := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, testDenom)
		newBalance2 := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, testDenom2)

		require.True(t, newBalance1.Amount.GT(initialBalance1.Amount),
			"provider should receive testDenom funds")
		require.True(t, newBalance2.Amount.GT(initialBalance2.Amount),
			"provider should receive testDenom2 funds")
	})
}

// TestMsgCloseLease_MultiDenom_Settlement tests that closing a multi-denom lease
// settles all denoms correctly.
func TestMsgCloseLease_MultiDenom_Settlement(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]

	// Create provider and two SKUs with different denoms
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku1 := f.createTestSKUWithDenom(t, provider.Uuid, 3600, testDenom)  // 1 per second in testDenom
	sku2 := f.createTestSKUWithDenom(t, provider.Uuid, 7200, testDenom2) // 2 per second in testDenom2

	// Fund tenant's credit account with BOTH denoms
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount1 := sdk.NewCoin(testDenom, sdkmath.NewInt(100000000))  // 100M testDenom
	fundAmount2 := sdk.NewCoin(testDenom2, sdkmath.NewInt(200000000)) // 200M testDenom2
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount1, fundAmount2))

	// Create credit account
	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create lease with both SKUs and acknowledge it
	leaseID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{SkuUuid: sku1.Uuid, Quantity: 1},
		{SkuUuid: sku2.Uuid, Quantity: 1},
	})

	// Advance block time by 100 seconds
	newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
	f.Ctx = newCtx

	// Get initial payout balances
	initialBalance1 := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, testDenom)
	initialBalance2 := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, testDenom2)

	t.Run("success: close lease settles all denoms", func(t *testing.T) {
		resp, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{leaseID},
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, uint64(1), resp.ClosedCount)

		// Verify lease is closed
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_CLOSED, lease.State)

		// Verify provider received both denoms via settlement
		newBalance1 := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, testDenom)
		newBalance2 := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, testDenom2)

		require.True(t, newBalance1.Amount.GT(initialBalance1.Amount),
			"provider should receive testDenom settlement")
		require.True(t, newBalance2.Amount.GT(initialBalance2.Amount),
			"provider should receive testDenom2 settlement")
	})
}

// TestMsgFundCredit_MultiDenom tests funding a credit account with multiple denoms.
func TestMsgFundCredit_MultiDenom(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	sender := f.TestAccs[0]
	tenant := f.TestAccs[1]

	// Fund sender with both denoms
	fundAmount1 := sdk.NewCoin(testDenom, sdkmath.NewInt(10000000))
	fundAmount2 := sdk.NewCoin(testDenom2, sdkmath.NewInt(20000000))
	f.fundAccount(t, sender, sdk.NewCoins(fundAmount1, fundAmount2))

	t.Run("success: fund credit with first denom", func(t *testing.T) {
		resp, err := msgServer.FundCredit(f.Ctx, &types.MsgFundCredit{
			Sender: sender.String(),
			Tenant: tenant.String(),
			Amount: sdk.NewCoin(testDenom, sdkmath.NewInt(5000000)),
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, testDenom, resp.NewBalance.Denom)
	})

	t.Run("success: fund credit with second denom", func(t *testing.T) {
		resp, err := msgServer.FundCredit(f.Ctx, &types.MsgFundCredit{
			Sender: sender.String(),
			Tenant: tenant.String(),
			Amount: sdk.NewCoin(testDenom2, sdkmath.NewInt(10000000)),
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, testDenom2, resp.NewBalance.Denom)
	})

	t.Run("success: verify credit account has both denoms", func(t *testing.T) {
		creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
		require.NoError(t, err)

		balance1 := f.App.BankKeeper.GetBalance(f.Ctx, creditAddr, testDenom)
		balance2 := f.App.BankKeeper.GetBalance(f.Ctx, creditAddr, testDenom2)

		require.Equal(t, sdkmath.NewInt(5000000), balance1.Amount)
		require.Equal(t, sdkmath.NewInt(10000000), balance2.Amount)
	})
}

// TestMsgCreateLease_MultiDenom_SameDenomMultipleSKUs tests lease creation
// with multiple SKUs that use the same denom.
func TestMsgCreateLease_MultiDenom_SameDenomMultipleSKUs(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]

	// Create provider and multiple SKUs with the SAME denom
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku1 := f.createTestSKUWithDenom(t, provider.Uuid, 3600, testDenom)  // 1 per second
	sku2 := f.createTestSKUWithDenom(t, provider.Uuid, 7200, testDenom)  // 2 per second
	sku3 := f.createTestSKUWithDenom(t, provider.Uuid, 10800, testDenom) // 3 per second

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	// Total rate = 1+2+3 = 6/sec, min duration = 3600, need at least 21,600
	fundAmount := sdk.NewCoin(testDenom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	// Create credit account
	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	t.Run("success: create lease with multiple SKUs same denom", func(t *testing.T) {
		msg := &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{SkuUuid: sku1.Uuid, Quantity: 1},
				{SkuUuid: sku2.Uuid, Quantity: 1},
				{SkuUuid: sku3.Uuid, Quantity: 1},
			},
		}
		resp, err := msgServer.CreateLease(f.Ctx, msg)
		require.NoError(t, err)
		require.NotNil(t, resp)

		// Verify lease items all have the same denom
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, resp.LeaseUuid)
		require.NoError(t, err)
		require.Len(t, lease.Items, 3)

		for _, item := range lease.Items {
			require.Equal(t, testDenom, item.LockedPrice.Denom)
		}
	})
}

// =============================================================================
// Lease Lifecycle Tests (Acknowledge/Reject/Cancel)
// =============================================================================

// TestMsgAcknowledgeLease tests the provider acknowledgement of pending leases.
func TestMsgAcknowledgeLease(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	unauthorizedUser := f.TestAccs[3]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease (starts in PENDING state)
	createResp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items: []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		},
	})
	require.NoError(t, err)
	leaseID := createResp.LeaseUuid

	// Verify lease is PENDING
	lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_PENDING, lease.State)

	t.Run("success: provider acknowledges lease", func(t *testing.T) {
		// Clear event manager to isolate acknowledge events
		f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())

		resp, err := msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{leaseID},
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.False(t, resp.AcknowledgedAt.IsZero())

		// Verify lease is now ACTIVE
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_ACTIVE, lease.State)
		require.NotNil(t, lease.AcknowledgedAt)

		// Verify single lease does NOT emit batch event
		events := f.Ctx.EventManager().Events()
		perLeaseEventCount := 0
		batchEventCount := 0
		for _, event := range events {
			switch event.Type {
			case types.EventTypeLeaseAcknowledged:
				perLeaseEventCount++
			case types.EventTypeBatchAcknowledged:
				batchEventCount++
			}
		}
		require.Equal(t, 1, perLeaseEventCount, "should emit 1 per-lease event")
		require.Equal(t, 0, batchEventCount, "should NOT emit batch event for single lease")
	})

	// Create another lease for error tests
	createResp2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	leaseID2 := createResp2.LeaseUuid

	t.Run("fail: unauthorized user cannot acknowledge", func(t *testing.T) {
		_, err := msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     unauthorizedUser.String(),
			LeaseUuids: []string{leaseID2},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "unauthorized")
	})

	t.Run("fail: cannot acknowledge non-existent lease", func(t *testing.T) {
		_, err := msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{"01912345-6789-7abc-8def-999999999999"},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not found")
	})

	t.Run("fail: cannot acknowledge already active lease", func(t *testing.T) {
		_, err := msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{leaseID}, // Already acknowledged above
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not in PENDING state")
	})

	t.Run("success: authority can acknowledge lease", func(t *testing.T) {
		resp, err := msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     f.Authority.String(),
			LeaseUuids: []string{leaseID2},
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
	})
}

// TestMsgAcknowledgeLeaseBatch tests batch acknowledgement of multiple leases.
func TestMsgAcknowledgeLeaseBatch(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	provider2Addr := f.TestAccs[3]
	payout2Addr := f.TestAccs[4]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Create second provider for mixed-provider test
	provider2 := f.createTestProvider(t, provider2Addr.String(), payout2Addr.String())
	sku2 := f.createTestSKU(t, provider2.Uuid, 3600)

	// Fund tenant's credit account generously
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	t.Run("success: acknowledge multiple leases at once", func(t *testing.T) {
		// Create 3 pending leases for the same provider
		lease1, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		lease2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 2}},
		})
		require.NoError(t, err)

		lease3, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 3}},
		})
		require.NoError(t, err)

		// Clear event manager to isolate acknowledge events
		f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())

		// Acknowledge all 3 at once
		resp, err := msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{lease1.LeaseUuid, lease2.LeaseUuid, lease3.LeaseUuid},
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, uint64(3), resp.AcknowledgedCount)
		require.False(t, resp.AcknowledgedAt.IsZero())

		// Verify all leases are now ACTIVE
		for _, uuid := range []string{lease1.LeaseUuid, lease2.LeaseUuid, lease3.LeaseUuid} {
			lease, err := f.App.BillingKeeper.GetLease(f.Ctx, uuid)
			require.NoError(t, err)
			require.Equal(t, types.LEASE_STATE_ACTIVE, lease.State)
			require.NotNil(t, lease.AcknowledgedAt)
		}

		// Verify events: 3 per-lease events + 1 batch summary event
		events := f.Ctx.EventManager().Events()
		perLeaseEventCount := 0
		batchEventCount := 0
		for _, event := range events {
			switch event.Type {
			case types.EventTypeLeaseAcknowledged:
				perLeaseEventCount++
			case types.EventTypeBatchAcknowledged:
				batchEventCount++
				// Verify batch event attributes
				for _, attr := range event.Attributes {
					switch attr.Key {
					case types.AttributeKeyLeaseCount:
						require.Equal(t, "3", attr.Value)
					case types.AttributeKeyProviderUUID:
						require.Equal(t, provider.Uuid, attr.Value)
					case types.AttributeKeyAcknowledgedBy:
						require.Equal(t, providerAddr.String(), attr.Value)
					}
				}
			}
		}
		require.Equal(t, 3, perLeaseEventCount, "should emit 3 per-lease events")
		require.Equal(t, 1, batchEventCount, "should emit 1 batch summary event")
	})

	t.Run("fail: mixed providers", func(t *testing.T) {
		// Create leases for different providers
		leaseP1, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		leaseP2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku2.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		// Try to acknowledge both (different providers) - should fail
		_, err = msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{leaseP1.LeaseUuid, leaseP2.LeaseUuid},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "belongs to provider")

		// Verify both leases are still PENDING (atomic rollback)
		lease1, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseP1.LeaseUuid)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, lease1.State)

		lease2, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseP2.LeaseUuid)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, lease2.State)
	})

	t.Run("fail: one lease not pending (atomicity)", func(t *testing.T) {
		// Create two leases
		pendingLease, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		activeLease, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		// Acknowledge one lease first
		_, err = msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{activeLease.LeaseUuid},
		})
		require.NoError(t, err)

		// Try to acknowledge both (one already active) - should fail
		_, err = msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{pendingLease.LeaseUuid, activeLease.LeaseUuid},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not in PENDING state")

		// Verify the pending lease is still PENDING (atomic - no partial success)
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, pendingLease.LeaseUuid)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, lease.State)
	})

	t.Run("fail: empty lease list", func(t *testing.T) {
		_, err := msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "cannot be empty")
	})

	t.Run("fail: duplicate UUIDs", func(t *testing.T) {
		lease, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		_, err = msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{lease.LeaseUuid, lease.LeaseUuid},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "duplicate")
	})

	t.Run("fail: missing credit account (data integrity)", func(t *testing.T) {
		// Create a new tenant address without a credit account
		orphanTenant := sdk.AccAddress("orphan_tenant_addr__")

		// Directly create a lease in the store (bypassing normal flow to simulate data integrity issue)
		// Use valid UUIDv7 format (version 7 = 0x7xxx in the version nibble)
		orphanLeaseUUID := "01912345-6789-7abc-8def-ffffffffffff"
		orphanLease := types.Lease{
			Uuid:                       orphanLeaseUUID,
			Tenant:                     orphanTenant.String(),
			ProviderUuid:               provider.Uuid,
			State:                      types.LEASE_STATE_PENDING,
			MinLeaseDurationAtCreation: 1,
			Reservation:                &types.LeaseReservation{RemainingAmounts: sdk.NewCoins()},
			Items: []types.LeaseItem{
				{SkuUuid: sku.Uuid, Quantity: 1, LockedPrice: sdk.NewInt64Coin(denom, 3600)},
			},
			CreatedAt:     f.Ctx.BlockTime(),
			LastSettledAt: f.Ctx.BlockTime(),
		}
		err := f.App.BillingKeeper.SetLease(f.Ctx, orphanLease)
		require.NoError(t, err)

		// Try to acknowledge - should fail because credit account doesn't exist
		_, err = msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{orphanLeaseUUID},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "credit account not found")
		require.Contains(t, err.Error(), "data integrity issue")

		// Verify lease is still PENDING (no partial state change)
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, orphanLeaseUUID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, lease.State)
	})
}

// TestMsgAcknowledgeLeasePendingTimeoutBoundary verifies that PendingTimeout is
// a hard acknowledgement deadline with the same strict boundary as EndBlocker.
func TestMsgAcknowledgeLeasePendingTimeoutBoundary(t *testing.T) {
	tests := []struct {
		name        string
		elapsed     time.Duration
		expectError bool
	}{
		{
			name:    "just before cutoff",
			elapsed: 60*time.Second - time.Nanosecond,
		},
		{
			name:    "exactly at cutoff",
			elapsed: 60 * time.Second,
		},
		{
			name:        "just after cutoff before EndBlock",
			elapsed:     60*time.Second + time.Nanosecond,
			expectError: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			s := newAcknowledgementTestSetup(t, 1, func(params *types.Params) {
				params.PendingTimeout = 60
			})
			leaseUUID := s.createPendingLease(t, s.tenants[0])
			var endBlockBoundaryUUID string
			if tc.elapsed == 60*time.Second {
				// Leave a second lease unacknowledged so this same case also proves
				// EndBlock preserves PENDING state at the exact acknowledgement cutoff.
				endBlockBoundaryUUID = s.createPendingLease(t, s.tenants[0])
			}

			beforeLease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUID)
			require.NoError(t, err)
			beforeAccount, err := s.f.App.BillingKeeper.GetCreditAccount(s.f.Ctx, s.tenants[0].String())
			require.NoError(t, err)

			ackTime := beforeLease.CreatedAt.Add(tc.elapsed)
			ackCtx := s.f.Ctx.WithBlockTime(ackTime).WithEventManager(sdk.NewEventManager())
			resp, err := s.msgServer.AcknowledgeLease(ackCtx, &types.MsgAcknowledgeLease{
				Sender:     s.providerAddr.String(),
				LeaseUuids: []string{leaseUUID},
			})

			if !tc.expectError {
				require.NoError(t, err)
				require.NotNil(t, resp)
				require.Equal(t, ackTime, resp.AcknowledgedAt)

				lease, err := s.f.App.BillingKeeper.GetLease(ackCtx, leaseUUID)
				require.NoError(t, err)
				require.Equal(t, types.LEASE_STATE_ACTIVE, lease.State)
				require.NotNil(t, lease.AcknowledgedAt)
				require.Equal(t, ackTime, *lease.AcknowledgedAt)
				require.Equal(t, ackTime, lease.LastSettledAt)

				account, err := s.f.App.BillingKeeper.GetCreditAccount(ackCtx, s.tenants[0].String())
				require.NoError(t, err)
				require.Equal(t, uint64(1), account.ActiveLeaseCount)
				expectedPending := uint64(0)
				if endBlockBoundaryUUID != "" {
					expectedPending = 1
				}
				require.Equal(t, expectedPending, account.PendingLeaseCount)
				require.Equal(t, beforeAccount.ReservedAmounts, account.ReservedAmounts,
					"acknowledgement must preserve the lease reservation")
				require.Len(t, ackCtx.EventManager().Events(), 1)

				if endBlockBoundaryUUID != "" {
					require.NoError(t, s.f.App.BillingKeeper.EndBlocker(ackCtx))
					boundaryLease, err := s.f.App.BillingKeeper.GetLease(ackCtx, endBlockBoundaryUUID)
					require.NoError(t, err)
					require.Equal(t, types.LEASE_STATE_PENDING, boundaryLease.State)
					boundaryAccount, err := s.f.App.BillingKeeper.GetCreditAccount(ackCtx, s.tenants[0].String())
					require.NoError(t, err)
					require.Equal(t, account, boundaryAccount,
						"EndBlock at the exact cutoff must not change counts or reservations")
				}
				return
			}

			require.Nil(t, resp)
			require.ErrorIs(t, err, types.ErrLeaseAcknowledgementDeadlineExceeded)

			// The acknowledgement runs before EndBlock for this block. A failed hard-deadline
			// check must leave every field, aggregate, reservation, and event untouched.
			afterLease, getErr := s.f.App.BillingKeeper.GetLease(ackCtx, leaseUUID)
			require.NoError(t, getErr)
			require.Equal(t, beforeLease, afterLease)
			afterAccount, getErr := s.f.App.BillingKeeper.GetCreditAccount(ackCtx, s.tenants[0].String())
			require.NoError(t, getErr)
			require.Equal(t, beforeAccount, afterAccount)
			require.Empty(t, ackCtx.EventManager().Events())

			// EndBlock observes the identical strict boundary and expires the lease later
			// in the same block, proving acknowledgement cannot win the pre-EndBlock race.
			require.NoError(t, s.f.App.BillingKeeper.EndBlocker(ackCtx))
			expiredLease, getErr := s.f.App.BillingKeeper.GetLease(ackCtx, leaseUUID)
			require.NoError(t, getErr)
			require.Equal(t, types.LEASE_STATE_EXPIRED, expiredLease.State)
			expiredAccount, getErr := s.f.App.BillingKeeper.GetCreditAccount(ackCtx, s.tenants[0].String())
			require.NoError(t, getErr)
			require.Zero(t, expiredAccount.ActiveLeaseCount)
			require.Zero(t, expiredAccount.PendingLeaseCount)
			require.True(t, expiredAccount.ReservedAmounts.IsZero(),
				"EndBlock expiration must release the pending lease reservation")
		})
	}
}

// TestMsgAcknowledgeLeaseTimeoutBatchAtomicity verifies that an overdue lease
// late in the batch prevents an otherwise-eligible lease from being activated.
func TestMsgAcknowledgeLeaseTimeoutBatchAtomicity(t *testing.T) {
	s := newAcknowledgementTestSetup(t, 1, func(params *types.Params) {
		params.PendingTimeout = 60
		params.MaxPendingLeasesPerTenant = 2
	})
	baseTime := s.f.Ctx.BlockTime()
	overdueUUID := s.createPendingLease(t, s.tenants[0])

	// The second lease is younger and still eligible at the acknowledgement time.
	s.f.Ctx = s.f.Ctx.WithBlockTime(baseTime.Add(30 * time.Second))
	eligibleUUID := s.createPendingLease(t, s.tenants[0])
	leaseUUIDs := []string{eligibleUUID, overdueUUID}

	beforeAccount, err := s.f.App.BillingKeeper.GetCreditAccount(s.f.Ctx, s.tenants[0].String())
	require.NoError(t, err)
	beforeLeases := make([]types.Lease, 0, len(leaseUUIDs))
	for _, leaseUUID := range leaseUUIDs {
		lease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUID)
		require.NoError(t, err)
		beforeLeases = append(beforeLeases, lease)
	}

	ackCtx := s.f.Ctx.WithBlockTime(baseTime.Add(60*time.Second + time.Nanosecond)).
		WithEventManager(sdk.NewEventManager())
	resp, err := s.msgServer.AcknowledgeLease(ackCtx, &types.MsgAcknowledgeLease{
		Sender:     s.providerAddr.String(),
		LeaseUuids: leaseUUIDs,
	})
	require.Nil(t, resp)
	require.ErrorIs(t, err, types.ErrLeaseAcknowledgementDeadlineExceeded)

	afterAccount, err := s.f.App.BillingKeeper.GetCreditAccount(ackCtx, s.tenants[0].String())
	require.NoError(t, err)
	require.Equal(t, beforeAccount, afterAccount)
	for i, leaseUUID := range leaseUUIDs {
		lease, err := s.f.App.BillingKeeper.GetLease(ackCtx, leaseUUID)
		require.NoError(t, err)
		require.Equal(t, beforeLeases[i], lease)
	}
	require.Empty(t, ackCtx.EventManager().Events())
}

// TestMsgAcknowledgeLeaseActiveCap verifies that the active-lease limit is
// evaluated against each tenant's post-batch count before any writes occur.
func TestMsgAcknowledgeLeaseActiveCap(t *testing.T) {
	t.Run("equivalent Bech32 spellings share one tenant cap", func(t *testing.T) {
		for _, tc := range []struct {
			name      string
			maxActive uint64
			wantErr   bool
		}{
			{name: "reject overshoot", maxActive: 1, wantErr: true},
			{name: "apply both counts once", maxActive: 2},
		} {
			t.Run(tc.name, func(t *testing.T) {
				s := newAcknowledgementTestSetup(t, 1, func(params *types.Params) {
					params.MaxLeasesPerTenant = tc.maxActive
					params.MaxPendingLeasesPerTenant = 2
				})
				pendingUUIDs := []string{
					s.createPendingLease(t, s.tenants[0]),
					s.createPendingLease(t, s.tenants[0]),
				}

				// Simulate a historical v2 value written with an all-uppercase
				// Bech32 spelling. Its indexes were already SDK address bytes.
				aliasedLease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, pendingUUIDs[1])
				require.NoError(t, err)
				aliasedLease.Tenant = strings.ToUpper(aliasedLease.Tenant)
				overwriteLeaseWithLegacyEncoding(t, s.f, aliasedLease)

				ackCtx := s.f.Ctx.WithEventManager(sdk.NewEventManager())
				resp, err := s.msgServer.AcknowledgeLease(ackCtx, &types.MsgAcknowledgeLease{
					Sender:     s.providerAddr.String(),
					LeaseUuids: pendingUUIDs,
				})

				account, accountErr := s.f.App.BillingKeeper.GetCreditAccount(ackCtx, s.tenants[0].String())
				require.NoError(t, accountErr)
				if tc.wantErr {
					require.Nil(t, resp)
					require.ErrorIs(t, err, types.ErrLeaseAcknowledgementActiveCapExceeded)
					require.Zero(t, account.ActiveLeaseCount)
					require.Equal(t, uint64(2), account.PendingLeaseCount)
					require.Empty(t, ackCtx.EventManager().Events())
					for _, leaseUUID := range pendingUUIDs {
						lease, leaseErr := s.f.App.BillingKeeper.GetLease(ackCtx, leaseUUID)
						require.NoError(t, leaseErr)
						require.Equal(t, types.LEASE_STATE_PENDING, lease.State)
					}
					return
				}

				require.NoError(t, err)
				require.Equal(t, uint64(2), resp.AcknowledgedCount)
				require.Equal(t, uint64(2), account.ActiveLeaseCount)
				require.Zero(t, account.PendingLeaseCount)
				storedLease, leaseErr := s.f.App.BillingKeeper.GetLease(ackCtx, pendingUUIDs[1])
				require.NoError(t, leaseErr)
				require.Equal(t, s.tenants[0].String(), storedLease.Tenant)
			})
		}
	})

	t.Run("same-tenant batch succeeds at active cap boundary", func(t *testing.T) {
		s := newAcknowledgementTestSetup(t, 1, func(params *types.Params) {
			params.MaxLeasesPerTenant = 2
			params.MaxPendingLeasesPerTenant = 3
		})
		pendingUUIDs := []string{
			s.createPendingLease(t, s.tenants[0]),
			s.createPendingLease(t, s.tenants[0]),
		}

		resp, err := s.msgServer.AcknowledgeLease(s.f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     s.providerAddr.String(),
			LeaseUuids: pendingUUIDs,
		})
		require.NoError(t, err)
		require.Equal(t, uint64(2), resp.AcknowledgedCount)

		account, err := s.f.App.BillingKeeper.GetCreditAccount(s.f.Ctx, s.tenants[0].String())
		require.NoError(t, err)
		require.Equal(t, uint64(2), account.ActiveLeaseCount)
		require.Zero(t, account.PendingLeaseCount)
	})

	t.Run("batch overshoot is atomic", func(t *testing.T) {
		s := newAcknowledgementTestSetup(t, 1, func(params *types.Params) {
			params.MaxLeasesPerTenant = 2
			params.MaxPendingLeasesPerTenant = 3
		})
		s.f.createAndAcknowledgeLease(t, s.msgServer, s.tenants[0], s.providerAddr,
			[]types.LeaseItemInput{{SkuUuid: s.skuUUID, Quantity: 1}})
		pendingUUIDs := []string{
			s.createPendingLease(t, s.tenants[0]),
			s.createPendingLease(t, s.tenants[0]),
		}

		beforeAccount, err := s.f.App.BillingKeeper.GetCreditAccount(s.f.Ctx, s.tenants[0].String())
		require.NoError(t, err)
		beforeLeases := make([]types.Lease, 0, len(pendingUUIDs))
		for _, leaseUUID := range pendingUUIDs {
			lease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUID)
			require.NoError(t, err)
			beforeLeases = append(beforeLeases, lease)
		}

		ackCtx := s.f.Ctx.WithEventManager(sdk.NewEventManager())
		resp, err := s.msgServer.AcknowledgeLease(ackCtx, &types.MsgAcknowledgeLease{
			Sender:     s.providerAddr.String(),
			LeaseUuids: pendingUUIDs,
		})
		require.Nil(t, resp)
		require.ErrorIs(t, err, types.ErrLeaseAcknowledgementActiveCapExceeded)

		afterAccount, err := s.f.App.BillingKeeper.GetCreditAccount(ackCtx, s.tenants[0].String())
		require.NoError(t, err)
		require.Equal(t, beforeAccount, afterAccount)
		for i, leaseUUID := range pendingUUIDs {
			lease, err := s.f.App.BillingKeeper.GetLease(ackCtx, leaseUUID)
			require.NoError(t, err)
			require.Equal(t, beforeLeases[i], lease)
		}
		require.Empty(t, ackCtx.EventManager().Events())
	})

	t.Run("account already above a lowered cap is rejected without underflow", func(t *testing.T) {
		s := newAcknowledgementTestSetup(t, 1, func(params *types.Params) {
			params.MaxLeasesPerTenant = 4
			params.MaxPendingLeasesPerTenant = 2
		})
		for range 3 {
			s.f.createAndAcknowledgeLease(t, s.msgServer, s.tenants[0], s.providerAddr,
				[]types.LeaseItemInput{{SkuUuid: s.skuUUID, Quantity: 1}})
		}
		pendingUUID := s.createPendingLease(t, s.tenants[0])

		params, err := s.f.App.BillingKeeper.GetParams(s.f.Ctx)
		require.NoError(t, err)
		params.MaxLeasesPerTenant = 2
		require.NoError(t, s.f.App.BillingKeeper.SetParams(s.f.Ctx, params))

		beforeAccount, err := s.f.App.BillingKeeper.GetCreditAccount(s.f.Ctx, s.tenants[0].String())
		require.NoError(t, err)
		require.Equal(t, uint64(3), beforeAccount.ActiveLeaseCount)
		beforeLease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, pendingUUID)
		require.NoError(t, err)

		ackCtx := s.f.Ctx.WithEventManager(sdk.NewEventManager())
		resp, err := s.msgServer.AcknowledgeLease(ackCtx, &types.MsgAcknowledgeLease{
			Sender:     s.providerAddr.String(),
			LeaseUuids: []string{pendingUUID},
		})
		require.Nil(t, resp)
		require.ErrorIs(t, err, types.ErrLeaseAcknowledgementActiveCapExceeded)

		afterAccount, err := s.f.App.BillingKeeper.GetCreditAccount(ackCtx, s.tenants[0].String())
		require.NoError(t, err)
		require.Equal(t, beforeAccount, afterAccount)
		afterLease, err := s.f.App.BillingKeeper.GetLease(ackCtx, pendingUUID)
		require.NoError(t, err)
		require.Equal(t, beforeLease, afterLease)
		require.Empty(t, ackCtx.EventManager().Events())
	})

	t.Run("mixed tenants are capped independently", func(t *testing.T) {
		s := newAcknowledgementTestSetup(t, 2, func(params *types.Params) {
			params.MaxLeasesPerTenant = 1
			params.MaxPendingLeasesPerTenant = 2
		})
		leaseUUIDs := []string{
			s.createPendingLease(t, s.tenants[0]),
			s.createPendingLease(t, s.tenants[1]),
		}

		resp, err := s.msgServer.AcknowledgeLease(s.f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     s.providerAddr.String(),
			LeaseUuids: leaseUUIDs,
		})
		require.NoError(t, err)
		require.Equal(t, uint64(2), resp.AcknowledgedCount)

		for _, tenant := range s.tenants {
			account, err := s.f.App.BillingKeeper.GetCreditAccount(s.f.Ctx, tenant.String())
			require.NoError(t, err)
			require.Equal(t, uint64(1), account.ActiveLeaseCount)
			require.Zero(t, account.PendingLeaseCount)
		}
	})

	t.Run("one tenant cap failure rolls back a mixed-tenant batch", func(t *testing.T) {
		s := newAcknowledgementTestSetup(t, 2, func(params *types.Params) {
			params.MaxLeasesPerTenant = 2
			params.MaxPendingLeasesPerTenant = 3
		})
		s.f.createAndAcknowledgeLease(t, s.msgServer, s.tenants[0], s.providerAddr,
			[]types.LeaseItemInput{{SkuUuid: s.skuUUID, Quantity: 1}})
		leaseUUIDs := []string{
			s.createPendingLease(t, s.tenants[1]),
			s.createPendingLease(t, s.tenants[0]),
			s.createPendingLease(t, s.tenants[0]),
		}

		beforeAccounts := make([]types.CreditAccount, 0, len(s.tenants))
		for _, tenant := range s.tenants {
			account, err := s.f.App.BillingKeeper.GetCreditAccount(s.f.Ctx, tenant.String())
			require.NoError(t, err)
			beforeAccounts = append(beforeAccounts, account)
		}
		beforeLeases := make([]types.Lease, 0, len(leaseUUIDs))
		for _, leaseUUID := range leaseUUIDs {
			lease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUID)
			require.NoError(t, err)
			beforeLeases = append(beforeLeases, lease)
		}

		ackCtx := s.f.Ctx.WithEventManager(sdk.NewEventManager())
		resp, err := s.msgServer.AcknowledgeLease(ackCtx, &types.MsgAcknowledgeLease{
			Sender:     s.providerAddr.String(),
			LeaseUuids: leaseUUIDs,
		})
		require.Nil(t, resp)
		require.ErrorIs(t, err, types.ErrLeaseAcknowledgementActiveCapExceeded)

		for i, tenant := range s.tenants {
			account, err := s.f.App.BillingKeeper.GetCreditAccount(ackCtx, tenant.String())
			require.NoError(t, err)
			require.Equal(t, beforeAccounts[i], account)
		}
		for i, leaseUUID := range leaseUUIDs {
			lease, err := s.f.App.BillingKeeper.GetLease(ackCtx, leaseUUID)
			require.NoError(t, err)
			require.Equal(t, beforeLeases[i], lease)
		}
		require.Empty(t, ackCtx.EventManager().Events())
	})
}

func TestBatchLeaseAccountingUsesCanonicalTenantIdentity(t *testing.T) {
	for _, tc := range []struct {
		name      string
		terminal  types.LeaseState
		operation func(*acknowledgementTestSetup, []string) error
	}{
		{
			name:     "reject",
			terminal: types.LEASE_STATE_REJECTED,
			operation: func(s *acknowledgementTestSetup, leaseUUIDs []string) error {
				_, err := s.msgServer.RejectLease(s.f.Ctx, &types.MsgRejectLease{
					Sender:     s.providerAddr.String(),
					LeaseUuids: leaseUUIDs,
					Reason:     "canonical identity regression",
				})
				return err
			},
		},
		{
			name:     "close",
			terminal: types.LEASE_STATE_CLOSED,
			operation: func(s *acknowledgementTestSetup, leaseUUIDs []string) error {
				_, err := s.msgServer.AcknowledgeLease(s.f.Ctx, &types.MsgAcknowledgeLease{
					Sender:     s.providerAddr.String(),
					LeaseUuids: leaseUUIDs,
				})
				if err != nil {
					return err
				}
				aliasedLease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUIDs[1])
				if err != nil {
					return err
				}
				aliasedLease.Tenant = strings.ToUpper(aliasedLease.Tenant)
				overwriteLeaseWithLegacyEncoding(t, s.f, aliasedLease)
				_, err = s.msgServer.CloseLease(s.f.Ctx, &types.MsgCloseLease{
					Sender:     s.providerAddr.String(),
					LeaseUuids: leaseUUIDs,
				})
				return err
			},
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			s := newAcknowledgementTestSetup(t, 1, func(params *types.Params) {
				params.MaxLeasesPerTenant = 2
				params.MaxPendingLeasesPerTenant = 2
			})
			leaseUUIDs := []string{
				s.createPendingLease(t, s.tenants[0]),
				s.createPendingLease(t, s.tenants[0]),
			}
			aliasedLease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUIDs[1])
			require.NoError(t, err)
			aliasedLease.Tenant = strings.ToUpper(aliasedLease.Tenant)
			overwriteLeaseWithLegacyEncoding(t, s.f, aliasedLease)

			require.NoError(t, tc.operation(s, leaseUUIDs))
			account, err := s.f.App.BillingKeeper.GetCreditAccount(s.f.Ctx, s.tenants[0].String())
			require.NoError(t, err)
			require.Zero(t, account.ActiveLeaseCount)
			require.Zero(t, account.PendingLeaseCount)
			require.True(t, account.ReservedAmounts.IsZero())
			for _, leaseUUID := range leaseUUIDs {
				lease, leaseErr := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUID)
				require.NoError(t, leaseErr)
				require.Equal(t, tc.terminal, lease.State)
			}
		})
	}
}

// TestMsgRejectLease tests the provider rejection of pending leases.
func TestMsgRejectLease(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	unauthorizedUser := f.TestAccs[3]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:           tenant.String(),
		CreditAddress:    creditAddr.String(),
		ActiveLeaseCount: 0,
	})
	require.NoError(t, err)

	// Create a lease (starts in PENDING state)
	createResp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	leaseID := createResp.LeaseUuid

	t.Run("success: provider rejects lease with reason", func(t *testing.T) {
		resp, err := msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{leaseID},
			Reason:     "Resource unavailable",
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.False(t, resp.RejectedAt.IsZero())
		require.Equal(t, uint64(1), resp.RejectedCount)

		// Verify lease is now REJECTED
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_REJECTED, lease.State)
		require.NotNil(t, lease.RejectedAt)
		require.Equal(t, "Resource unavailable", lease.RejectionReason)
	})

	// Create another lease for more tests
	createResp2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	leaseID2 := createResp2.LeaseUuid

	t.Run("fail: unauthorized user cannot reject", func(t *testing.T) {
		_, err := msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
			Sender:     unauthorizedUser.String(),
			LeaseUuids: []string{leaseID2},
			Reason:     "Test",
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "unauthorized")
	})

	t.Run("fail: cannot reject already rejected lease", func(t *testing.T) {
		_, err := msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{leaseID}, // Already rejected above
			Reason:     "Test",
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not in PENDING state")
	})

	t.Run("success: authority can reject lease", func(t *testing.T) {
		resp, err := msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
			Sender:     f.Authority.String(),
			LeaseUuids: []string{leaseID2},
			Reason:     "Admin rejection",
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, uint64(1), resp.RejectedCount)
	})
}

// TestMsgRejectLeaseBatch tests batch rejection of multiple pending leases.
func TestMsgRejectLeaseBatch(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	provider2Addr := f.TestAccs[3]
	payout2Addr := f.TestAccs[4]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Create second provider for mixed-provider test
	provider2 := f.createTestProvider(t, provider2Addr.String(), payout2Addr.String())
	sku2 := f.createTestSKU(t, provider2.Uuid, 3600)

	// Fund tenant's credit account generously
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	t.Run("success: reject multiple leases at once", func(t *testing.T) {
		// Create 3 pending leases for the same provider
		lease1, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		lease2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 2}},
		})
		require.NoError(t, err)

		lease3, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 3}},
		})
		require.NoError(t, err)

		// Clear event manager to isolate reject events
		f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())

		// Reject all 3 at once
		resp, err := msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{lease1.LeaseUuid, lease2.LeaseUuid, lease3.LeaseUuid},
			Reason:     "Batch rejection test",
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, uint64(3), resp.RejectedCount)
		require.False(t, resp.RejectedAt.IsZero())

		// Verify all leases are now REJECTED
		for _, uuid := range []string{lease1.LeaseUuid, lease2.LeaseUuid, lease3.LeaseUuid} {
			lease, err := f.App.BillingKeeper.GetLease(f.Ctx, uuid)
			require.NoError(t, err)
			require.Equal(t, types.LEASE_STATE_REJECTED, lease.State)
			require.NotNil(t, lease.RejectedAt)
			require.Equal(t, "Batch rejection test", lease.RejectionReason)
		}

		// Verify events: 3 per-lease events + 1 batch summary event
		events := f.Ctx.EventManager().Events()
		perLeaseEventCount := 0
		batchEventCount := 0
		for _, event := range events {
			switch event.Type {
			case types.EventTypeLeaseRejected:
				perLeaseEventCount++
			case types.EventTypeBatchRejected:
				batchEventCount++
				// Verify batch event attributes
				for _, attr := range event.Attributes {
					switch attr.Key {
					case types.AttributeKeyLeaseCount:
						require.Equal(t, "3", attr.Value)
					case types.AttributeKeyProviderUUID:
						require.Equal(t, provider.Uuid, attr.Value)
					case types.AttributeKeyRejectedBy:
						require.Equal(t, providerAddr.String(), attr.Value)
					}
				}
			}
		}
		require.Equal(t, 3, perLeaseEventCount, "should emit 3 per-lease events")
		require.Equal(t, 1, batchEventCount, "should emit 1 batch summary event")
	})

	t.Run("fail: mixed providers", func(t *testing.T) {
		// Create leases for different providers
		leaseP1, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		leaseP2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku2.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		// Try to reject both (different providers) - should fail
		_, err = msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{leaseP1.LeaseUuid, leaseP2.LeaseUuid},
			Reason:     "Test",
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "belongs to provider")

		// Verify both leases are still PENDING (atomic rollback)
		lease1, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseP1.LeaseUuid)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, lease1.State)

		lease2, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseP2.LeaseUuid)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, lease2.State)
	})

	t.Run("fail: one lease not pending (atomicity)", func(t *testing.T) {
		// Create two leases
		pendingLease, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		ackLease, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		// Acknowledge one lease first (making it ACTIVE)
		_, err = msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{ackLease.LeaseUuid},
		})
		require.NoError(t, err)

		// Try to reject both (one is ACTIVE) - should fail
		_, err = msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{pendingLease.LeaseUuid, ackLease.LeaseUuid},
			Reason:     "Test",
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not in PENDING state")

		// Verify the pending lease is still PENDING (atomic - no partial success)
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, pendingLease.LeaseUuid)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, lease.State)
	})

	t.Run("fail: empty lease list", func(t *testing.T) {
		_, err := msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{},
			Reason:     "Test",
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "cannot be empty")
	})

	t.Run("fail: duplicate UUIDs", func(t *testing.T) {
		lease, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		_, err = msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{lease.LeaseUuid, lease.LeaseUuid},
			Reason:     "Test",
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "duplicate")
	})
}

// TestMsgCancelLease tests the tenant cancellation of pending leases.
func TestMsgCancelLease(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	otherTenant := f.TestAccs[1]
	providerAddr := f.TestAccs[2]
	payoutAddr := f.TestAccs[3]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:           tenant.String(),
		CreditAddress:    creditAddr.String(),
		ActiveLeaseCount: 0,
	})
	require.NoError(t, err)

	// Create a lease (starts in PENDING state)
	createResp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	leaseID := createResp.LeaseUuid

	t.Run("success: tenant cancels own pending lease", func(t *testing.T) {
		resp, err := msgServer.CancelLease(f.Ctx, &types.MsgCancelLease{
			Tenant:     tenant.String(),
			LeaseUuids: []string{leaseID},
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.False(t, resp.CancelledAt.IsZero())
		require.Equal(t, uint64(1), resp.CancelledCount)

		// Verify lease is now REJECTED (cancelled)
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_REJECTED, lease.State)
	})

	// Create another lease for error tests
	createResp2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	leaseID2 := createResp2.LeaseUuid

	t.Run("fail: other tenant cannot cancel someone else's lease", func(t *testing.T) {
		// otherTenant is not the tenant of leaseID2, so ownership check fails
		_, err := msgServer.CancelLease(f.Ctx, &types.MsgCancelLease{
			Tenant:     otherTenant.String(),
			LeaseUuids: []string{leaseID2},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "is not the tenant")
	})

	t.Run("fail: cannot cancel non-existent lease", func(t *testing.T) {
		_, err := msgServer.CancelLease(f.Ctx, &types.MsgCancelLease{
			Tenant:     tenant.String(),
			LeaseUuids: []string{"01912345-6789-7abc-8def-999999999999"},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not found")
	})

	// First acknowledge the lease, then try to cancel
	_, err = msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
		Sender:     providerAddr.String(),
		LeaseUuids: []string{leaseID2},
	})
	require.NoError(t, err)

	t.Run("fail: cannot cancel active lease", func(t *testing.T) {
		_, err := msgServer.CancelLease(f.Ctx, &types.MsgCancelLease{
			Tenant:     tenant.String(),
			LeaseUuids: []string{leaseID2},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not in PENDING state")
	})
}

// TestMsgCancelLeaseBatch tests batch cancel operations.
func TestMsgCancelLeaseBatch(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:           tenant.String(),
		CreditAddress:    creditAddr.String(),
		ActiveLeaseCount: 0,
	})
	require.NoError(t, err)

	t.Run("success: batch cancel multiple pending leases", func(t *testing.T) {
		// Create 3 leases
		lease1, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		lease2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		lease3, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		// Cancel all 3 leases in one transaction
		resp, err := msgServer.CancelLease(f.Ctx, &types.MsgCancelLease{
			Tenant:     tenant.String(),
			LeaseUuids: []string{lease1.LeaseUuid, lease2.LeaseUuid, lease3.LeaseUuid},
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.False(t, resp.CancelledAt.IsZero())
		require.Equal(t, uint64(3), resp.CancelledCount)

		// Verify all leases are REJECTED
		for _, leaseUUID := range []string{lease1.LeaseUuid, lease2.LeaseUuid, lease3.LeaseUuid} {
			lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseUUID)
			require.NoError(t, err)
			require.Equal(t, types.LEASE_STATE_REJECTED, lease.State)
			require.Equal(t, "cancelled by tenant", lease.RejectionReason)
		}
	})

	t.Run("fail: atomicity - one non-pending lease fails entire batch", func(t *testing.T) {
		// Create 2 pending leases
		lease1, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		lease2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		// Acknowledge lease1 to make it ACTIVE
		_, err = msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
			Sender:     providerAddr.String(),
			LeaseUuids: []string{lease1.LeaseUuid},
		})
		require.NoError(t, err)

		// Verify lease1 is now ACTIVE
		l1, err := f.App.BillingKeeper.GetLease(f.Ctx, lease1.LeaseUuid)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_ACTIVE, l1.State)

		// Try to cancel both - should fail because lease1 is ACTIVE
		_, err = msgServer.CancelLease(f.Ctx, &types.MsgCancelLease{
			Tenant:     tenant.String(),
			LeaseUuids: []string{lease1.LeaseUuid, lease2.LeaseUuid},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not in PENDING state")

		// Verify lease2 is still PENDING (atomicity: no partial changes)
		l2, err := f.App.BillingKeeper.GetLease(f.Ctx, lease2.LeaseUuid)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, l2.State)
	})

	t.Run("fail: duplicate UUIDs in request", func(t *testing.T) {
		lease, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		_, err = msgServer.CancelLease(f.Ctx, &types.MsgCancelLease{
			Tenant:     tenant.String(),
			LeaseUuids: []string{lease.LeaseUuid, lease.LeaseUuid},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "duplicate")
	})

	t.Run("fail: empty lease_uuids", func(t *testing.T) {
		_, err := msgServer.CancelLease(f.Ctx, &types.MsgCancelLease{
			Tenant:     tenant.String(),
			LeaseUuids: []string{},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "cannot be empty")
	})
}

// TestEndBlockerPendingLeaseExpiration tests that pending leases expire after the timeout.
func TestEndBlockerPendingLeaseExpiration(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Set a short pending timeout for testing (60 seconds)
	params := types.DefaultParams()
	params.PendingTimeout = 60 // 60 seconds
	err := f.App.BillingKeeper.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a lease (will be in PENDING state)
	createResp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items: []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		},
	})
	require.NoError(t, err)
	leaseUUID := createResp.LeaseUuid

	// Verify lease is in PENDING state
	lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseUUID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_PENDING, lease.State)

	// Verify pending lease count is 1
	creditAccount, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, uint64(1), creditAccount.PendingLeaseCount)

	t.Run("lease not expired before timeout", func(t *testing.T) {
		// Advance time by 30 seconds (less than timeout)
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(30 * time.Second))

		// Run EndBlocker
		err := f.App.BillingKeeper.EndBlocker(newCtx)
		require.NoError(t, err)

		// Lease should still be PENDING
		lease, err := f.App.BillingKeeper.GetLease(newCtx, leaseUUID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, lease.State)
	})

	t.Run("lease expires after timeout", func(t *testing.T) {
		// Advance time by 61 seconds (past the timeout)
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(61 * time.Second))

		// Run EndBlocker
		err := f.App.BillingKeeper.EndBlocker(newCtx)
		require.NoError(t, err)

		// Lease should now be EXPIRED
		lease, err := f.App.BillingKeeper.GetLease(newCtx, leaseUUID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_EXPIRED, lease.State)
		require.NotNil(t, lease.ExpiredAt)

		// Pending lease count should be decremented
		creditAccount, err := f.App.BillingKeeper.GetCreditAccount(newCtx, tenant.String())
		require.NoError(t, err)
		require.Equal(t, uint64(0), creditAccount.PendingLeaseCount)
	})
}

// TestLeaseLifecycleEvents tests that proper events are emitted during lease lifecycle.
func TestLeaseLifecycleEvents(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create and acknowledge a lease
	createResp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)

	// Clear events before acknowledge
	f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())

	_, err = msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
		Sender:     providerAddr.String(),
		LeaseUuids: []string{createResp.LeaseUuid},
	})
	require.NoError(t, err)

	// Check for acknowledge event
	events := f.Ctx.EventManager().Events()
	foundAckEvent := false
	for _, event := range events {
		if event.Type == types.EventTypeLeaseAcknowledged {
			foundAckEvent = true
			break
		}
	}
	require.True(t, foundAckEvent, "lease_acknowledged event should be emitted")

	// Create another lease and reject it
	createResp2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)

	// Clear events before reject
	f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())

	_, err = msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
		Sender:     providerAddr.String(),
		LeaseUuids: []string{createResp2.LeaseUuid},
		Reason:     "Test rejection",
	})
	require.NoError(t, err)

	// Check for reject event
	events = f.Ctx.EventManager().Events()
	foundRejectEvent := false
	for _, event := range events {
		if event.Type == types.EventTypeLeaseRejected {
			foundRejectEvent = true
			break
		}
	}
	require.True(t, foundRejectEvent, "lease_rejected event should be emitted")
}

// TestAddressEventAttributesUseCanonicalBech32 verifies that valid uppercase
// wire and persisted SKU spellings never split a single account identity across
// billing events. Public messages remain string-based; event values use the
// canonical spelling returned by the SDK address parser.
func TestAddressEventAttributesUseCanonicalBech32(t *testing.T) {
	f := initFixture(t)
	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	uppercaseTenant := strings.ToUpper(tenant.String())
	uppercaseProvider := strings.ToUpper(providerAddr.String())

	// Supply uppercase wire spellings and verify SKU storage/API normalization,
	// billing authorization, and event attributes all use SDK address identity.
	provider := f.createTestProvider(
		t,
		uppercaseProvider,
		strings.ToUpper(payoutAddr.String()),
	)
	storedProvider, err := f.App.SKUKeeper.GetProvider(f.Ctx, provider.Uuid)
	require.NoError(t, err)
	require.Equal(t, providerAddr.String(), storedProvider.Address)
	require.Equal(t, payoutAddr.String(), storedProvider.PayoutAddress)
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	creditAddr := types.DeriveCreditAddress(tenant)
	f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(testDenom, sdkmath.NewInt(100_000_000))))
	require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	}))

	createPendingLease := func() string {
		t.Helper()
		f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())
		resp, createErr := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: uppercaseTenant,
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, createErr)
		createdEvent := findEvent(t, f.Ctx, types.EventTypeLeaseCreated)
		require.Equal(t, tenant.String(), attrValue(t, createdEvent, types.AttributeKeyTenant))
		return resp.LeaseUuid
	}

	providerLeaseUUID := createPendingLease()
	f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())
	_, err = msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
		// Intentionally differs from the provider's stored uppercase spelling:
		// a raw string authorization check would reject this valid signer.
		Sender:     providerAddr.String(),
		LeaseUuids: []string{providerLeaseUUID},
	})
	require.NoError(t, err)
	acknowledgedEvent := findEvent(t, f.Ctx, types.EventTypeLeaseAcknowledged)
	require.Equal(t, tenant.String(), attrValue(t, acknowledgedEvent, types.AttributeKeyTenant))
	require.Equal(t, providerAddr.String(), attrValue(t, acknowledgedEvent, types.AttributeKeyAcknowledgedBy))

	// Withdrawal attributes and the response canonicalize the SKU module's
	// uppercase payout spelling through the SDK as well.
	f.Ctx = f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(10 * time.Second)).
		WithEventManager(sdk.NewEventManager())
	withdrawResp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
		Sender:     uppercaseProvider,
		LeaseUuids: []string{providerLeaseUUID},
	})
	require.NoError(t, err)
	require.Equal(t, payoutAddr.String(), withdrawResp.PayoutAddress)
	withdrawEvent := findEvent(t, f.Ctx, types.EventTypeProviderWithdraw)
	require.Equal(t, payoutAddr.String(), attrValue(t, withdrawEvent, types.AttributeKeyPayoutAddress))

	rejectedLeaseUUID := createPendingLease()
	f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())
	_, err = msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
		// Pin byte-identity authorization on rejection independently as well.
		Sender:     providerAddr.String(),
		LeaseUuids: []string{rejectedLeaseUUID},
		Reason:     "canonical address event regression",
	})
	require.NoError(t, err)
	rejectedEvent := findEvent(t, f.Ctx, types.EventTypeLeaseRejected)
	require.Equal(t, tenant.String(), attrValue(t, rejectedEvent, types.AttributeKeyTenant))
	require.Equal(t, providerAddr.String(), attrValue(t, rejectedEvent, types.AttributeKeyRejectedBy))

	cancelledLeaseUUID := createPendingLease()
	f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())
	_, err = msgServer.CancelLease(f.Ctx, &types.MsgCancelLease{
		Tenant:     uppercaseTenant,
		LeaseUuids: []string{cancelledLeaseUUID},
	})
	require.NoError(t, err)
	cancelledEvent := findEvent(t, f.Ctx, types.EventTypeLeaseCancelled)
	require.Equal(t, tenant.String(), attrValue(t, cancelledEvent, types.AttributeKeyTenant))
	require.Equal(t, tenant.String(), attrValue(t, cancelledEvent, types.AttributeKeyCancelledBy))

	authorityLeaseUUID := createPendingLease()
	f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())
	_, err = msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
		Sender:     strings.ToUpper(f.Authority.String()),
		LeaseUuids: []string{authorityLeaseUUID},
	})
	require.NoError(t, err)
	authorityEvent := findEvent(t, f.Ctx, types.EventTypeLeaseAcknowledged)
	require.Equal(t, f.Authority.String(), attrValue(t, authorityEvent, types.AttributeKeyAcknowledgedBy))

	// Exercise the specific-lease batch summary and provider-wide summary sites,
	// which both source payout_address from the same persisted SKU value.
	f.Ctx = f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(10 * time.Second)).
		WithEventManager(sdk.NewEventManager())
	batchWithdrawResp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
		Sender:     uppercaseProvider,
		LeaseUuids: []string{providerLeaseUUID, authorityLeaseUUID},
	})
	require.NoError(t, err)
	require.Equal(t, payoutAddr.String(), batchWithdrawResp.PayoutAddress)
	batchWithdrawEvent := findEvent(t, f.Ctx, types.EventTypeBatchWithdraw)
	require.Equal(t, payoutAddr.String(), attrValue(t, batchWithdrawEvent, types.AttributeKeyPayoutAddress))

	f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())
	providerWithdrawResp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
		Sender:       uppercaseProvider,
		ProviderUuid: provider.Uuid,
	})
	require.NoError(t, err)
	require.Equal(t, payoutAddr.String(), providerWithdrawResp.PayoutAddress)
	providerWithdrawEvent := findEvent(t, f.Ctx, types.EventTypeBatchWithdraw)
	require.Equal(t, payoutAddr.String(), attrValue(t, providerWithdrawEvent, types.AttributeKeyPayoutAddress))
}

// TestMsgCreateLease_AllSKUsSameProvider tests that all SKUs in a lease must be from the same provider.
func TestMsgCreateLease_AllSKUsSameProvider(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	provider1Addr := f.TestAccs[1]
	provider2Addr := f.TestAccs[2]
	payout1Addr := f.TestAccs[3]
	payout2Addr := f.TestAccs[4]
	denom := testDenom

	// Create two different providers
	provider1 := f.createTestProvider(t, provider1Addr.String(), payout1Addr.String())
	provider2 := f.createTestProvider(t, provider2Addr.String(), payout2Addr.String())

	// Create SKUs for each provider
	sku1 := f.createTestSKU(t, provider1.Uuid, 3600)
	sku2 := f.createTestSKUWithDenom(t, provider2.Uuid, 3600, testDenom)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	t.Run("fail: SKUs from different providers", func(t *testing.T) {
		_, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{SkuUuid: sku1.Uuid, Quantity: 1}, // Provider 1
				{SkuUuid: sku2.Uuid, Quantity: 1}, // Provider 2
			},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "all SKUs in a lease must belong to the same provider")
	})

	t.Run("success: all SKUs from same provider", func(t *testing.T) {
		// Create another SKU for provider 1
		sku1b := f.createTestSKU(t, provider1.Uuid, 7200)

		resp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{SkuUuid: sku1.Uuid, Quantity: 1},
				{SkuUuid: sku1b.Uuid, Quantity: 1},
			},
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
	})
}

// TestMsgCreateLease_MaxLeasesLimit tests the max active leases per tenant limit.
func TestMsgCreateLease_MaxLeasesLimit(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Set params with low max leases (this uses MaxLeasesPerTenant, not MaxPendingLeasesPerTenant)
	params := types.DefaultParams()
	params.MaxLeasesPerTenant = 2
	err := f.App.BillingKeeper.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	// Create credit account with ActiveLeaseCount already at max-1
	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:           tenant.String(),
		CreditAddress:    creditAddr.String(),
		ActiveLeaseCount: 2, // Already at max
	})
	require.NoError(t, err)

	t.Run("fail: max leases reached", func(t *testing.T) {
		_, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "max")
	})
}

// TestEndBlockerMultiplePendingLeases tests that EndBlocker correctly handles multiple pending leases.
func TestEndBlockerMultiplePendingLeases(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Set a short pending timeout for testing (60 seconds)
	params := types.DefaultParams()
	params.PendingTimeout = 60 // 60 seconds
	params.MaxPendingLeasesPerTenant = 5
	err := f.App.BillingKeeper.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create 3 leases at different times
	var leaseUUIDs []string

	// Lease 1 at t=0
	createResp1, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	leaseUUIDs = append(leaseUUIDs, createResp1.LeaseUuid)

	// Advance time by 20 seconds for lease 2
	ctx20 := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(20 * time.Second))

	// Lease 2 at t=20
	createResp2, err := msgServer.CreateLease(ctx20, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	leaseUUIDs = append(leaseUUIDs, createResp2.LeaseUuid)

	// Advance time by 40 seconds for lease 3
	ctx40 := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(40 * time.Second))

	// Lease 3 at t=40
	createResp3, err := msgServer.CreateLease(ctx40, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	leaseUUIDs = append(leaseUUIDs, createResp3.LeaseUuid)

	// Verify all 3 leases are pending
	creditAccount, err := f.App.BillingKeeper.GetCreditAccount(ctx40, tenant.String())
	require.NoError(t, err)
	require.Equal(t, uint64(3), creditAccount.PendingLeaseCount)

	t.Run("only first lease expires at t=61", func(t *testing.T) {
		// At t=61, only lease 1 should expire (created at t=0, timeout is 60s)
		ctx61 := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(61 * time.Second))

		err := f.App.BillingKeeper.EndBlocker(ctx61)
		require.NoError(t, err)

		// Lease 1 should be EXPIRED
		lease1, err := f.App.BillingKeeper.GetLease(ctx61, leaseUUIDs[0])
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_EXPIRED, lease1.State)

		// Lease 2 and 3 should still be PENDING
		lease2, err := f.App.BillingKeeper.GetLease(ctx61, leaseUUIDs[1])
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, lease2.State)

		lease3, err := f.App.BillingKeeper.GetLease(ctx61, leaseUUIDs[2])
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, lease3.State)

		// Pending count should be 2
		creditAccount, err := f.App.BillingKeeper.GetCreditAccount(ctx61, tenant.String())
		require.NoError(t, err)
		require.Equal(t, uint64(2), creditAccount.PendingLeaseCount)
	})

	t.Run("all leases expire at t=101", func(t *testing.T) {
		// At t=101, all leases should be expired
		// Lease 1: created at t=0, expired at t=60
		// Lease 2: created at t=20, expires at t=80
		// Lease 3: created at t=40, expires at t=100
		ctx101 := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(101 * time.Second))

		err := f.App.BillingKeeper.EndBlocker(ctx101)
		require.NoError(t, err)

		// All leases should be EXPIRED
		for _, leaseUUID := range leaseUUIDs {
			lease, err := f.App.BillingKeeper.GetLease(ctx101, leaseUUID)
			require.NoError(t, err)
			require.Equal(t, types.LEASE_STATE_EXPIRED, lease.State, "lease %s should be expired", leaseUUID)
		}

		// Pending count should be 0
		creditAccount, err := f.App.BillingKeeper.GetCreditAccount(ctx101, tenant.String())
		require.NoError(t, err)
		require.Equal(t, uint64(0), creditAccount.PendingLeaseCount)
	})
}

// TestEndBlockerCreditRefund tests that expired leases properly manage credit accounts.
// Note: PENDING leases do NOT lock credit - credit is only consumed when lease is ACTIVE.
func TestEndBlockerCreditRefund(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Set a short pending timeout for testing (60 seconds)
	params := types.DefaultParams()
	params.PendingTimeout = 60
	err := f.App.BillingKeeper.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create provider and SKU with known price
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 = 1 token per second

	// Fund tenant's credit account with exact amount needed
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	initialBalance := sdk.NewCoin(denom, sdkmath.NewInt(50000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(initialBalance))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Get initial balance
	balanceBefore := f.App.BankKeeper.GetBalance(f.Ctx, creditAddr, denom)
	t.Logf("Balance before lease: %s", balanceBefore)

	// Create a lease
	createResp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	leaseUUID := createResp.LeaseUuid

	// Get the lease to see the locked price
	lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseUUID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_PENDING, lease.State)
	t.Logf("Lease locked price per second: %v", lease.Items[0].LockedPrice)

	// Balance should NOT be reduced for PENDING leases - credit is only consumed when ACTIVE
	balanceAfterCreate := f.App.BankKeeper.GetBalance(f.Ctx, creditAddr, denom)
	t.Logf("Balance after lease creation (PENDING): %s", balanceAfterCreate)
	require.Equal(t, balanceBefore.Amount, balanceAfterCreate.Amount,
		"balance should NOT decrease for PENDING lease - credit not locked until acknowledged")

	// Verify pending lease count increased
	creditAccount, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, uint64(1), creditAccount.PendingLeaseCount)

	// Now expire the lease
	ctx61 := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(61 * time.Second))
	err = f.App.BillingKeeper.EndBlocker(ctx61)
	require.NoError(t, err)

	// Verify lease is expired
	expiredLease, err := f.App.BillingKeeper.GetLease(ctx61, leaseUUID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_EXPIRED, expiredLease.State)

	// Balance should be unchanged (no credit was consumed)
	balanceAfterExpire := f.App.BankKeeper.GetBalance(ctx61, creditAddr, denom)
	t.Logf("Balance after expiration: %s", balanceAfterExpire)
	require.Equal(t, balanceBefore.Amount, balanceAfterExpire.Amount,
		"balance should be unchanged - PENDING leases don't consume credit")

	// Pending lease count should be decremented
	creditAccount, err = f.App.BillingKeeper.GetCreditAccount(ctx61, tenant.String())
	require.NoError(t, err)
	require.Equal(t, uint64(0), creditAccount.PendingLeaseCount)
}

// TestEndBlockerDoesNotExpireAcknowledgedLeases tests that acknowledged leases are not expired.
func TestEndBlockerDoesNotExpireAcknowledgedLeases(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Set a short pending timeout for testing (60 seconds)
	params := types.DefaultParams()
	params.PendingTimeout = 60
	err := f.App.BillingKeeper.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create and acknowledge a lease
	leaseUUID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr,
		[]types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}})

	// Verify lease is ACTIVE
	lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseUUID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_ACTIVE, lease.State)

	// Run EndBlocker well past the timeout
	ctx200 := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(200 * time.Second))
	err = f.App.BillingKeeper.EndBlocker(ctx200)
	require.NoError(t, err)

	// Lease should still be ACTIVE (not expired because it was acknowledged)
	lease, err = f.App.BillingKeeper.GetLease(ctx200, leaseUUID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_ACTIVE, lease.State,
		"acknowledged lease should not be expired by EndBlocker")
}

// TestEndBlockerExpiredLeaseQueryFilter tests querying expired leases by state.
func TestEndBlockerExpiredLeaseQueryFilter(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Set a short pending timeout for testing
	params := types.DefaultParams()
	params.PendingTimeout = 60
	err := f.App.BillingKeeper.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create a pending lease
	createResp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	leaseUUID := createResp.LeaseUuid

	// Expire the lease
	ctx61 := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(61 * time.Second))
	err = f.App.BillingKeeper.EndBlocker(ctx61)
	require.NoError(t, err)

	// Query lease directly - should be expired
	lease, err := f.App.BillingKeeper.GetLease(ctx61, leaseUUID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_EXPIRED, lease.State)
	require.NotNil(t, lease.ExpiredAt)
	require.False(t, lease.ExpiredAt.IsZero())
}

// TestEndBlockerRateLimiting tests that EndBlocker respects the rate limit
// and processes at most MaxPendingLeaseExpirationsPerBlock leases per block.
// This also verifies the iterator-based implementation works correctly without
// loading all pending leases into memory at once.
func TestEndBlockerRateLimiting(t *testing.T) {
	f := initFixture(t)

	k := f.App.BillingKeeper
	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Set a short pending timeout for testing (60 seconds)
	params := types.DefaultParams()
	params.PendingTimeout = 60
	params.MaxPendingLeasesPerTenant = 200 // Allow many leases for this test
	err := k.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account with enough for many leases
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(1000000000000)) // 1 trillion
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = k.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Create 150 pending leases directly (more than MaxPendingLeaseExpirationsPerBlock = 100)
	// Using direct SetLease to avoid message validation overhead for bulk creation
	const numLeases = 150
	leaseUUIDs := make([]string, numLeases)
	baseTime := f.Ctx.BlockTime()
	totalReservation := sdk.NewCoins()

	for i := 0; i < numLeases; i++ {
		leaseUUID := fmt.Sprintf("rate-limit-test-lease-%03d", i)
		leaseUUIDs[i] = leaseUUID

		lease := types.Lease{
			Uuid:         leaseUUID,
			Tenant:       tenant.String(),
			ProviderUuid: provider.Uuid,
			Items: []types.LeaseItem{
				{
					SkuUuid:     sku.Uuid,
					Quantity:    1,
					LockedPrice: sdk.NewCoin(denom, sdkmath.NewInt(1)),
				},
			},
			State:                      types.LEASE_STATE_PENDING,
			CreatedAt:                  baseTime, // All created at same time
			LastSettledAt:              baseTime,
			AcknowledgedAt:             nil,
			ClosedAt:                   nil,
			ExpiredAt:                  nil,
			MinLeaseDurationAtCreation: params.MinLeaseDuration,
		}
		reservation := getLeaseReservationAmount(t, &lease, params.MinLeaseDuration)
		lease.Reservation = &types.LeaseReservation{
			RemainingAmounts: append(sdk.Coins(nil), reservation...),
		}
		totalReservation = addTestReservation(t, totalReservation, reservation)
		err := k.SetLease(f.Ctx, lease)
		require.NoError(t, err)
	}
	creditAccount, err := k.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	creditAccount.PendingLeaseCount = uint64(numLeases)
	creditAccount.ReservedAmounts = totalReservation
	require.NoError(t, k.SetCreditAccount(f.Ctx, creditAccount))

	// Verify all 150 leases are pending
	pendingLeases, err := k.GetPendingLeases(f.Ctx)
	require.NoError(t, err)
	require.Len(t, pendingLeases, numLeases, "should have %d pending leases", numLeases)

	// Advance time past the pending timeout (60 seconds)
	expiredCtx := f.Ctx.WithBlockTime(baseTime.Add(61 * time.Second))

	t.Run("first EndBlocker call processes exactly rate limit", func(t *testing.T) {
		err := k.EndBlocker(expiredCtx)
		require.NoError(t, err)

		// Count expired vs still pending
		stillPending, err := k.GetPendingLeases(expiredCtx)
		require.NoError(t, err)

		expiredCount := numLeases - len(stillPending)
		require.Equal(t, types.MaxPendingLeaseExpirationsPerBlock, expiredCount,
			"should expire exactly %d leases (rate limit)", types.MaxPendingLeaseExpirationsPerBlock)
		require.Equal(t, 50, len(stillPending), "should have 50 leases still pending")
	})

	t.Run("second EndBlocker call processes remaining leases", func(t *testing.T) {
		err := k.EndBlocker(expiredCtx)
		require.NoError(t, err)

		// All should now be expired
		stillPending, err := k.GetPendingLeases(expiredCtx)
		require.NoError(t, err)
		require.Len(t, stillPending, 0, "all leases should be expired after second EndBlocker")

		// Verify all leases are in EXPIRED state
		for _, leaseUUID := range leaseUUIDs {
			lease, err := k.GetLease(expiredCtx, leaseUUID)
			require.NoError(t, err)
			require.Equal(t, types.LEASE_STATE_EXPIRED, lease.State,
				"lease %s should be expired", leaseUUID)
		}
	})
}

// TestEndBlockerIteratorDoesNotLoadAll verifies that the iterator-based
// EndBlocker processes leases one-by-one and stops at the rate limit,
// even when only some leases are expired.
func TestEndBlockerIteratorDoesNotLoadAll(t *testing.T) {
	f := initFixture(t)

	k := f.App.BillingKeeper
	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Set pending timeout for testing
	params := types.DefaultParams()
	params.PendingTimeout = 60
	params.MaxPendingLeasesPerTenant = 200
	err := k.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant's credit account
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(1000000000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = k.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	baseTime := f.Ctx.BlockTime()
	totalReservation := sdk.NewCoins()

	// Create 50 leases that will be expired (created at baseTime)
	expiredLeaseUUIDs := make([]string, 50)
	for i := 0; i < 50; i++ {
		leaseUUID := fmt.Sprintf("expired-lease-%03d", i)
		expiredLeaseUUIDs[i] = leaseUUID

		lease := types.Lease{
			Uuid:                       leaseUUID,
			Tenant:                     tenant.String(),
			ProviderUuid:               provider.Uuid,
			Items:                      []types.LeaseItem{{SkuUuid: sku.Uuid, Quantity: 1, LockedPrice: sdk.NewCoin(denom, sdkmath.NewInt(1))}},
			State:                      types.LEASE_STATE_PENDING,
			CreatedAt:                  baseTime, // Will be expired
			LastSettledAt:              baseTime,
			MinLeaseDurationAtCreation: params.MinLeaseDuration,
		}
		reservation := getLeaseReservationAmount(t, &lease, params.MinLeaseDuration)
		lease.Reservation = &types.LeaseReservation{
			RemainingAmounts: append(sdk.Coins(nil), reservation...),
		}
		totalReservation = addTestReservation(t, totalReservation, reservation)
		err := k.SetLease(f.Ctx, lease)
		require.NoError(t, err)
	}

	// Create 50 leases that will NOT be expired (created in the future relative to check time)
	notExpiredLeaseUUIDs := make([]string, 50)
	futureTime := baseTime.Add(30 * time.Second)
	for i := 0; i < 50; i++ {
		leaseUUID := fmt.Sprintf("not-expired-lease-%03d", i)
		notExpiredLeaseUUIDs[i] = leaseUUID

		lease := types.Lease{
			Uuid:                       leaseUUID,
			Tenant:                     tenant.String(),
			ProviderUuid:               provider.Uuid,
			Items:                      []types.LeaseItem{{SkuUuid: sku.Uuid, Quantity: 1, LockedPrice: sdk.NewCoin(denom, sdkmath.NewInt(1))}},
			State:                      types.LEASE_STATE_PENDING,
			CreatedAt:                  futureTime, // Created 30s later, won't be expired yet
			LastSettledAt:              futureTime,
			MinLeaseDurationAtCreation: params.MinLeaseDuration,
		}
		reservation := getLeaseReservationAmount(t, &lease, params.MinLeaseDuration)
		lease.Reservation = &types.LeaseReservation{
			RemainingAmounts: append(sdk.Coins(nil), reservation...),
		}
		totalReservation = addTestReservation(t, totalReservation, reservation)
		err := k.SetLease(f.Ctx, lease)
		require.NoError(t, err)
	}
	creditAccount, err := k.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	creditAccount.PendingLeaseCount = 100
	creditAccount.ReservedAmounts = totalReservation
	require.NoError(t, k.SetCreditAccount(f.Ctx, creditAccount))

	// Verify we have 100 pending leases total
	pendingLeases, err := k.GetPendingLeases(f.Ctx)
	require.NoError(t, err)
	require.Len(t, pendingLeases, 100)

	// Advance time to expire only the first batch (61 seconds from baseTime)
	// The second batch was created at baseTime+30s, so timeout is at baseTime+90s
	checkCtx := f.Ctx.WithBlockTime(baseTime.Add(61 * time.Second))

	t.Run("EndBlocker only expires eligible leases", func(t *testing.T) {
		err := k.EndBlocker(checkCtx)
		require.NoError(t, err)

		// Check expired leases
		for _, leaseUUID := range expiredLeaseUUIDs {
			lease, err := k.GetLease(checkCtx, leaseUUID)
			require.NoError(t, err)
			require.Equal(t, types.LEASE_STATE_EXPIRED, lease.State,
				"lease %s should be expired", leaseUUID)
		}

		// Check not-expired leases are still pending
		for _, leaseUUID := range notExpiredLeaseUUIDs {
			lease, err := k.GetLease(checkCtx, leaseUUID)
			require.NoError(t, err)
			require.Equal(t, types.LEASE_STATE_PENDING, lease.State,
				"lease %s should still be pending", leaseUUID)
		}

		// Verify counts
		stillPending, err := k.GetPendingLeases(checkCtx)
		require.NoError(t, err)
		require.Len(t, stillPending, 50, "50 leases should still be pending")
	})
}

// newExpiryFixture sets up a fixture with a provider, an SKU, and a funded tenant
// (TestAccs[0]) credit account, plus the given pending timeout, for EndBlocker
// pending-lease expiration tests. It returns the fixture along with the provider
// UUID, SKU UUID, denom, and the fixture's base block time.
func newExpiryFixture(t *testing.T) (*testFixture, string, string, string, time.Time) {
	t.Helper()
	f := initFixture(t)
	k := f.App.BillingKeeper

	params := types.DefaultParams()
	params.PendingTimeout = 60
	params.MaxPendingLeasesPerTenant = 500
	require.NoError(t, k.SetParams(f.Ctx, params))

	provider := f.createTestProvider(t, f.TestAccs[1].String(), f.TestAccs[2].String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	tenant := f.TestAccs[0]
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(testDenom, sdkmath.NewInt(1_000_000_000_000))))
	require.NoError(t, k.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	}))

	return f, provider.Uuid, sku.Uuid, testDenom, f.Ctx.BlockTime()
}

// setPendingLease writes a PENDING lease with an explicit UUID and created_at
// directly to state (bypassing message validation) so expiration tests can
// control the (state, created_at) index key precisely.
func (f *testFixture) setPendingLease(t *testing.T, uuid, providerUUID, skuUUID, denom string, createdAt time.Time) {
	t.Helper()
	params, err := f.App.BillingKeeper.GetParams(f.Ctx)
	require.NoError(t, err)

	lease := types.Lease{
		Uuid:                       uuid,
		Tenant:                     f.TestAccs[0].String(),
		ProviderUuid:               providerUUID,
		Items:                      []types.LeaseItem{{SkuUuid: skuUUID, Quantity: 1, LockedPrice: sdk.NewCoin(denom, sdkmath.NewInt(1))}},
		State:                      types.LEASE_STATE_PENDING,
		CreatedAt:                  createdAt,
		LastSettledAt:              createdAt,
		MinLeaseDurationAtCreation: params.MinLeaseDuration,
	}
	reservation := getLeaseReservationAmount(t, &lease, params.MinLeaseDuration)
	lease.Reservation = &types.LeaseReservation{
		RemainingAmounts: append(sdk.Coins(nil), reservation...),
	}
	require.NoError(t, f.App.BillingKeeper.SetLease(f.Ctx, lease))

	// Mirror CreateLease's credit-account side effects so EndBlocker expiry finds a
	// consistent account: bump the pending count and reserve credit using the same
	// amount ExpirePendingLease will release. Without this, expiry logs
	// "data inconsistency" warnings (pending count already zero / reservation underflow).
	ca, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, lease.Tenant)
	require.NoError(t, err)
	ca.PendingLeaseCount++
	ca.ReservedAmounts = addTestReservation(t, ca.ReservedAmounts, reservation)
	require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, ca))
}

// TestEndBlocker_ExpiresByCreatedAtNotUUIDOrder verifies that the range-bounded
// EndBlocker scan selects leases to expire by created_at, not by UUID string
// order. The StateCreatedAt index is keyed ((state, created_at), uuid); the fix
// ranges over created_at, so a lexicographically-small UUID with a large
// created_at must not be expired ahead of an older lease with a larger UUID.
func TestEndBlocker_ExpiresByCreatedAtNotUUIDOrder(t *testing.T) {
	f, providerUUID, skuUUID, denom, baseTime := newExpiryFixture(t)
	k := f.App.BillingKeeper

	// UUID string order deliberately DISAGREES with created_at order:
	// "aaa-young" (created later) sorts before "zzz-old" (created earlier). Both
	// created_at values stay <= the EndBlocker block time (baseTime+61s) — as they
	// always are in production — while the young one stays above the expiry cutoff.
	f.setPendingLease(t, "zzz-old", providerUUID, skuUUID, denom, baseTime)
	f.setPendingLease(t, "aaa-young", providerUUID, skuUUID, denom, baseTime.Add(30*time.Second))

	// At baseTime+61s the old lease (created at baseTime) is past its 60s timeout;
	// the young one (created at +30s, cutoff is +1s) is not.
	ctx := f.Ctx.WithBlockTime(baseTime.Add(61 * time.Second))
	require.NoError(t, k.EndBlocker(ctx))

	oldLease, err := k.GetLease(ctx, "zzz-old")
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_EXPIRED, oldLease.State,
		"older lease must expire regardless of UUID string order")

	youngLease, err := k.GetLease(ctx, "aaa-young")
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_PENDING, youngLease.State,
		"younger lease must remain pending even though its UUID sorts first")
}

// TestEndBlocker_CutoffBoundaryIsStrict verifies that expiry is strict: a lease
// whose created_at equals exactly (blockTime - pendingTimeout) is NOT expired,
// while one nanosecond past the cutoff is. This locks the EndExclusive upper
// bound of the range and the blockTime.After(...) check.
func TestEndBlocker_CutoffBoundaryIsStrict(t *testing.T) {
	f, providerUUID, skuUUID, denom, baseTime := newExpiryFixture(t)
	k := f.App.BillingKeeper

	f.setPendingLease(t, "boundary-lease", providerUUID, skuUUID, denom, baseTime)

	// Exactly at created_at + timeout: not expired (created_at == cutoff).
	atCutoff := f.Ctx.WithBlockTime(baseTime.Add(60 * time.Second))
	require.NoError(t, k.EndBlocker(atCutoff))
	lease, err := k.GetLease(atCutoff, "boundary-lease")
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_PENDING, lease.State,
		"lease exactly at the timeout must not expire")

	// One nanosecond past the cutoff: expired.
	pastCutoff := f.Ctx.WithBlockTime(baseTime.Add(60*time.Second + time.Nanosecond))
	require.NoError(t, k.EndBlocker(pastCutoff))
	lease, err = k.GetLease(pastCutoff, "boundary-lease")
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_EXPIRED, lease.State,
		"lease one nanosecond past the timeout must expire")
}

// TestEndBlocker_YoungBacklogDoesNotBlockExpiry is the motivating scenario: a
// large backlog of not-yet-expired (young) pending leases must neither be scanned
// into the expiration set nor prevent the few expirable (old) leases from being
// expired. UUIDs are arranged so the young leases sort before the old ones, to
// prove the range bounds — not iteration luck — drive the result.
func TestEndBlocker_YoungBacklogDoesNotBlockExpiry(t *testing.T) {
	f, providerUUID, skuUUID, denom, baseTime := newExpiryFixture(t)
	k := f.App.BillingKeeper

	oldUUIDs := make([]string, 5)
	for i := range oldUUIDs {
		oldUUIDs[i] = fmt.Sprintf("zzz-old-%02d", i)
		f.setPendingLease(t, oldUUIDs[i], providerUUID, skuUUID, denom, baseTime)
	}
	// Young leases: created_at stays <= the EndBlocker block time (baseTime+61s, as
	// in production) but above the expiry cutoff (baseTime+1s), so they are not
	// expirable and must be excluded from the scan.
	youngUUIDs := make([]string, 300)
	for i := range youngUUIDs {
		youngUUIDs[i] = fmt.Sprintf("aaa-young-%03d", i)
		f.setPendingLease(t, youngUUIDs[i], providerUUID, skuUUID, denom, baseTime.Add(30*time.Second))
	}

	ctx := f.Ctx.WithBlockTime(baseTime.Add(61 * time.Second))
	require.NoError(t, k.EndBlocker(ctx))

	for _, u := range oldUUIDs {
		lease, err := k.GetLease(ctx, u)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_EXPIRED, lease.State, "old lease %s must expire", u)
	}
	for _, u := range youngUUIDs {
		lease, err := k.GetLease(ctx, u)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, lease.State, "young lease %s must remain pending", u)
	}
	stillPending, err := k.GetPendingLeases(ctx)
	require.NoError(t, err)
	require.Len(t, stillPending, 300, "only the 5 old leases should expire; the 300 young leases remain")
}

func TestEndBlocker_StaleTerminalIndexRowsDoNotConsumeExpirationLimit(t *testing.T) {
	f, providerUUID, skuUUID, denom, baseTime := newExpiryFixture(t)
	k := f.App.BillingKeeper
	params, err := k.GetParams(f.Ctx)
	require.NoError(t, err)

	staleCreatedAt := baseTime.Add(-time.Minute)
	closedAt := baseTime
	for i := range types.MaxPendingLeaseExpirationsPerBlock {
		lease := types.Lease{
			Uuid:         fmt.Sprintf("stale-terminal-%03d", i),
			Tenant:       f.TestAccs[0].String(),
			ProviderUuid: providerUUID,
			Items: []types.LeaseItem{{
				SkuUuid:     skuUUID,
				Quantity:    1,
				LockedPrice: sdk.NewCoin(denom, sdkmath.NewInt(1)),
			}},
			State:                      types.LEASE_STATE_CLOSED,
			CreatedAt:                  staleCreatedAt,
			LastSettledAt:              closedAt,
			ClosedAt:                   &closedAt,
			MinLeaseDurationAtCreation: params.MinLeaseDuration,
			Reservation:                &types.LeaseReservation{RemainingAmounts: sdk.NewCoins()},
		}
		require.NoError(t, k.SetLease(f.Ctx, lease))

		stalePendingReference := lease
		stalePendingReference.State = types.LEASE_STATE_PENDING
		require.NoError(t, k.Leases.Indexes.StateCreatedAt.Reference(
			f.Ctx,
			lease.Uuid,
			stalePendingReference,
			func() (types.Lease, error) { return types.Lease{}, collections.ErrNotFound },
		))
	}

	const realExpiredUUID = "real-expired-behind-stale-rows"
	f.setPendingLease(t, realExpiredUUID, providerUUID, skuUUID, denom, baseTime)
	ctx := f.Ctx.WithBlockTime(baseTime.Add(61 * time.Second))
	require.NoError(t, k.EndBlocker(ctx))

	lease, err := k.GetLease(ctx, realExpiredUUID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_EXPIRED, lease.State,
		"stale terminal index rows must not consume the expiration quota")
}

func TestEndBlocker_UUIDMismatchIsSkippedWithoutBlockingValidExpiry(t *testing.T) {
	f, providerUUID, skuUUID, denom, baseTime := newExpiryFixture(t)
	k := f.App.BillingKeeper

	const (
		mismatchedPrimaryUUID = "aaa-mismatched-primary"
		mismatchedValueUUID   = "different-stored-uuid"
		validUUID             = "zzz-valid-expired"
	)
	f.setPendingLease(t, mismatchedPrimaryUUID, providerUUID, skuUUID, denom, baseTime)
	f.setPendingLease(t, validUUID, providerUUID, skuUUID, denom, baseTime)

	corruptLease, err := k.Leases.Get(f.Ctx, mismatchedPrimaryUUID)
	require.NoError(t, err)
	corruptLease.Uuid = mismatchedValueUUID
	require.NoError(t, k.Leases.Set(f.Ctx, mismatchedPrimaryUUID, corruptLease))

	ctx := f.Ctx.WithBlockTime(baseTime.Add(61 * time.Second))
	require.NoError(t, k.EndBlocker(ctx))

	unchanged, err := k.Leases.Get(ctx, mismatchedPrimaryUUID)
	require.NoError(t, err)
	require.Equal(t, mismatchedValueUUID, unchanged.Uuid)
	require.Equal(t, types.LEASE_STATE_PENDING, unchanged.State,
		"a UUID-mismatched primary must not be transitioned under either identity")

	valid, err := k.GetLease(ctx, validUUID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_EXPIRED, valid.State,
		"a corrupt row must not block a later valid expiration")

	account, err := k.GetCreditAccount(ctx, f.TestAccs[0].String())
	require.NoError(t, err)
	require.Equal(t, uint64(1), account.PendingLeaseCount,
		"only the skipped corrupt lease remains pending")
}

// TestMsgWithdraw_ProviderWideMode tests the provider-wide withdrawal mode using --provider flag.
func TestMsgWithdraw_ProviderWideMode(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU with 1 unit per second rate
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	// Fund tenant's credit account generously
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	t.Run("success: provider-wide withdrawal from multiple leases", func(t *testing.T) {
		// Create and acknowledge 3 leases
		lease1 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})
		lease2 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})
		lease3 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		// Advance block time by 100 seconds
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
		f.Ctx = newCtx

		// Get initial balance
		initialBalance := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom)

		// Withdraw using provider-wide mode (no lease UUIDs, just provider UUID)
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       providerAddr.String(),
			ProviderUuid: provider.Uuid,
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, payoutAddr.String(), resp.PayoutAddress)
		require.Equal(t, uint64(3), resp.WithdrawalCount)
		require.False(t, resp.TotalAmounts.IsZero())
		require.False(t, resp.HasMore) // Only 3 leases, default limit is 50

		// Verify total balance increased
		newBalance := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom)
		require.True(t, newBalance.Amount.GT(initialBalance.Amount))

		// Verify each lease was settled (last_settled_at updated)
		for _, leaseUUID := range []string{lease1, lease2, lease3} {
			lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseUUID)
			require.NoError(t, err)
			require.Equal(t, f.Ctx.BlockTime(), lease.LastSettledAt)
		}
	})

	t.Run("success: pagination with limit parameter", func(t *testing.T) {
		// Create 5 more leases
		for i := 0; i < 5; i++ {
			f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
				{SkuUuid: sku.Uuid, Quantity: 1},
			})
		}

		// Advance time so there's something to withdraw
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
		f.Ctx = newCtx

		// Withdraw with limit=2
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       providerAddr.String(),
			ProviderUuid: provider.Uuid,
			Limit:        2,
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, uint64(2), resp.WithdrawalCount)
		require.True(t, resp.HasMore) // More leases remain
	})

	t.Run("success: has_more is false when all leases processed", func(t *testing.T) {
		// Advance time
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
		f.Ctx = newCtx

		// Withdraw with high limit (more than total leases)
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       providerAddr.String(),
			ProviderUuid: provider.Uuid,
			Limit:        100,
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.False(t, resp.HasMore) // All leases processed
	})

	t.Run("success: skips pending leases", func(t *testing.T) {
		// Create a new provider for isolation
		provider2Addr := f.TestAccs[3]
		provider2 := f.createTestProvider(t, provider2Addr.String(), provider2Addr.String())
		sku2 := f.createTestSKU(t, provider2.Uuid, 3600)

		// Create a lease but don't acknowledge it (stays PENDING)
		createResp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku2.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)

		// Verify it's pending
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, createResp.LeaseUuid)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_PENDING, lease.State)

		// Advance time
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
		f.Ctx = newCtx

		// Provider-wide withdraw should return 0 (pending leases are skipped)
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       provider2Addr.String(),
			ProviderUuid: provider2.Uuid,
		})
		require.NoError(t, err)
		require.Equal(t, uint64(0), resp.WithdrawalCount)
		require.True(t, resp.TotalAmounts.IsZero())
	})

	t.Run("success: closed leases are already settled and skipped", func(t *testing.T) {
		// Create a new provider for isolation
		provider3Addr := f.TestAccs[4]
		provider3 := f.createTestProvider(t, provider3Addr.String(), provider3Addr.String())
		sku3 := f.createTestSKU(t, provider3.Uuid, 3600)

		// Create and acknowledge a lease
		leaseUUID := f.createAndAcknowledgeLease(t, msgServer, tenant, provider3Addr, []types.LeaseItemInput{
			{SkuUuid: sku3.Uuid, Quantity: 1},
		})

		// Advance time
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
		f.Ctx = newCtx

		// Close the lease (this settles it)
		_, err := msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
			Sender:     tenant.String(),
			LeaseUuids: []string{leaseUUID},
		})
		require.NoError(t, err)

		// Provider-wide withdraw skips CLOSED leases (already settled at close).
		// (nothing more to withdraw since close already settled)
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       provider3Addr.String(),
			ProviderUuid: provider3.Uuid,
		})
		require.NoError(t, err)
		// Should succeed but nothing to withdraw (already settled during close)
		require.Equal(t, uint64(0), resp.WithdrawalCount)
	})

	t.Run("fail: invalid provider UUID", func(t *testing.T) {
		_, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       providerAddr.String(),
			ProviderUuid: "00000000-0000-7000-8000-000000000000",
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not found")
	})

	t.Run("fail: unauthorized sender", func(t *testing.T) {
		// Use tenant as an unauthorized sender for provider-wide withdrawal
		_, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       tenant.String(), // tenant is not provider
			ProviderUuid: provider.Uuid,
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "not authorized")
	})

	t.Run("success: authority can withdraw on behalf of provider", func(t *testing.T) {
		// Create a new provider for isolation (reuse payoutAddr as provider address)
		provider4 := f.createTestProvider(t, payoutAddr.String(), payoutAddr.String())
		sku4 := f.createTestSKU(t, provider4.Uuid, 3600)

		// Create and acknowledge a lease
		f.createAndAcknowledgeLease(t, msgServer, tenant, payoutAddr, []types.LeaseItemInput{
			{SkuUuid: sku4.Uuid, Quantity: 1},
		})

		// Advance time
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
		f.Ctx = newCtx

		// Authority withdraws on behalf of provider
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       f.App.BillingKeeper.GetAuthority(),
			ProviderUuid: provider4.Uuid,
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, uint64(1), resp.WithdrawalCount)
		require.Equal(t, payoutAddr.String(), resp.PayoutAddress)
	})

	t.Run("fail: cannot specify both lease_uuids and provider_uuid", func(t *testing.T) {
		leaseUUID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		_, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       providerAddr.String(),
			LeaseUuids:   []string{leaseUUID},
			ProviderUuid: provider.Uuid,
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "cannot specify both")
	})

	t.Run("fail: must specify either lease_uuids or provider_uuid", func(t *testing.T) {
		_, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender: providerAddr.String(),
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "must specify either")
	})

	t.Run("success: auto-closes leases on credit exhaustion", func(t *testing.T) {
		// Create a new tenant with limited credit for this test
		limitedTenant := f.TestAccs[3]
		limitedCreditAddr, err := types.DeriveCreditAddressFromBech32(limitedTenant.String())
		require.NoError(t, err)

		// Fund with 5000 units - enough to create lease (min 3600 for 1hr min duration)
		// but will be exhausted after 5000 seconds
		limitedFundAmount := sdk.NewCoin(denom, sdkmath.NewInt(5000))
		f.fundAccount(t, limitedCreditAddr, sdk.NewCoins(limitedFundAmount))

		err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
			Tenant:        limitedTenant.String(),
			CreditAddress: limitedCreditAddr.String(),
		})
		require.NoError(t, err)

		// Create and acknowledge a lease (1 unit per second)
		leaseUUID := f.createAndAcknowledgeLease(t, msgServer, limitedTenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})

		// Verify lease is active and credit account has correct counts
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseUUID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_ACTIVE, lease.State)

		creditAcct, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, limitedTenant.String())
		require.NoError(t, err)
		require.Equal(t, uint64(1), creditAcct.ActiveLeaseCount)

		// Advance time beyond credit capacity (10000 seconds > 5000 available)
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(10000 * time.Second))
		f.Ctx = newCtx

		// Provider-wide withdrawal should trigger auto-close
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       providerAddr.String(),
			ProviderUuid: provider.Uuid,
		})
		require.NoError(t, err)
		require.NotNil(t, resp)

		// Verify the lease was auto-closed
		lease, err = f.App.BillingKeeper.GetLease(f.Ctx, leaseUUID)
		require.NoError(t, err)
		require.Equal(t, types.LEASE_STATE_CLOSED, lease.State, "lease should be auto-closed due to credit exhaustion")
		require.NotNil(t, lease.ClosedAt, "closed_at should be set")
		require.Equal(t, types.ClosureReasonCreditExhausted, lease.ClosureReason, "closure reason should indicate credit exhaustion")

		// Verify credit account's active lease count was decremented
		creditAcct, err = f.App.BillingKeeper.GetCreditAccount(f.Ctx, limitedTenant.String())
		require.NoError(t, err)
		require.Equal(t, uint64(0), creditAcct.ActiveLeaseCount, "active lease count should be decremented")

		// Verify provider received the available credit (5000 units)
		// The transfer amount should be capped at available credit
		require.False(t, resp.TotalAmounts.IsZero(), "provider should receive the available credit")
	})
}

// TestMsgWithdraw_ProviderWideLargePagination tests provider-wide withdrawal with more leases
// than the default limit, verifying has_more flag and limit behavior.
// Note: Provider-wide withdrawal does NOT have stateful pagination (no cursor).
// Each call iterates from the beginning and processes up to `limit` leases.
func TestMsgWithdraw_ProviderWideLargePagination(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 1 per second

	// Fund tenant's credit account generously for many leases
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(1000000000)) // 1 billion
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	// Increase max leases per tenant for this test
	params := types.DefaultParams()
	params.MaxLeasesPerTenant = 200
	params.MaxPendingLeasesPerTenant = 200
	err = f.App.BillingKeeper.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create 75 leases (more than default limit of 50)
	const totalLeases = 75
	leaseUUIDs := make([]string, 0, totalLeases)
	for i := 0; i < totalLeases; i++ {
		leaseUUID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku.Uuid, Quantity: 1},
		})
		leaseUUIDs = append(leaseUUIDs, leaseUUID)
	}

	// Advance time so there's something to withdraw
	newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
	f.Ctx = newCtx

	// Get initial payout balance
	initialBalance := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom)

	t.Run("default limit processes 50 leases with has_more=true", func(t *testing.T) {
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       providerAddr.String(),
			ProviderUuid: provider.Uuid,
			// Limit: 0 means use default (50)
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, uint64(50), resp.WithdrawalCount, "should process default limit of 50")
		require.True(t, resp.HasMore, "should indicate more leases exist beyond limit")
		require.False(t, resp.TotalAmounts.IsZero())

		// Verify funds were transferred
		newBalance := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom)
		require.True(t, newBalance.Amount.GT(initialBalance.Amount), "balance should increase")
	})

	t.Run("explicit limit=100 processes all 75 leases", func(t *testing.T) {
		// Advance time so there's more to withdraw
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
		f.Ctx = newCtx

		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       providerAddr.String(),
			ProviderUuid: provider.Uuid,
			Limit:        100, // Explicit max limit
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, uint64(75), resp.WithdrawalCount, "should process all 75 leases")
		require.False(t, resp.HasMore, "no more leases when all processed")
	})

	t.Run("small limit processes only requested amount", func(t *testing.T) {
		// Advance time
		newCtx := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))
		f.Ctx = newCtx

		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       providerAddr.String(),
			ProviderUuid: provider.Uuid,
			Limit:        10, // Small limit
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, uint64(10), resp.WithdrawalCount, "should process exactly 10 leases")
		require.True(t, resp.HasMore, "should indicate more leases exist")
	})

	t.Run("all leases get settled over multiple calls", func(t *testing.T) {
		// Verify all 75 leases have been settled at least once
		settledCount := 0
		for _, leaseUUID := range leaseUUIDs {
			lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseUUID)
			require.NoError(t, err)
			if lease.LastSettledAt.After(lease.CreatedAt) {
				settledCount++
			}
		}
		require.Equal(t, totalLeases, settledCount, "all leases should have been settled")
	})

	t.Run("funds accumulate correctly across withdrawals", func(t *testing.T) {
		finalBalance := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, denom)
		require.True(t, finalBalance.Amount.GT(initialBalance.Amount),
			"final balance (%s) should be greater than initial (%s)",
			finalBalance.Amount, initialBalance.Amount)
	})
}

// TestMsgWithdraw_ProviderWideMultiDenom tests provider-wide withdrawal from
// multiple leases using different denoms, verifying correct aggregation.
func TestMsgWithdraw_ProviderWideMultiDenom(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]

	// Create provider with SKUs in different denoms
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku1 := f.createTestSKUWithDenom(t, provider.Uuid, 3600, testDenom)  // 1 per second in testDenom
	sku2 := f.createTestSKUWithDenom(t, provider.Uuid, 7200, testDenom2) // 2 per second in testDenom2

	// Fund tenant's credit account with BOTH denoms
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount1 := sdk.NewCoin(testDenom, sdkmath.NewInt(100000000))  // 100M testDenom
	fundAmount2 := sdk.NewCoin(testDenom2, sdkmath.NewInt(200000000)) // 200M testDenom2
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount1, fundAmount2))

	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	t.Run("success: provider-wide withdraw aggregates multiple denoms", func(t *testing.T) {
		// Create lease 1 with testDenom SKU
		lease1 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku1.Uuid, Quantity: 1},
		})

		// Create lease 2 with testDenom2 SKU
		lease2 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku2.Uuid, Quantity: 1},
		})

		// Create lease 3 with both denoms
		lease3 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
			{SkuUuid: sku1.Uuid, Quantity: 1},
			{SkuUuid: sku2.Uuid, Quantity: 1},
		})

		// Advance time by 100 seconds
		// testDenom: lease1 (1*100) + lease3 (1*100) = 200
		// testDenom2: lease2 (2*100) + lease3 (2*100) = 400
		f.Ctx = f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))

		// Get initial balances
		initialBalance1 := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, testDenom)
		initialBalance2 := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, testDenom2)

		// Provider-wide withdraw
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       providerAddr.String(),
			ProviderUuid: provider.Uuid,
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, uint64(3), resp.WithdrawalCount, "should withdraw from all 3 leases")

		// Verify both denoms were received
		newBalance1 := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, testDenom)
		newBalance2 := f.App.BankKeeper.GetBalance(f.Ctx, payoutAddr, testDenom2)

		withdrawnDenom1 := newBalance1.Amount.Sub(initialBalance1.Amount)
		withdrawnDenom2 := newBalance2.Amount.Sub(initialBalance2.Amount)

		require.Equal(t, sdkmath.NewInt(200), withdrawnDenom1,
			"should receive 200 testDenom (1/sec * 100sec * 2 leases)")
		require.Equal(t, sdkmath.NewInt(400), withdrawnDenom2,
			"should receive 400 testDenom2 (2/sec * 100sec * 2 leases)")

		// Verify response includes both denoms
		require.Equal(t, sdkmath.NewInt(200), resp.TotalAmounts.AmountOf(testDenom))
		require.Equal(t, sdkmath.NewInt(400), resp.TotalAmounts.AmountOf(testDenom2))

		// Verify all leases were settled
		for _, leaseUUID := range []string{lease1, lease2, lease3} {
			lease, err := f.App.BillingKeeper.GetLease(f.Ctx, leaseUUID)
			require.NoError(t, err)
			require.Equal(t, f.Ctx.BlockTime(), lease.LastSettledAt)
		}
	})

	t.Run("empty result when no withdrawable amounts", func(t *testing.T) {
		// Create a new provider for isolation
		provider2Addr := f.TestAccs[3]
		provider2 := f.createTestProvider(t, provider2Addr.String(), provider2Addr.String())
		sku3 := f.createTestSKU(t, provider2.Uuid, 3600)

		// Create and acknowledge a lease
		f.createAndAcknowledgeLease(t, msgServer, tenant, provider2Addr, []types.LeaseItemInput{
			{SkuUuid: sku3.Uuid, Quantity: 1},
		})

		// Withdraw immediately without advancing time - nothing to withdraw
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       provider2Addr.String(),
			ProviderUuid: provider2.Uuid,
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.Equal(t, uint64(0), resp.WithdrawalCount, "should process 0 leases with withdrawable amounts")
		require.True(t, resp.TotalAmounts.IsZero(), "total amounts should be zero")
	})
}

// ============================================================================
// Credit Reservation / Overbooking Prevention Tests
// ============================================================================

// TestOverbookingPrevention tests that the credit reservation system prevents
// creating more leases than available credit can support.
func TestOverbookingPrevention(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), providerAddr.String())
	// SKU: 3600 per hour = 1 per second
	// With min_lease_duration of 3600 seconds (default), each lease reserves 3600 credits
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 umfx per hour

	// Fund tenant with 10000 credits
	// With 3600 credits reserved per lease, tenant should only be able to create 2 leases
	// (2 * 3600 = 7200 < 10000, but 3 * 3600 = 10800 > 10000)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000))
	f.fundAccount(t, tenant, sdk.NewCoins(fundAmount))

	// Fund credit account
	_, err := msgServer.FundCredit(f.Ctx, &types.MsgFundCredit{
		Sender: tenant.String(),
		Tenant: tenant.String(),
		Amount: fundAmount,
	})
	require.NoError(t, err)

	// Lease 1: Should succeed (reserves 3600, available: 10000 - 3600 = 6400)
	createResp1, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	require.NotNil(t, createResp1)
	t.Logf("Lease 1 created: %s", createResp1.LeaseUuid)

	// Verify reservation was made
	creditAccount, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(3600), creditAccount.ReservedAmounts.AmountOf(denom))

	// Lease 2: Should succeed (reserves 3600, available: 10000 - 7200 = 2800)
	createResp2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	require.NotNil(t, createResp2)
	t.Logf("Lease 2 created: %s", createResp2.LeaseUuid)

	// Verify reservation increased
	creditAccount, err = f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(7200), creditAccount.ReservedAmounts.AmountOf(denom))

	// Lease 3: Should FAIL (need 3600, only 2800 available)
	_, err = msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "insufficient available credit")
	t.Logf("Lease 3 correctly rejected: %v", err)

	// Verify reservation unchanged after failed attempt
	creditAccount, err = f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(7200), creditAccount.ReservedAmounts.AmountOf(denom))
}

// TestReservationReleaseOnClose tests that closing an active lease releases its reservation.
func TestReservationReleaseOnClose(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), providerAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 umfx per hour = 1 per second

	// Fund tenant with just enough for 2 leases
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(8000))
	f.fundAccount(t, tenant, sdk.NewCoins(fundAmount))

	_, err := msgServer.FundCredit(f.Ctx, &types.MsgFundCredit{
		Sender: tenant.String(),
		Tenant: tenant.String(),
		Amount: fundAmount,
	})
	require.NoError(t, err)

	// Create and acknowledge 2 leases
	leaseUUID1 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr,
		[]types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}})
	leaseUUID2 := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr,
		[]types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}})

	// Verify both reservations exist
	creditAccount, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(7200), creditAccount.ReservedAmounts.AmountOf(denom))

	// Third lease should fail
	_, err = msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "insufficient available credit")

	// Close lease 1
	_, err = msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
		Sender:     tenant.String(),
		LeaseUuids: []string{leaseUUID1},
	})
	require.NoError(t, err)

	// Verify reservation was released
	creditAccount, err = f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(3600), creditAccount.ReservedAmounts.AmountOf(denom))

	// Now third lease should succeed (after closing first)
	createResp3, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	require.NotNil(t, createResp3)
	t.Logf("Lease 3 created after closing lease 1: %s", createResp3.LeaseUuid)

	// Cleanup: verify we can still close all leases
	_, err = msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
		Sender:     tenant.String(),
		LeaseUuids: []string{leaseUUID2},
	})
	require.NoError(t, err)
}

// TestReservationReleaseOnReject tests that rejecting a pending lease releases its reservation.
func TestReservationReleaseOnReject(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), providerAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(8000))
	f.fundAccount(t, tenant, sdk.NewCoins(fundAmount))

	_, err := msgServer.FundCredit(f.Ctx, &types.MsgFundCredit{
		Sender: tenant.String(),
		Tenant: tenant.String(),
		Amount: fundAmount,
	})
	require.NoError(t, err)

	// Create 2 pending leases (don't acknowledge)
	createResp1, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)

	createResp2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)

	// Verify reservations
	creditAccount, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(7200), creditAccount.ReservedAmounts.AmountOf(denom))

	// Third lease should fail
	_, err = msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.Error(t, err)

	// Provider rejects lease 1
	_, err = msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
		Sender:     providerAddr.String(),
		LeaseUuids: []string{createResp1.LeaseUuid},
		Reason:     "Test rejection",
	})
	require.NoError(t, err)

	// Verify reservation was released
	creditAccount, err = f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(3600), creditAccount.ReservedAmounts.AmountOf(denom))

	// Now third lease should succeed
	createResp3, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	require.NotNil(t, createResp3)
	t.Logf("Lease 3 created after rejecting lease 1: %s", createResp3.LeaseUuid)

	// Cleanup
	_, err = msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
		Sender:     providerAddr.String(),
		LeaseUuids: []string{createResp2.LeaseUuid, createResp3.LeaseUuid},
		Reason:     "Cleanup",
	})
	require.NoError(t, err)
}

// TestReservationReleaseOnCancel tests that cancelling a pending lease releases its reservation.
func TestReservationReleaseOnCancel(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), providerAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(8000))
	f.fundAccount(t, tenant, sdk.NewCoins(fundAmount))

	_, err := msgServer.FundCredit(f.Ctx, &types.MsgFundCredit{
		Sender: tenant.String(),
		Tenant: tenant.String(),
		Amount: fundAmount,
	})
	require.NoError(t, err)

	// Create 2 pending leases
	createResp1, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)

	createResp2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)

	// Verify reservations
	creditAccount, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(7200), creditAccount.ReservedAmounts.AmountOf(denom))

	// Tenant cancels lease 1
	_, err = msgServer.CancelLease(f.Ctx, &types.MsgCancelLease{
		Tenant:     tenant.String(),
		LeaseUuids: []string{createResp1.LeaseUuid},
	})
	require.NoError(t, err)

	// Verify reservation was released
	creditAccount, err = f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(3600), creditAccount.ReservedAmounts.AmountOf(denom))

	// Now third lease should succeed
	createResp3, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	require.NotNil(t, createResp3)
	t.Logf("Lease 3 created after cancelling lease 1: %s", createResp3.LeaseUuid)

	// Cleanup
	_, err = msgServer.CancelLease(f.Ctx, &types.MsgCancelLease{
		Tenant:     tenant.String(),
		LeaseUuids: []string{createResp2.LeaseUuid, createResp3.LeaseUuid},
	})
	require.NoError(t, err)
}

// TestReservationReleaseOnExpire tests that expiring a pending lease releases its reservation.
func TestReservationReleaseOnExpire(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	denom := testDenom

	// Set a short pending timeout for testing
	params := types.DefaultParams()
	params.PendingTimeout = 60 // 60 seconds
	err := f.App.BillingKeeper.SetParams(f.Ctx, params)
	require.NoError(t, err)

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), providerAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(8000))
	f.fundAccount(t, tenant, sdk.NewCoins(fundAmount))

	_, err = msgServer.FundCredit(f.Ctx, &types.MsgFundCredit{
		Sender: tenant.String(),
		Tenant: tenant.String(),
		Amount: fundAmount,
	})
	require.NoError(t, err)

	// Create 2 pending leases
	createResp1, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)

	createResp2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)

	// Verify reservations
	creditAccount, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant.String())
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(7200), creditAccount.ReservedAmounts.AmountOf(denom))

	// Third lease should fail
	_, err = msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.Error(t, err)

	// Advance time past pending timeout
	ctx61 := f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(61 * time.Second))

	// Run EndBlocker to expire pending leases
	err = f.App.BillingKeeper.EndBlocker(ctx61)
	require.NoError(t, err)

	// Verify both leases are now EXPIRED
	lease1, err := f.App.BillingKeeper.GetLease(ctx61, createResp1.LeaseUuid)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_EXPIRED, lease1.State)

	lease2, err := f.App.BillingKeeper.GetLease(ctx61, createResp2.LeaseUuid)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_EXPIRED, lease2.State)

	// Verify reservations were released
	creditAccount, err = f.App.BillingKeeper.GetCreditAccount(ctx61, tenant.String())
	require.NoError(t, err)
	require.True(t, creditAccount.ReservedAmounts.IsZero() || creditAccount.ReservedAmounts.AmountOf(denom).IsZero(),
		"reservations should be released after expiry, got: %s", creditAccount.ReservedAmounts)

	// Now new leases should succeed
	createResp3, err := msgServer.CreateLease(ctx61, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	require.NotNil(t, createResp3)
	t.Logf("Lease 3 created after lease 1 and 2 expired: %s", createResp3.LeaseUuid)
}

// TestQueryAvailableBalances tests that the CreditAccount query returns correct available_balances.
func TestQueryAvailableBalances(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)
	querier := keeper.NewQuerier(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), providerAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	// Fund tenant with 10000 credits
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(10000))
	f.fundAccount(t, tenant, sdk.NewCoins(fundAmount))

	_, err := msgServer.FundCredit(f.Ctx, &types.MsgFundCredit{
		Sender: tenant.String(),
		Tenant: tenant.String(),
		Amount: fundAmount,
	})
	require.NoError(t, err)

	// Query initial state - all balances should be available
	resp, err := querier.CreditAccount(f.Ctx, &types.QueryCreditAccountRequest{
		Tenant: tenant.String(),
	})
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(10000), resp.Balances.AmountOf(denom))
	require.Equal(t, sdkmath.NewInt(10000), resp.AvailableBalances.AmountOf(denom))
	require.True(t, resp.CreditAccount.ReservedAmounts.IsZero())

	// Create a lease (reserves 3600)
	createResp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)

	// Query after lease creation
	resp, err = querier.CreditAccount(f.Ctx, &types.QueryCreditAccountRequest{
		Tenant: tenant.String(),
	})
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(10000), resp.Balances.AmountOf(denom), "total balance should be unchanged")
	require.Equal(t, sdkmath.NewInt(6400), resp.AvailableBalances.AmountOf(denom), "available should be balance - reserved")
	require.Equal(t, sdkmath.NewInt(3600), resp.CreditAccount.ReservedAmounts.AmountOf(denom), "reserved should show lease reservation")

	// Create another lease
	_, err = msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)

	// Query after second lease
	resp, err = querier.CreditAccount(f.Ctx, &types.QueryCreditAccountRequest{
		Tenant: tenant.String(),
	})
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(10000), resp.Balances.AmountOf(denom))
	require.Equal(t, sdkmath.NewInt(2800), resp.AvailableBalances.AmountOf(denom))
	require.Equal(t, sdkmath.NewInt(7200), resp.CreditAccount.ReservedAmounts.AmountOf(denom))

	// Cancel first lease
	_, err = msgServer.CancelLease(f.Ctx, &types.MsgCancelLease{
		Tenant:     tenant.String(),
		LeaseUuids: []string{createResp.LeaseUuid},
	})
	require.NoError(t, err)

	// Query after cancellation
	resp, err = querier.CreditAccount(f.Ctx, &types.QueryCreditAccountRequest{
		Tenant: tenant.String(),
	})
	require.NoError(t, err)
	require.Equal(t, sdkmath.NewInt(10000), resp.Balances.AmountOf(denom))
	require.Equal(t, sdkmath.NewInt(6400), resp.AvailableBalances.AmountOf(denom))
	require.Equal(t, sdkmath.NewInt(3600), resp.CreditAccount.ReservedAmounts.AmountOf(denom))
}

// TestMsgCreateLease_ServiceName tests lease creation with service_name fields.
func TestMsgCreateLease_ServiceName(t *testing.T) {
	f := initFixture(t)

	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	// Create provider and SKU
	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 3600 per hour = 1 per second

	// Fund tenant's credit account generously
	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	fundAmount := sdk.NewCoin(denom, sdkmath.NewInt(100000000))
	f.fundAccount(t, creditAddr, sdk.NewCoins(fundAmount))

	// Create credit account
	err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	})
	require.NoError(t, err)

	t.Run("success: same SKU with different service_names", func(t *testing.T) {
		resp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{SkuUuid: sku.Uuid, Quantity: 1, ServiceName: "web"},
				{SkuUuid: sku.Uuid, Quantity: 1, ServiceName: "db"},
			},
		})
		require.NoError(t, err)
		require.NotNil(t, resp)
		require.NotEmpty(t, resp.LeaseUuid)

		// Verify stored lease has correct service_names
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, resp.LeaseUuid)
		require.NoError(t, err)
		require.Len(t, lease.Items, 2)
		require.Equal(t, "web", lease.Items[0].ServiceName)
		require.Equal(t, "db", lease.Items[1].ServiceName)
		require.Equal(t, sku.Uuid, lease.Items[0].SkuUuid)
		require.Equal(t, sku.Uuid, lease.Items[1].SkuUuid)
	})

	t.Run("fail: mixed service_names (some set, some not)", func(t *testing.T) {
		_, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{SkuUuid: sku.Uuid, Quantity: 1, ServiceName: "web"},
				{SkuUuid: sku.Uuid, Quantity: 1},
			},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "all items must have service_name or none")
	})

	t.Run("fail: duplicate service_name", func(t *testing.T) {
		_, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{SkuUuid: sku.Uuid, Quantity: 1, ServiceName: "web"},
				{SkuUuid: sku.Uuid, Quantity: 1, ServiceName: "web"},
			},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "duplicate service_name")
	})

	t.Run("backward compat: no service_names, duplicate SKU rejected", func(t *testing.T) {
		_, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{SkuUuid: sku.Uuid, Quantity: 1},
				{SkuUuid: sku.Uuid, Quantity: 2},
			},
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "appears multiple times")
	})

	t.Run("backward compat: no service_names, single item passes", func(t *testing.T) {
		resp, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant.String(),
			Items: []types.LeaseItemInput{
				{SkuUuid: sku.Uuid, Quantity: 3},
			},
		})
		require.NoError(t, err)
		require.NotNil(t, resp)

		// Verify service_name is empty
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, resp.LeaseUuid)
		require.NoError(t, err)
		require.Len(t, lease.Items, 1)
		require.Empty(t, lease.Items[0].ServiceName)
	})
}

// TestBatchMultiTenantDeterminism is a regression test for non-deterministic map
// iteration in batch lease operations. When multiple tenants appear in a single
// AcknowledgeLease / RejectLease / CloseLease message, their credit accounts are
// collected in a map[string]CreditAccount. Iterating that map with `range` produces
// a random order per Go spec, which can cause divergent state across validators.
//
// The fix tracks a tenantOrder slice at insertion time. This test runs each
// batch operation 50 times on independent fixtures and asserts that the resulting
// credit-account state and event sequence are identical every time.
func TestBatchMultiTenantDeterminism(t *testing.T) {
	denom := testDenom

	// setupMultiTenant returns two tenants each with a pending lease for the same provider.
	setupMultiTenant := func(t *testing.T) (*testFixture, types.MsgServer, sdk.AccAddress, sdk.AccAddress, sdk.AccAddress, string, string) {
		t.Helper()
		f := initFixture(t)
		msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

		tenant1 := f.TestAccs[0]
		tenant2 := f.TestAccs[1]
		providerAddr := f.TestAccs[2]
		payoutAddr := f.TestAccs[3]

		provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
		sku := f.createTestSKU(t, provider.Uuid, 3600)

		for _, tenant := range []sdk.AccAddress{tenant1, tenant2} {
			creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
			require.NoError(t, err)
			f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(denom, sdkmath.NewInt(100_000_000))))
			err = f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
				Tenant:        tenant.String(),
				CreditAddress: creditAddr.String(),
			})
			require.NoError(t, err)
		}

		// Create one pending lease per tenant, both for the same provider.
		resp1, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant1.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
		})
		require.NoError(t, err)
		resp2, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
			Tenant: tenant2.String(),
			Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 2}},
		})
		require.NoError(t, err)

		return f, msgServer, tenant1, tenant2, providerAddr, resp1.LeaseUuid, resp2.LeaseUuid
	}

	t.Run("AcknowledgeLease multi-tenant determinism", func(t *testing.T) {
		type snapshot struct {
			ca1Pending uint64
			ca1Active  uint64
			ca2Pending uint64
			ca2Active  uint64
			eventTypes []string
		}

		var reference *snapshot
		for i := range 50 {
			f, msgServer, tenant1, tenant2, providerAddr, lease1, lease2 := setupMultiTenant(t)
			f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())

			_, err := msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
				Sender:     providerAddr.String(),
				LeaseUuids: []string{lease1, lease2},
			})
			require.NoError(t, err)

			ca1, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant1.String())
			require.NoError(t, err)
			ca2, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant2.String())
			require.NoError(t, err)

			events := f.Ctx.EventManager().Events()
			eventTypes := make([]string, len(events))
			for j, ev := range events {
				eventTypes[j] = ev.Type
			}

			s := &snapshot{
				ca1Pending: ca1.PendingLeaseCount,
				ca1Active:  ca1.ActiveLeaseCount,
				ca2Pending: ca2.PendingLeaseCount,
				ca2Active:  ca2.ActiveLeaseCount,
				eventTypes: eventTypes,
			}

			if i == 0 {
				reference = s
			} else {
				require.Equal(t, reference, s, "iteration %d produced different results", i)
			}
		}
	})

	t.Run("RejectLease multi-tenant determinism", func(t *testing.T) {
		type snapshot struct {
			ca1Pending  uint64
			ca2Pending  uint64
			ca1Reserved string
			ca2Reserved string
			eventTypes  []string
		}

		var reference *snapshot
		for i := range 50 {
			f, msgServer, tenant1, tenant2, providerAddr, lease1, lease2 := setupMultiTenant(t)
			f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())

			_, err := msgServer.RejectLease(f.Ctx, &types.MsgRejectLease{
				Sender:     providerAddr.String(),
				LeaseUuids: []string{lease1, lease2},
				Reason:     "test rejection",
			})
			require.NoError(t, err)

			ca1, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant1.String())
			require.NoError(t, err)
			ca2, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant2.String())
			require.NoError(t, err)

			events := f.Ctx.EventManager().Events()
			eventTypes := make([]string, len(events))
			for j, ev := range events {
				eventTypes[j] = ev.Type
			}

			s := &snapshot{
				ca1Pending:  ca1.PendingLeaseCount,
				ca2Pending:  ca2.PendingLeaseCount,
				ca1Reserved: ca1.ReservedAmounts.String(),
				ca2Reserved: ca2.ReservedAmounts.String(),
				eventTypes:  eventTypes,
			}

			if i == 0 {
				reference = s
			} else {
				require.Equal(t, reference, s, "iteration %d produced different results", i)
			}
		}
	})

	t.Run("CloseLease multi-tenant determinism", func(t *testing.T) {
		type snapshot struct {
			ca1Active   uint64
			ca2Active   uint64
			ca1Reserved string
			ca2Reserved string
			eventTypes  []string
		}

		var reference *snapshot
		for i := range 50 {
			f, msgServer, tenant1, tenant2, providerAddr, lease1, lease2 := setupMultiTenant(t)

			// Acknowledge both leases first
			_, err := msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
				Sender:     providerAddr.String(),
				LeaseUuids: []string{lease1, lease2},
			})
			require.NoError(t, err)

			// Advance time to accrue billing
			f.Ctx = f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(10 * time.Second))
			f.Ctx = f.Ctx.WithEventManager(sdk.NewEventManager())

			_, err = msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
				Sender:     providerAddr.String(),
				LeaseUuids: []string{lease1, lease2},
			})
			require.NoError(t, err)

			ca1, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant1.String())
			require.NoError(t, err)
			ca2, err := f.App.BillingKeeper.GetCreditAccount(f.Ctx, tenant2.String())
			require.NoError(t, err)

			events := f.Ctx.EventManager().Events()
			eventTypes := make([]string, len(events))
			for j, ev := range events {
				eventTypes[j] = ev.Type
			}

			s := &snapshot{
				ca1Active:   ca1.ActiveLeaseCount,
				ca2Active:   ca2.ActiveLeaseCount,
				ca1Reserved: ca1.ReservedAmounts.String(),
				ca2Reserved: ca2.ReservedAmounts.String(),
				eventTypes:  eventTypes,
			}

			if i == 0 {
				reference = s
			} else {
				require.Equal(t, reference, s, "iteration %d produced different results", i)
			}
		}
	})
}

// TestMsgWithdraw_ProviderWideCursorDrainsAllLeases verifies that looping
// provider-wide withdrawal with key <- next_key at a small limit settles every
// active lease and terminates (the pre-cursor code re-scans the front forever).
func TestMsgWithdraw_ProviderWideCursorDrainsAllLeases(t *testing.T) {
	f := initFixture(t)
	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 1 per second

	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(denom, sdkmath.NewInt(1000000000))))
	require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	}))

	params := types.DefaultParams()
	params.MaxLeasesPerTenant = 200
	params.MaxPendingLeasesPerTenant = 200
	require.NoError(t, f.App.BillingKeeper.SetParams(f.Ctx, params))

	const totalLeases = 25
	leaseUUIDs := make([]string, 0, totalLeases)
	for i := 0; i < totalLeases; i++ {
		leaseUUIDs = append(leaseUUIDs, f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr,
			[]types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}}))
	}

	// Advance time so every lease has something to settle.
	f.Ctx = f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))

	var key []byte
	pages := 0
	totalSettled := uint64(0)
	for {
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       providerAddr.String(),
			ProviderUuid: provider.Uuid,
			Limit:        7,
			Key:          key,
		})
		require.NoError(t, err)
		pages++
		totalSettled += resp.WithdrawalCount
		require.LessOrEqual(t, resp.WithdrawalCount, uint64(7))
		require.Less(t, pages, 100, "pagination must terminate")
		if !resp.HasMore {
			require.Empty(t, resp.NextKey, "next_key must be empty on the final page")
			break
		}
		require.NotEmpty(t, resp.NextKey, "next_key must be set while has_more is true")
		key = resp.NextKey
	}

	// ceil(25 / 7) == 4 pages, every lease settled exactly once (no double-drain), and
	// every lease settled to the current block time.
	require.Equal(t, 4, pages, "should take 4 pages to drain 25 leases at limit 7")
	require.Equal(t, uint64(totalLeases), totalSettled, "each lease settled exactly once across all pages")
	for _, uuid := range leaseUUIDs {
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, uuid)
		require.NoError(t, err)
		require.Equal(t, f.Ctx.BlockTime(), lease.LastSettledAt,
			"lease %s should be settled to current block time", uuid)
	}
}

// TestMsgWithdraw_ProviderWideCursorSurvivesClosedBoundaryLease closes the exact
// lease named by next_key between pages. StartExclusive must still resume at the
// next-greater UUID rather than silently stopping.
func TestMsgWithdraw_ProviderWideCursorSurvivesClosedBoundaryLease(t *testing.T) {
	f := initFixture(t)
	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(denom, sdkmath.NewInt(1000000000))))
	require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	}))

	const totalLeases = 6
	for i := 0; i < totalLeases; i++ {
		f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr,
			[]types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}})
	}
	f.Ctx = f.Ctx.WithBlockTime(f.Ctx.BlockTime().Add(100 * time.Second))

	// Page 1 at limit 3 processes the 3 smallest UUIDs; next_key is the 3rd.
	resp1, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
		Sender:       providerAddr.String(),
		ProviderUuid: provider.Uuid,
		Limit:        3,
	})
	require.NoError(t, err)
	require.Equal(t, uint64(3), resp1.WithdrawalCount)
	require.True(t, resp1.HasMore)
	require.NotEmpty(t, resp1.NextKey)

	// Close the boundary lease, removing it from the ACTIVE index.
	boundaryUUID := string(resp1.NextKey)
	_, err = msgServer.CloseLease(f.Ctx, &types.MsgCloseLease{
		Sender:     tenant.String(),
		LeaseUuids: []string{boundaryUUID},
	})
	require.NoError(t, err)

	// Resume from the now-closed cursor: the remaining 3 tail leases must be reached.
	seen := uint64(0)
	key := resp1.NextKey
	pages := 0
	for {
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender:       providerAddr.String(),
			ProviderUuid: provider.Uuid,
			Limit:        3,
			Key:          key,
		})
		require.NoError(t, err)
		seen += resp.WithdrawalCount
		pages++
		require.Less(t, pages, 100, "pagination must terminate")
		if !resp.HasMore {
			break
		}
		key = resp.NextKey
	}
	require.Equal(t, uint64(3), seen, "tail leases must be reached after the boundary lease was closed")
}

// TestMsgWithdraw_ProviderWideCursorMidCycleAckDeferredOneCycle verifies the
// documented liveness property: a lease acknowledged (PENDING->ACTIVE) with a
// UUID *behind* an in-flight cursor is not settled in the current cycle (the
// cursor already passed its index slot), but is picked up on the next full
// cycle (key=""). It is deferred by one cycle, never skipped forever or
// double-settled.
func TestMsgWithdraw_ProviderWideCursorMidCycleAckDeferredOneCycle(t *testing.T) {
	f := initFixture(t)
	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	denom := testDenom

	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600) // 1 per second

	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(denom, sdkmath.NewInt(1000000000))))
	require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	}))

	// Create the "early" lease FIRST so it gets the smallest (UUIDv7, sequence-
	// ordered) UUID, but leave it PENDING so it is not yet in the ACTIVE index.
	earlyCreate, err := msgServer.CreateLease(f.Ctx, &types.MsgCreateLease{
		Tenant: tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	earlyUUID := earlyCreate.LeaseUuid

	// Four acknowledged (ACTIVE) leases, all with larger UUIDs than earlyUUID.
	active := make([]string, 0, 4)
	for i := 0; i < 4; i++ {
		active = append(active, f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr,
			[]types.LeaseItemInput{{SkuUuid: sku.Uuid, Quantity: 1}}))
	}

	// T1: advance so the ACTIVE leases have something to settle.
	t1 := f.Ctx.BlockTime().Add(100 * time.Second)
	f.Ctx = f.Ctx.WithBlockTime(t1)

	// Page 1 (limit 2, no cursor): settles the two smallest ACTIVE UUIDs; the
	// cursor (next_key) lands on the 2nd-smallest ACTIVE lease.
	resp1, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
		Sender: providerAddr.String(), ProviderUuid: provider.Uuid, Limit: 2,
	})
	require.NoError(t, err)
	require.Equal(t, uint64(2), resp1.WithdrawalCount)
	require.True(t, resp1.HasMore)
	require.NotEmpty(t, resp1.NextKey)

	// Acknowledge the early lease now: it becomes ACTIVE with LastSettledAt == t1
	// and a UUID smaller than the cursor, i.e. behind the in-flight cursor.
	_, err = msgServer.AcknowledgeLease(f.Ctx, &types.MsgAcknowledgeLease{
		Sender: providerAddr.String(), LeaseUuids: []string{earlyUUID},
	})
	require.NoError(t, err)
	earlyLease, err := f.App.BillingKeeper.GetLease(f.Ctx, earlyUUID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_ACTIVE, earlyLease.State)
	require.Equal(t, t1, earlyLease.LastSettledAt)

	// Finish the current cycle from the cursor. StartExclusive skips everything
	// <= cursor, so the early lease (behind the cursor) is NOT settled this cycle.
	key := resp1.NextKey
	for {
		resp, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
			Sender: providerAddr.String(), ProviderUuid: provider.Uuid, Limit: 2, Key: key,
		})
		require.NoError(t, err)
		if !resp.HasMore {
			break
		}
		key = resp.NextKey
	}
	earlyLease, err = f.App.BillingKeeper.GetLease(f.Ctx, earlyUUID)
	require.NoError(t, err)
	require.Equal(t, t1, earlyLease.LastSettledAt,
		"early lease must NOT be settled in the cycle whose cursor already passed its slot")

	// T2: advance again, then run a fresh cycle from the front (key="").
	t2 := f.Ctx.BlockTime().Add(100 * time.Second)
	f.Ctx = f.Ctx.WithBlockTime(t2)
	resp2, err := msgServer.Withdraw(f.Ctx, &types.MsgWithdraw{
		Sender: providerAddr.String(), ProviderUuid: provider.Uuid, Limit: 100,
	})
	require.NoError(t, err)
	require.False(t, resp2.HasMore)

	// The early lease is settled on the following cycle (deferred, not skipped),
	// and every lease ends settled to the same t2 (no duplication).
	for _, uuid := range append([]string{earlyUUID}, active...) {
		lease, err := f.App.BillingKeeper.GetLease(f.Ctx, uuid)
		require.NoError(t, err)
		require.Equal(t, t2, lease.LastSettledAt, "lease %s should be settled to t2 on the following cycle", uuid)
	}
}
