package keeper

import (
	"context"
	"encoding/hex"
	"errors"
	"strconv"
	"strings"
	"time"

	"cosmossdk.io/collections"
	errorsmod "cosmossdk.io/errors"
	sdkmath "cosmossdk.io/math"

	sdk "github.com/cosmos/cosmos-sdk/types"

	"github.com/manifest-network/manifest-ledger/pkg/sanitize"
	pkguuid "github.com/manifest-network/manifest-ledger/pkg/uuid"
	"github.com/manifest-network/manifest-ledger/x/billing/types"
	skutypes "github.com/manifest-network/manifest-ledger/x/sku/types"
)

var _ types.MsgServer = msgServer{}

type msgServer struct {
	k Keeper
}

// NewMsgServerImpl returns an implementation of the MsgServer interface.
func NewMsgServerImpl(keeper Keeper) types.MsgServer {
	return &msgServer{k: keeper}
}

// FundCredit funds a tenant's credit account.
func (ms msgServer) FundCredit(ctx context.Context, msg *types.MsgFundCredit) (*types.MsgFundCreditResponse, error) {
	if err := msg.ValidateBasic(); err != nil {
		return nil, err
	}

	// Parse transaction addresses once so state and events use the SDK's
	// canonical Bech32 spelling even when the wire message uses an equivalent
	// all-uppercase representation.
	tenantAddr, err := sdk.AccAddressFromBech32(msg.Tenant)
	if err != nil {
		return nil, err
	}
	tenant := tenantAddr.String()
	creditAddr := types.DeriveCreditAddress(tenantAddr)

	// Parse sender address
	senderAddr, err := sdk.AccAddressFromBech32(msg.Sender)
	if err != nil {
		return nil, err
	}

	// Like a bank MsgSend, a user-funded deposit must honor denomination send
	// restrictions. SendCoins itself does not enforce this policy.
	if err := ms.k.bankKeeper.IsSendEnabledCoins(ctx, msg.Amount); err != nil {
		return nil, err
	}

	// Use CacheContext to ensure atomicity: either all operations succeed
	// (token transfer + credit account creation) or none do.
	sdkCtx := sdk.UnwrapSDKContext(ctx)
	cacheCtx, writeCache := sdkCtx.CacheContext()

	// Transfer tokens from sender to credit address
	if err := ms.k.bankKeeper.SendCoins(cacheCtx, senderAddr, creditAddr, sdk.NewCoins(msg.Amount)); err != nil {
		return nil, types.ErrInvalidCreditOperation.Wrapf("failed to transfer tokens: %s", err)
	}

	// Get or create credit account
	creditAccount, err := ms.k.GetCreditAccount(cacheCtx, tenant)
	if err != nil {
		if !errors.Is(err, types.ErrCreditAccountNotFound) {
			return nil, errorsmod.Wrap(err, "failed to get credit account")
		}
		// Credit account doesn't exist, create it
		creditAccount = types.CreditAccount{
			Tenant:            tenant,
			CreditAddress:     creditAddr.String(),
			ActiveLeaseCount:  0,
			PendingLeaseCount: 0,
		}

		// Ensure the credit account address is registered in the account keeper
		if ms.k.accountKeeper.GetAccount(cacheCtx, creditAddr) == nil {
			acc := ms.k.accountKeeper.NewAccountWithAddress(cacheCtx, creditAddr)
			ms.k.accountKeeper.SetAccount(cacheCtx, acc)
		}
	}

	if err := ms.k.SetCreditAccount(cacheCtx, creditAccount); err != nil {
		return nil, err
	}

	// All operations succeeded - commit atomically
	writeCache()

	// Return usable credit after bank vesting locks (after commit).
	newBalance := ms.k.spendableCreditCoin(ctx, creditAddr, msg.Amount.Denom)

	// Emit the funding event after commit so it includes the final balance.
	sdkCtx.EventManager().EmitEvent(
		sdk.NewEvent(
			types.EventTypeCreditFunded,
			sdk.NewAttribute(types.AttributeKeyTenant, tenant),
			sdk.NewAttribute(types.AttributeKeyCreditAddress, creditAddr.String()),
			sdk.NewAttribute(types.AttributeKeySender, senderAddr.String()),
			sdk.NewAttribute(types.AttributeKeyAmount, msg.Amount.String()),
			sdk.NewAttribute(types.AttributeKeyNewBalance, newBalance.String()),
		),
	)

	return &types.MsgFundCreditResponse{
		CreditAddress: creditAddr.String(),
		NewBalance:    newBalance,
	}, nil
}

// leaseCreationResult holds the result of lease creation for use by the public methods.
type leaseCreationResult struct {
	leaseUUID     string
	tenant        string
	providerUUID  string
	itemCount     int
	totalRates    sdk.Coins // total rate per second by denom
	pendingLeases uint64
	metaHash      []byte
}

// createLeaseInternal contains the shared lease creation logic.
// It validates inputs, creates the lease, and returns the result for event emission.
func (ms msgServer) createLeaseInternal(ctx context.Context, tenant string, items []types.LeaseItemInput, metaHash []byte) (*leaseCreationResult, error) {
	sdkCtx := sdk.UnwrapSDKContext(ctx)
	blockTime := sdkCtx.BlockTime()
	tenantAddr, err := sdk.AccAddressFromBech32(tenant)
	if err != nil {
		return nil, err
	}
	tenant = tenantAddr.String()

	params, err := ms.k.GetParams(ctx)
	if err != nil {
		return nil, err
	}

	// 0. Verify item count doesn't exceed max_items_per_lease param
	if uint64(len(items)) > params.MaxItemsPerLease {
		return nil, types.ErrTooManyLeaseItems.Wrapf(
			"lease has %d items, maximum allowed is %d",
			len(items),
			params.MaxItemsPerLease,
		)
	}

	// 1. Get credit account and verify tenant hasn't exceeded max leases (O(1) check)
	creditAccount, err := ms.k.GetCreditAccount(ctx, tenant)
	if err != nil {
		if !errors.Is(err, types.ErrCreditAccountNotFound) {
			return nil, err
		}
		return nil, types.ErrCreditAccountNotFound.Wrapf("tenant %s has no credit account", tenant)
	}

	if creditAccount.ActiveLeaseCount >= params.MaxLeasesPerTenant {
		return nil, types.ErrMaxLeasesReached.Wrapf(
			"tenant has %d active leases, max is %d",
			creditAccount.ActiveLeaseCount,
			params.MaxLeasesPerTenant,
		)
	}

	// Also check pending lease limit
	if creditAccount.PendingLeaseCount >= params.MaxPendingLeasesPerTenant {
		return nil, types.ErrMaxPendingLeasesReached.Wrapf(
			"tenant has %d pending leases, max is %d",
			creditAccount.PendingLeaseCount,
			params.MaxPendingLeasesPerTenant,
		)
	}

	// 3. Verify all SKUs exist, are active, and belong to the same provider
	var providerUUID string
	leaseItems := make([]types.LeaseItem, 0, len(items))
	totalRatesPerSecond := sdk.NewCoins() // Accumulate rates by denom

	for i, inputItem := range items {
		sku, err := ms.k.skuKeeper.GetSKU(ctx, inputItem.SkuUuid)
		if err != nil {
			if !errors.Is(err, skutypes.ErrSKUNotFound) {
				return nil, err
			}
			return nil, types.ErrSKUNotFound.Wrapf("sku_uuid %s not found", inputItem.SkuUuid)
		}

		if !sku.Active {
			return nil, types.ErrSKUNotActive.Wrapf("sku_uuid %s is not active", inputItem.SkuUuid)
		}

		// Check provider consistency
		if i == 0 {
			providerUUID = sku.ProviderUuid
		} else if sku.ProviderUuid != providerUUID {
			return nil, types.ErrMixedProviders.Wrapf(
				"sku_uuid %s belongs to provider %s, expected provider %s",
				inputItem.SkuUuid,
				sku.ProviderUuid,
				providerUUID,
			)
		}

		// Lock price from SKU (convert to per-second rate, preserving denom)
		lockedPricePerSecond, err := ConvertBasePriceToPerSecond(sku.BasePrice, sku.Unit)
		if err != nil {
			// A SKU admitted by x/sku validation always has convertible pricing.
			// Reaching this branch means the dependency returned semantically
			// corrupt stored state, not that the requested SKU was absent.
			return nil, types.ErrInternalCorruption.Wrapf(
				"stored SKU %s has invalid pricing: %v",
				inputItem.SkuUuid,
				err,
			)
		}

		// Accumulate total rate for each denom
		itemRate, err := types.SafeMultiplyCoin(lockedPricePerSecond, sdkmath.NewIntFromUint64(inputItem.Quantity))
		if err != nil {
			return nil, errorsmod.Wrapf(err, "calculate rate for sku_uuid %s", inputItem.SkuUuid)
		}
		totalRatesPerSecond, err = types.SafeAddCoins(totalRatesPerSecond, sdk.Coins{itemRate})
		if err != nil {
			return nil, errorsmod.Wrapf(err, "sum rate for sku_uuid %s", inputItem.SkuUuid)
		}

		leaseItems = append(leaseItems, types.LeaseItem{
			SkuUuid:     inputItem.SkuUuid,
			Quantity:    inputItem.Quantity,
			LockedPrice: lockedPricePerSecond,
			ServiceName: inputItem.ServiceName,
		})
	}

	// 4. Verify provider is active (only need to check once since all SKUs belong to same provider)
	provider, err := ms.k.skuKeeper.GetProvider(ctx, providerUUID)
	if err != nil {
		if !errors.Is(err, skutypes.ErrProviderNotFound) {
			return nil, err
		}
		return nil, types.ErrProviderNotFound.Wrapf("provider_uuid %s not found", providerUUID)
	}
	if !provider.Active {
		return nil, types.ErrProviderNotActive.Wrapf("provider_uuid %s is not active", providerUUID)
	}
	// Historical providers may predate SKU's payout-policy validation. Do not
	// reserve more tenant credit for a provider that cannot receive settlement.
	payoutAddress, err := storedProviderPayoutAddress(provider)
	if err != nil {
		return nil, err
	}
	creditAddress, err := types.DeriveCreditAddressFromBech32(tenant)
	if err != nil {
		return nil, err
	}
	if err := ms.k.validatePayoutRecipient(payoutAddress, creditAddress); err != nil {
		return nil, err
	}

	// 5. Calculate reservation and verify tenant has enough AVAILABLE credit
	// Available credit = balance - already reserved amounts
	// This prevents overbooking where multiple leases could exhaust the same credit
	reservationAmount, err := types.CalculateLeaseReservationFromRates(totalRatesPerSecond, params.MinLeaseDuration)
	if err != nil {
		return nil, errorsmod.Wrap(err, "calculate lease reservation")
	}

	// Fetch credit balances for only the denoms needed by this lease.
	// This avoids loading dust from unrelated token sends to the credit address.
	// totalRatesPerSecond is sdk.Coins (sorted, deduplicated) so leaseDenoms has no duplicates.
	leaseDenoms := make([]string, 0, len(totalRatesPerSecond))
	for _, coin := range totalRatesPerSecond {
		leaseDenoms = append(leaseDenoms, coin.Denom)
	}
	creditBalances, err := ms.k.getCreditBalancesForDenoms(ctx, tenant, leaseDenoms)
	if err != nil {
		return nil, err
	}

	availableCredit := types.GetAvailableCredit(creditBalances, creditAccount.ReservedAmounts)

	// Check each denom in the reservation has sufficient available credit
	for _, res := range reservationAmount {
		available := availableCredit.AmountOf(res.Denom)
		if available.LT(res.Amount) {
			return nil, types.ErrInsufficientCredit.Wrapf(
				"insufficient available credit for denom %s: need %s, have %s available (balance: %s, reserved: %s)",
				res.Denom,
				res.Amount.String(),
				available.String(),
				creditBalances.AmountOf(res.Denom).String(),
				creditAccount.ReservedAmounts.AmountOf(res.Denom).String(),
			)
		}
	}

	// Reserve credit immediately (lease is PENDING but credit is locked)
	previousReservationDenoms := len(creditAccount.ReservedAmounts)
	updatedReservations, err := types.AddReservation(creditAccount.ReservedAmounts, reservationAmount)
	if err != nil {
		return nil, errorsmod.Wrap(err, "add lease reservation to credit account")
	}
	if len(updatedReservations) > types.MaxReservedDenomsPerCreditAccount &&
		len(updatedReservations) > previousReservationDenoms {
		return nil, types.ErrReservationDenomLimitExceeded.Wrapf(
			"creating this lease would increase tenant %s from %d to %d reserved denoms; maximum is %d",
			tenant,
			previousReservationDenoms,
			len(updatedReservations),
			types.MaxReservedDenomsPerCreditAccount,
		)
	}
	creditAccount.ReservedAmounts = updatedReservations

	// 6. Create lease with deterministic UUIDv7
	leaseSeq, err := ms.k.GetNextLeaseSequence(ctx)
	if err != nil {
		return nil, err
	}
	leaseUUID := pkguuid.GenerateUUIDv7(sdkCtx, types.ModuleName, leaseSeq)

	lease := types.Lease{
		Uuid:                       leaseUUID,
		Tenant:                     tenant,
		ProviderUuid:               providerUUID,
		Items:                      leaseItems,
		State:                      types.LEASE_STATE_PENDING, // Start in PENDING, awaiting provider acknowledgement
		CreatedAt:                  blockTime,
		LastSettledAt:              blockTime, // Will be updated to AcknowledgedAt when provider acknowledges
		MetaHash:                   metaHash,
		MinLeaseDurationAtCreation: params.MinLeaseDuration, // Store for consistent reservation release
		Reservation: &types.LeaseReservation{
			RemainingAmounts: append(sdk.Coins(nil), reservationAmount...),
		},
	}

	if err := ms.k.SetLease(ctx, lease); err != nil {
		return nil, err
	}

	// 7. Increment pending lease count in credit account (lease starts in PENDING state)
	creditAccount.PendingLeaseCount++
	if err := ms.k.SetCreditAccount(ctx, creditAccount); err != nil {
		return nil, err
	}

	return &leaseCreationResult{
		leaseUUID:     leaseUUID,
		tenant:        tenant,
		providerUUID:  providerUUID,
		itemCount:     len(leaseItems),
		totalRates:    totalRatesPerSecond,
		pendingLeases: creditAccount.PendingLeaseCount,
		metaHash:      metaHash,
	}, nil
}

// emitLeaseCreatedEvent emits a lease_created event with the given parameters.
func emitLeaseCreatedEvent(ctx sdk.Context, result *leaseCreationResult, createdBy, sender string) {
	eventAttrs := []sdk.Attribute{
		sdk.NewAttribute(types.AttributeKeyLeaseUUID, result.leaseUUID),
		sdk.NewAttribute(types.AttributeKeyTenant, result.tenant),
		sdk.NewAttribute(types.AttributeKeyProviderUUID, result.providerUUID),
		sdk.NewAttribute(types.AttributeKeyItemCount, strconv.Itoa(result.itemCount)),
		sdk.NewAttribute(types.AttributeKeyTotalRate, result.totalRates.String()),
		sdk.NewAttribute(types.AttributeKeyPendingLeaseCount, strconv.FormatUint(result.pendingLeases, 10)),
		sdk.NewAttribute(types.AttributeKeyCreatedBy, createdBy),
		sdk.NewAttribute(types.AttributeKeySender, sender),
	}
	if len(result.metaHash) > 0 {
		eventAttrs = append(eventAttrs, sdk.NewAttribute(types.AttributeKeyMetaHash, hex.EncodeToString(result.metaHash)))
	}
	ctx.EventManager().EmitEvent(sdk.NewEvent(types.EventTypeLeaseCreated, eventAttrs...))
}

// CreateLease creates a new lease for the tenant.
func (ms msgServer) CreateLease(ctx context.Context, msg *types.MsgCreateLease) (*types.MsgCreateLeaseResponse, error) {
	if err := msg.ValidateBasic(); err != nil {
		return nil, err
	}

	result, err := ms.createLeaseInternal(ctx, msg.Tenant, msg.Items, msg.MetaHash)
	if err != nil {
		return nil, err
	}

	emitLeaseCreatedEvent(sdk.UnwrapSDKContext(ctx), result, types.AttributeValueRoleTenant, result.tenant)

	return &types.MsgCreateLeaseResponse{
		LeaseUuid: result.leaseUUID,
	}, nil
}

// CreateLeaseForTenant allows authority or allowed addresses to create a lease on behalf of a tenant.
// This is used for migrating off-chain leases to on-chain.
func (ms msgServer) CreateLeaseForTenant(ctx context.Context, msg *types.MsgCreateLeaseForTenant) (*types.MsgCreateLeaseForTenantResponse, error) {
	if err := msg.ValidateBasic(); err != nil {
		return nil, err
	}

	// Verify sender is authorized (authority or in allowed list)
	role, err := ms.k.HasAdminPrivileges(ctx, msg.Authority)
	if err != nil {
		return nil, types.ErrUnauthorized.Wrapf("failed to check authorization: %s", err)
	}
	if role == "" {
		return nil, types.ErrUnauthorized.Wrapf("%s is not the authority or in the allowed list", msg.Authority)
	}

	sender, err := sdk.AccAddressFromBech32(msg.Authority)
	if err != nil {
		return nil, err
	}
	result, err := ms.createLeaseInternal(ctx, msg.Tenant, msg.Items, msg.MetaHash)
	if err != nil {
		return nil, err
	}

	emitLeaseCreatedEvent(sdk.UnwrapSDKContext(ctx), result, role, sender.String())

	return &types.MsgCreateLeaseForTenantResponse{
		LeaseUuid: result.leaseUUID,
	}, nil
}

// CloseLease closes one or more active leases.
// Sender must be authorized for each lease (tenant, provider, or authority).
// This is an atomic operation: all leases succeed or all fail.
func (ms msgServer) CloseLease(ctx context.Context, msg *types.MsgCloseLease) (*types.MsgCloseLeaseResponse, error) {
	if err := msg.ValidateBasic(); err != nil {
		return nil, err
	}

	sdkCtx := sdk.UnwrapSDKContext(ctx)
	blockTime := sdkCtx.BlockTime()

	senderAddr, err := sdk.AccAddressFromBech32(msg.Sender)
	if err != nil {
		return nil, err
	}
	authorityAddr, err := sdk.AccAddressFromBech32(ms.k.GetAuthority())
	if err != nil {
		return nil, err
	}

	// Phase 1: Validate ALL leases and authorization first (fail-fast)
	leases := make([]types.Lease, 0, len(msg.LeaseUuids))
	tenantKeys := make([]string, 0, len(msg.LeaseUuids))
	creditAccounts := make(map[string]types.CreditAccount) // keyed by tenant address
	tenantOrder := make([]string, 0, len(msg.LeaseUuids))  // deterministic iteration order
	providerCache := make(map[string]sdk.AccAddress)       // provider UUID -> provider address
	var closedBy string                                    // consistent role for all leases

	isAuthority := senderAddr.Equals(authorityAddr)

	for _, uuid := range msg.LeaseUuids {
		lease, err := ms.k.GetLease(ctx, uuid)
		if err != nil {
			if !errors.Is(err, types.ErrLeaseNotFound) {
				return nil, err
			}
			return nil, types.ErrLeaseNotFound.Wrapf("lease %s not found", uuid)
		}

		if lease.State != types.LEASE_STATE_ACTIVE {
			return nil, types.ErrLeaseNotActive.Wrapf("lease %s is not active", uuid)
		}

		// Address text is not an identity: equivalent Bech32 values can use
		// different casing. Use the SDK's canonical spelling for map keys and
		// emitted identities.
		tenantAddr, err := sdk.AccAddressFromBech32(lease.Tenant)
		if err != nil {
			return nil, types.ErrInvalidLease.Wrapf("lease %s has invalid tenant address: %s", uuid, err)
		}
		tenantKey := tenantAddr.String()

		// Determine authorization for this lease
		leaseClosedBy := ""

		// Check if sender is tenant
		if senderAddr.Equals(tenantAddr) {
			leaseClosedBy = "tenant"
		}

		// Check if sender is authority (can close any lease)
		if isAuthority {
			leaseClosedBy = "authority"
		}

		// Check if sender is provider address (cache provider lookups)
		if leaseClosedBy == "" {
			providerAddr, exists := providerCache[lease.ProviderUuid]
			if !exists {
				provider, err := ms.k.skuKeeper.GetProvider(ctx, lease.ProviderUuid)
				if err != nil {
					if !errors.Is(err, skutypes.ErrProviderNotFound) {
						return nil, err
					}
					// Provider not found — sender cannot be the provider
				} else {
					providerAddr, err = sdk.AccAddressFromBech32(provider.Address)
					if err != nil {
						return nil, err
					}
					providerCache[lease.ProviderUuid] = providerAddr
				}
			}
			if !providerAddr.Empty() && senderAddr.Equals(providerAddr) {
				leaseClosedBy = "provider"
			}
		}

		if leaseClosedBy == "" {
			return nil, types.ErrUnauthorized.Wrapf(
				"sender %s is not authorized to close lease %s",
				msg.Sender,
				uuid,
			)
		}

		// For non-authority senders, ensure consistent role across all leases
		if !isAuthority {
			if closedBy == "" {
				closedBy = leaseClosedBy
			} else if closedBy != leaseClosedBy {
				return nil, types.ErrUnauthorized.Wrapf(
					"sender %s has inconsistent authorization: lease %s requires %s role but batch uses %s",
					msg.Sender,
					uuid,
					leaseClosedBy,
					closedBy,
				)
			}
		} else {
			closedBy = "authority"
		}

		// Validate credit account exists for this tenant (only fetch once per tenant)
		if _, exists := creditAccounts[tenantKey]; !exists {
			creditAccount, err := ms.k.GetCreditAccount(ctx, tenantKey)
			if err != nil {
				if !errors.Is(err, types.ErrCreditAccountNotFound) {
					return nil, err
				}
				return nil, types.ErrCreditAccountNotFound.Wrapf(
					"credit account not found for tenant %s (lease %s): data integrity issue",
					lease.Tenant,
					uuid,
				)
			}
			creditAccounts[tenantKey] = creditAccount
			tenantOrder = append(tenantOrder, tenantKey)
		}

		leases = append(leases, lease)
		tenantKeys = append(tenantKeys, tenantKey)
	}

	// Phase 2: Apply all changes atomically using CacheContext
	// This ensures that if any operation fails, all changes are rolled back.
	cacheCtx, writeCache := sdkCtx.CacheContext()
	totalSettledAmounts := sdk.NewCoins()

	// Track close events to emit after successful commit.
	type leaseEvent struct {
		uuid            string
		tenant          string
		providerUUID    string
		settledAmounts  sdk.Coins
		closedBy        string
		durationSeconds string
		activeCount     uint64
		closureReason   string
	}
	leaseEvents := make([]leaseEvent, 0, len(leases))

	for i := range leases {
		var settledAmounts sdk.Coins
		var closeTime time.Time
		lastSettledAt := leases[i].LastSettledAt
		leaseClosedBy := closedBy
		creditAccount := creditAccounts[tenantKeys[i]]

		// Check if lease should be auto-closed due to exhausted credit
		shouldAutoClose, autoCloseTime, err := ms.k.ShouldAutoCloseLease(cacheCtx, &leases[i], &creditAccount)
		if err != nil {
			return nil, err
		}

		if shouldAutoClose {
			// Lease should be auto-closed due to credit exhaustion.
			closeTime = autoCloseTime

			// Perform settlement using silent mode (doesn't fail on overflow)
			result, err := ms.k.PerformSettlementSilent(cacheCtx, &leases[i], &creditAccount, closeTime)
			if err != nil {
				return nil, err
			}
			settledAmounts = result.TransferAmounts

			// Update lease state
			leases[i].State = types.LEASE_STATE_CLOSED
			leases[i].ClosedAt = &closeTime
			leases[i].LastSettledAt = closeTime

			// ShouldAutoCloseLease uses a GTE boundary (accrued >= balance), so it
			// also fires when the tenant's credit EXACTLY covers the accrued
			// charges — and in a batch an earlier lease's settlement can drain the
			// shared credit balance so a later, fully-paid lease trips the boundary
			// with nothing left unpaid. That is a full payment (the credit did its
			// job), not exhaustion, so the caller-supplied reason and role are
			// preserved (ENG-577).
			//
			// Keep the caller's reason ONLY when a positive accrued charge was
			// settled in full. Everything else ShouldAutoCloseLease flags is genuine
			// exhaustion and keeps the credit_exhausted label:
			//   - overflow: PerformSettlementSilent clamps the affected denoms to
			//     their remaining balances, so a capped result can look fully paid;
			//     use its explicit overflow metadata rather than inferring from duration.
			//   - partial settlement: the transfer fell short of the accrued amount.
			//   - zero-balance / zero-duration: a required denom balance is already
			//     zero with nothing accrued this instant (AccruedAmounts empty) — the
			//     credit is exhausted even though there is no unpaid remainder.
			overflowed := len(result.AccrualOverflow) > 0
			fullyPaid := result.TransferAmounts.Equal(result.AccruedAmounts)
			if overflowed || !fullyPaid || result.AccruedAmounts.IsZero() {
				leases[i].ClosureReason = types.ClosureReasonCreditExhausted
				leaseClosedBy = "credit_exhaustion"
			} else {
				leases[i].ClosureReason = msg.Reason
			}
		} else {
			// Normal close - use block time
			closeTime = blockTime

			// Settle accrued charges
			settledAmounts, err = ms.settleLeaseForClose(cacheCtx, &leases[i], &creditAccount, closeTime)
			if err != nil {
				return nil, err
			}

			// Update lease state to inactive
			leases[i].State = types.LEASE_STATE_CLOSED
			leases[i].ClosedAt = &closeTime
			leases[i].ClosureReason = msg.Reason
		}

		durationSeconds, err := elapsedWholeSeconds(lastSettledAt, closeTime)
		if err != nil {
			return nil, errorsmod.Wrapf(err, "calculate close duration for lease %s", leases[i].Uuid)
		}

		// Update lease counts: decrement active (in memory map)
		ms.k.DecrementActiveLeaseCount(&creditAccount, leases[i].Uuid)

		// Release reservation for this lease
		if err := ms.k.ReleaseLeaseReservation(cacheCtx, &creditAccount, &leases[i]); err != nil {
			return nil, err
		}

		// Persist the terminal lease after its remaining reservation has been
		// cleared; SetLease also reconciles the custom-domain reverse index.
		if err := ms.k.SetLease(cacheCtx, leases[i]); err != nil {
			return nil, types.ErrInvalidLease.Wrapf("failed to update lease %s: %s", leases[i].Uuid, err)
		}

		creditAccounts[tenantKeys[i]] = creditAccount

		// Aggregate settled amounts
		totalSettledAmounts, err = types.SafeAddCoins(totalSettledAmounts, settledAmounts)
		if err != nil {
			return nil, errorsmod.Wrap(err, "sum settled amounts while closing leases")
		}

		// Queue event for emission after successful commit
		// (creditAccount already has the updated ActiveLeaseCount from above)
		leaseEvents = append(leaseEvents, leaseEvent{
			uuid:            leases[i].Uuid,
			tenant:          tenantKeys[i],
			providerUUID:    leases[i].ProviderUuid,
			settledAmounts:  settledAmounts,
			closedBy:        leaseClosedBy,
			durationSeconds: durationSeconds.String(),
			activeCount:     creditAccount.ActiveLeaseCount,
			closureReason:   leases[i].ClosureReason,
		})
	}

	// Persist all credit account updates to the cache context.
	// Use tenantOrder (insertion-order slice) instead of ranging over the map.
	for _, tenant := range tenantOrder {
		if err := ms.k.SetCreditAccount(cacheCtx, creditAccounts[tenant]); err != nil {
			return nil, err
		}
	}

	// All operations succeeded - commit the cache to the main context
	writeCache()

	// Emit events after successful commit (events go to the original context)
	for _, ev := range leaseEvents {
		eventAttrs := []sdk.Attribute{
			sdk.NewAttribute(types.AttributeKeyLeaseUUID, ev.uuid),
			sdk.NewAttribute(types.AttributeKeyTenant, ev.tenant),
			sdk.NewAttribute(types.AttributeKeyProviderUUID, ev.providerUUID),
			sdk.NewAttribute(types.AttributeKeySettledAmounts, ev.settledAmounts.String()),
			sdk.NewAttribute(types.AttributeKeyClosedBy, ev.closedBy),
			sdk.NewAttribute(types.AttributeKeyDuration, ev.durationSeconds),
			sdk.NewAttribute(types.AttributeKeyActiveLeaseCount, strconv.FormatUint(ev.activeCount, 10)),
		}
		if ev.closureReason != "" {
			eventAttrs = append(eventAttrs, sdk.NewAttribute(types.AttributeKeyClosureReason, sanitize.EventAttribute(ev.closureReason)))
		}
		sdkCtx.EventManager().EmitEvent(
			sdk.NewEvent(types.EventTypeLeaseClosed, eventAttrs...),
		)
	}

	// Emit batch summary event when multiple leases are closed
	if len(leases) > 1 {
		sdkCtx.EventManager().EmitEvent(
			sdk.NewEvent(
				types.EventTypeBatchClosed,
				sdk.NewAttribute(types.AttributeKeyLeaseCount, strconv.FormatUint(uint64(len(leases)), 10)),
				sdk.NewAttribute(types.AttributeKeyClosedBy, closedBy),
				sdk.NewAttribute(types.AttributeKeySettledAmounts, totalSettledAmounts.String()),
			),
		)
	}

	return &types.MsgCloseLeaseResponse{
		ClosedAt:            blockTime,
		ClosedCount:         uint64(len(leases)),
		TotalSettledAmounts: totalSettledAmounts,
	}, nil
}

// Withdraw allows a provider to withdraw accrued funds from one or more leases.
// Specific-lease mode is atomic. Provider-wide mode isolates each lease in its
// own cache, reports failures in processing order, and continues the page.
func (ms msgServer) Withdraw(ctx context.Context, msg *types.MsgWithdraw) (*types.MsgWithdrawResponse, error) {
	if err := msg.ValidateBasic(); err != nil {
		return nil, err
	}

	// Dispatch based on mode
	if msg.ProviderUuid != "" {
		return ms.withdrawFromProvider(ctx, msg)
	}
	return ms.withdrawFromLeases(ctx, msg)
}

// withdrawFromLeases handles withdrawal from specific lease UUIDs.
// All leases must belong to the same provider.
func (ms msgServer) withdrawFromLeases(ctx context.Context, msg *types.MsgWithdraw) (*types.MsgWithdrawResponse, error) {
	sdkCtx := sdk.UnwrapSDKContext(ctx)
	blockTime := sdkCtx.BlockTime()

	// Phase 1: Validate ALL leases first (fail-fast on any error)
	leases := make([]types.Lease, 0, len(msg.LeaseUuids))
	tenantKeys := make([]string, 0, len(msg.LeaseUuids))
	creditAccounts := make(map[string]types.CreditAccount)
	tenantOrder := make([]string, 0)
	var provider skutypes.Provider
	var providerUUID string

	for i, leaseUUID := range msg.LeaseUuids {
		// Get lease
		lease, err := ms.k.GetLease(ctx, leaseUUID)
		if err != nil {
			return nil, err
		}

		// Verify all leases belong to the same provider
		if i == 0 {
			providerUUID = lease.ProviderUuid
			provider, _, err = ms.validateProviderAuthorization(ctx, msg.Sender, providerUUID, "withdraw from")
			if err != nil {
				return nil, err
			}
		} else if lease.ProviderUuid != providerUUID {
			return nil, types.ErrInvalidLease.Wrapf(
				"lease %s belongs to provider %s, expected %s (all leases must belong to same provider)",
				leaseUUID,
				lease.ProviderUuid,
				providerUUID,
			)
		}

		tenantAddr, err := sdk.AccAddressFromBech32(lease.Tenant)
		if err != nil {
			return nil, types.ErrInvalidLease.Wrapf("lease %s has invalid tenant address: %s", lease.Uuid, err)
		}
		tenantKey := tenantAddr.String()
		if _, exists := creditAccounts[tenantKey]; !exists {
			creditAccount, err := ms.k.GetCreditAccount(ctx, tenantKey)
			if err != nil {
				return nil, err
			}
			creditAccounts[tenantKey] = creditAccount
			tenantOrder = append(tenantOrder, tenantKey)
		}

		leases = append(leases, lease)
		tenantKeys = append(tenantKeys, tenantKey)
	}
	payoutAddr, err := storedProviderPayoutAddress(provider)
	if err != nil {
		return nil, err
	}
	payoutAddress := payoutAddr.String()

	// Phase 2: Apply all changes atomically using CacheContext
	cacheCtx, writeCache := sdkCtx.CacheContext()

	totalAmounts := sdk.NewCoins()
	withdrawalCount := uint64(0)
	autoClosedLeases := make([]string, 0)
	leaseAmounts := make(map[string]sdk.Coins) // Track per-lease amounts for events

	for i := range leases {
		lease := &leases[i]
		creditAccount := creditAccounts[tenantKeys[i]]

		// For active leases, check if we need to auto-close due to exhausted credit
		if lease.State == types.LEASE_STATE_ACTIVE {
			shouldAutoClose, closeTime, err := ms.k.ShouldAutoCloseLease(cacheCtx, lease, &creditAccount)
			if err != nil {
				return nil, err
			}
			if shouldAutoClose {
				result, err := ms.k.AutoCloseLease(cacheCtx, lease, &creditAccount, closeTime)
				if err != nil {
					return nil, err
				}

				autoClosedLeases = append(autoClosedLeases, lease.Uuid)
				leaseAmounts[lease.Uuid] = result.TransferAmounts
				if !result.TransferAmounts.IsZero() {
					totalAmounts, err = types.SafeAddCoins(totalAmounts, result.TransferAmounts)
					if err != nil {
						return nil, errorsmod.Wrap(err, "sum auto-close withdrawal amounts")
					}
				}
				creditAccounts[tenantKeys[i]] = creditAccount
				withdrawalCount++
				continue
			}
		}

		// Determine settlement time based on lease state
		var settleTime time.Time
		switch {
		case lease.State == types.LEASE_STATE_ACTIVE:
			settleTime = blockTime
		case lease.State == types.LEASE_STATE_CLOSED && lease.ClosedAt != nil:
			settleTime = *lease.ClosedAt
		default:
			settleTime = lease.LastSettledAt // No duration, will return zero
		}

		// Perform settlement
		result, err := ms.k.PerformSettlement(cacheCtx, lease, &creditAccount, settleTime)
		if err != nil {
			return nil, err
		}

		// Skip leases with zero withdrawable amount (don't fail, just skip)
		if result.AccruedAmounts.IsZero() {
			continue
		}

		// A live lease advances only through the whole seconds charged. Keeping
		// the sub-second remainder in LastSettledAt makes repeated settlements
		// equivalent to one settlement over their combined interval. A terminal
		// lease has no future accrual and keeps the historical close-time rule.
		if lease.State == types.LEASE_STATE_ACTIVE {
			lease.LastSettledAt = result.SettledThrough
		} else {
			lease.LastSettledAt = settleTime
		}
		if err := ms.k.SetLease(cacheCtx, *lease); err != nil {
			return nil, err
		}
		creditAccounts[tenantKeys[i]] = creditAccount

		totalAmounts, err = types.SafeAddCoins(totalAmounts, result.TransferAmounts)
		if err != nil {
			return nil, errorsmod.Wrap(err, "sum lease withdrawal amounts")
		}
		leaseAmounts[lease.Uuid] = result.TransferAmounts
		withdrawalCount++
	}

	// Check if there was nothing to withdraw from any lease
	if withdrawalCount == 0 && len(autoClosedLeases) == 0 {
		return nil, types.ErrNoWithdrawableAmount
	}
	for _, tenant := range tenantOrder {
		if err := ms.k.SetCreditAccount(cacheCtx, creditAccounts[tenant]); err != nil {
			return nil, err
		}
	}

	// All operations succeeded - commit the cache to the main context
	writeCache()

	// Phase 3: Emit events after successful commit
	// Build lookup set for O(1) auto-close checks
	autoClosedSet := make(map[string]struct{}, len(autoClosedLeases))
	for _, uuid := range autoClosedLeases {
		autoClosedSet[uuid] = struct{}{}
	}

	for i := range leases {
		lease := &leases[i]
		if amounts, ok := leaseAmounts[lease.Uuid]; ok {
			_, wasAutoClosed := autoClosedSet[lease.Uuid]
			emitProviderWithdrawalEvent(sdkCtx, lease, amounts, payoutAddress, wasAutoClosed)
		}
	}

	// Emit batch event if multiple leases processed
	if len(msg.LeaseUuids) > 1 {
		sdkCtx.EventManager().EmitEvent(
			sdk.NewEvent(
				types.EventTypeBatchWithdraw,
				sdk.NewAttribute(types.AttributeKeyLeaseCount, strconv.FormatUint(withdrawalCount, 10)),
				sdk.NewAttribute(types.AttributeKeyProviderUUID, providerUUID),
				sdk.NewAttribute(types.AttributeKeyAmount, totalAmounts.String()),
				sdk.NewAttribute(types.AttributeKeyPayoutAddress, payoutAddress),
			),
		)
	}

	return &types.MsgWithdrawResponse{
		TotalAmounts:    totalAmounts,
		PayoutAddress:   payoutAddress,
		WithdrawalCount: withdrawalCount,
		HasMore:         false, // Never has more in specific lease mode
	}, nil
}

// emitProviderWithdrawalEvent attributes each committed payout to its lease in
// both withdrawal modes. Failed or skipped per-lease caches emit no payout event.
func emitProviderWithdrawalEvent(ctx sdk.Context, lease *types.Lease, amounts sdk.Coins, payoutAddress string, autoClosed bool) {
	attributes := []sdk.Attribute{
		sdk.NewAttribute(types.AttributeKeyLeaseUUID, lease.Uuid),
		sdk.NewAttribute(types.AttributeKeyAmount, amounts.String()),
		sdk.NewAttribute(types.AttributeKeyProviderUUID, lease.ProviderUuid),
		sdk.NewAttribute(types.AttributeKeyPayoutAddress, payoutAddress),
	}
	if autoClosed {
		attributes = append(attributes, sdk.NewAttribute(types.AttributeKeyAutoClosed, "true"))
	}
	ctx.EventManager().EmitEvent(sdk.NewEvent(types.EventTypeProviderWithdraw, attributes...))
}

// withdrawFromProvider handles paginated withdrawal from all leases for a provider.
// Uses streaming iteration to avoid loading all leases into memory at once.
func (ms msgServer) withdrawFromProvider(ctx context.Context, msg *types.MsgWithdraw) (*types.MsgWithdrawResponse, error) {
	sdkCtx := sdk.UnwrapSDKContext(ctx)

	// Get provider and verify authorization
	providerUUID := msg.ProviderUuid
	provider, _, err := ms.validateProviderAuthorization(ctx, msg.Sender, providerUUID, "withdraw from")
	if err != nil {
		return nil, err
	}
	payoutAddr, err := storedProviderPayoutAddress(provider)
	if err != nil {
		return nil, err
	}
	payoutAddress := payoutAddr.String()

	// Apply default limit if not specified (limit=0 means use default, not unlimited)
	limit := msg.Limit
	if limit == 0 {
		limit = types.DefaultProviderWithdrawLimit
	}

	// Two-pass approach: collect lease UUIDs first, then process them.
	// This avoids iterator invalidation: when we modify lease state (e.g., auto-close),
	// the indexed map updates its indexes. Modifying indexes while iterating over them
	// can cause undefined behavior. This matches the pattern used in EndBlocker.
	//
	// Collect only ACTIVE leases. CLOSED leases are already fully settled at close
	// (LastSettledAt == ClosedAt), so collecting them only burns cap slots + gas.
	//
	// The cursor (msg.Key) is the last lease UUID returned by the previous call's
	// next_key. StartExclusive seeks past it at the store level (O(log n)) and is
	// tolerant of that lease having been closed between transactions. This relies
	// on collections.PairRange.StartExclusive resolving to a strict lower bound
	// (RangeKeyNext); TestMsgWithdraw_ProviderWideCursorSurvivesClosedBoundaryLease
	// pins that behavior so a future collections bump cannot silently change it.
	refKey := collections.Join(providerUUID, int32(types.LEASE_STATE_ACTIVE))
	rng := collections.NewPrefixedPairRange[collections.Pair[string, int32], string](refKey)
	if len(msg.Key) > 0 {
		rng = rng.StartExclusive(string(msg.Key))
	}

	iter, err := ms.k.Leases.Indexes.ProviderState.Iterate(ctx, rng)
	if err != nil {
		return nil, err
	}

	// Phase 1: Collect up to `limit` ACTIVE lease UUIDs; a (limit+1)th means has_more.
	var leaseUUIDs []string
	hasMore := false
	for ; iter.Valid(); iter.Next() {
		if uint64(len(leaseUUIDs)) >= limit {
			hasMore = true
			break
		}
		uuid, pkErr := iter.PrimaryKey()
		if pkErr != nil {
			if closeErr := iter.Close(); closeErr != nil {
				return nil, errors.Join(pkErr, closeErr)
			}
			return nil, pkErr
		}
		leaseUUIDs = append(leaseUUIDs, uuid)
	}
	if closeErr := iter.Close(); closeErr != nil {
		return nil, errorsmod.Wrap(closeErr, "close provider withdraw iterator")
	}

	// next_key is the last collected UUID; the next call resumes StartExclusive after it.
	var nextKey []byte
	if hasMore {
		nextKey = []byte(leaseUUIDs[len(leaseUUIDs)-1])
	}

	// Phase 2: Process collected leases (iterator is closed, safe to modify state)
	totalAmounts := sdk.NewCoins()
	var withdrawalCount uint64
	autoClosedCount := uint64(0)
	failedLeaseUUIDs := make([]string, 0)

	for _, leaseUUID := range leaseUUIDs {
		lease, getErr := ms.k.GetLease(ctx, leaseUUID)
		if getErr != nil {
			failedLeaseUUIDs = append(failedLeaseUUIDs, leaseUUID)
			ms.k.Logger().Error("failed to get lease for withdrawal",
				"lease_id", leaseUUID,
				"error", getErr,
			)
			continue
		}

		// Use CacheContext to make all state changes atomic per lease.
		// If any operation fails, the cache is discarded and no state changes
		// are committed for this lease.
		cacheCtx, write := sdkCtx.CacheContext()
		result, processErr := ms.k.executeProviderLeaseWithdrawal(cacheCtx, &lease)
		if processErr != nil {
			failedLeaseUUIDs = append(failedLeaseUUIDs, leaseUUID)
			// Provider-wide withdrawal is intentionally best effort. Discard this
			// lease's cache and continue with the remaining page.
			ms.k.Logger().Error("failed to process provider withdrawal lease",
				"lease_id", lease.Uuid,
				"tenant", lease.Tenant,
				"error", processErr,
			)
			continue
		}
		if !result.counted {
			continue
		}

		// Compute the response total before committing this lease so an
		// arithmetic failure cannot leave committed state without a response.
		updatedTotal := totalAmounts
		if !result.transferAmounts.IsZero() {
			updatedTotal, processErr = types.SafeAddCoins(totalAmounts, result.transferAmounts)
			if processErr != nil {
				return nil, errorsmod.Wrap(processErr, "sum provider withdrawal amounts")
			}
		}

		write()

		emitProviderWithdrawalEvent(sdkCtx, &lease, result.transferAmounts, payoutAddress, result.autoClosed)
		if result.autoClosed {
			sdkCtx.EventManager().EmitEvent(
				sdk.NewEvent(
					types.EventTypeLeaseAutoClose,
					sdk.NewAttribute(types.AttributeKeyLeaseUUID, lease.Uuid),
					sdk.NewAttribute(types.AttributeKeyTenant, lease.Tenant),
					sdk.NewAttribute(types.AttributeKeyProviderUUID, lease.ProviderUuid),
					sdk.NewAttribute(types.AttributeKeyAmount, result.transferAmounts.String()),
					sdk.NewAttribute(types.AttributeKeyPayoutAddress, payoutAddress),
					sdk.NewAttribute(types.AttributeKeyReason, "credit_exhausted"),
				),
			)
			autoClosedCount++
		}

		totalAmounts = updatedTotal
		withdrawalCount++
	}

	// Emit batch event
	sdkCtx.EventManager().EmitEvent(
		sdk.NewEvent(
			types.EventTypeBatchWithdraw,
			sdk.NewAttribute(types.AttributeKeyProviderUUID, providerUUID),
			sdk.NewAttribute(types.AttributeKeyAmount, totalAmounts.String()),
			sdk.NewAttribute(types.AttributeKeyLeaseCount, strconv.FormatUint(withdrawalCount, 10)),
			sdk.NewAttribute(types.AttributeKeyPayoutAddress, payoutAddress),
			sdk.NewAttribute(types.AttributeKeyAutoClosed, strconv.FormatUint(autoClosedCount, 10)),
			sdk.NewAttribute(types.AttributeKeyFailedLeaseCount, strconv.Itoa(len(failedLeaseUUIDs))),
			sdk.NewAttribute(types.AttributeKeyFailedLeaseUUIDs, strings.Join(failedLeaseUUIDs, ",")),
		),
	)

	return &types.MsgWithdrawResponse{
		TotalAmounts:     totalAmounts,
		PayoutAddress:    payoutAddress,
		WithdrawalCount:  withdrawalCount,
		HasMore:          hasMore,
		NextKey:          nextKey,
		FailedLeaseUuids: failedLeaseUUIDs,
	}, nil
}

// UpdateParams updates the module parameters.
func (ms msgServer) UpdateParams(ctx context.Context, msg *types.MsgUpdateParams) (*types.MsgUpdateParamsResponse, error) {
	if err := msg.ValidateBasic(); err != nil {
		return nil, err
	}

	authorityAddr, err := sdk.AccAddressFromBech32(ms.k.GetAuthority())
	if err != nil {
		return nil, err
	}
	msgAuthorityAddr, err := sdk.AccAddressFromBech32(msg.Authority)
	if err != nil {
		return nil, err
	}
	if !authorityAddr.Equals(msgAuthorityAddr) {
		return nil, types.ErrUnauthorized.Wrapf("expected %s, got %s", ms.k.GetAuthority(), msg.Authority)
	}

	if err := ms.k.SetParams(ctx, msg.Params); err != nil {
		return nil, err
	}

	sdkCtx := sdk.UnwrapSDKContext(ctx)
	sdkCtx.EventManager().EmitEvent(
		sdk.NewEvent(types.EventTypeParamsUpdated),
	)

	return &types.MsgUpdateParamsResponse{}, nil
}

// SetItemCustomDomain sets or clears the custom_domain on a specific
// LeaseItem within a lease.
func (ms msgServer) SetItemCustomDomain(ctx context.Context, msg *types.MsgSetItemCustomDomain) (*types.MsgSetItemCustomDomainResponse, error) {
	if err := msg.ValidateBasic(); err != nil {
		return nil, err
	}
	if _, err := ms.k.SetItemCustomDomain(ctx, msg.Sender, msg.LeaseUuid, msg.ServiceName, msg.CustomDomain); err != nil {
		return nil, err
	}
	return &types.MsgSetItemCustomDomainResponse{}, nil
}

// settleLeaseForClose transfers accrued charges and advances the terminal
// cursor to the exact close time. Unlike a live withdrawal, a closed lease has
// no later settlement into which a sub-second remainder could carry.
func (ms msgServer) settleLeaseForClose(
	ctx context.Context,
	lease *types.Lease,
	creditAccount *types.CreditAccount,
	settleTime time.Time,
) (sdk.Coins, error) {
	result, err := ms.k.PerformSettlement(ctx, lease, creditAccount, settleTime)
	if err != nil {
		return sdk.NewCoins(), err
	}

	// Terminal leases record the exact close time.
	lease.LastSettledAt = settleTime

	return result.TransferAmounts, nil
}

// pendingLeaseBatchResult holds the result of validating a batch of pending leases.
type pendingLeaseBatchResult struct {
	leases         []types.Lease
	tenantKeys     []string // canonical SDK Bech32 spelling, parallel to leases
	creditAccounts map[string]types.CreditAccount
	tenantOrder    []string // deterministic iteration order (insertion order)
	providerUUID   string
}

// validatePendingLeaseBatch validates a batch of leases for provider operations (acknowledge/reject).
// It ensures all leases exist, are in PENDING state, belong to the same provider, and have valid credit accounts.
// Returns the validated leases, credit accounts map, and provider UUID.
func (ms msgServer) validatePendingLeaseBatch(ctx context.Context, leaseUuids []string) (*pendingLeaseBatchResult, error) {
	leases := make([]types.Lease, 0, len(leaseUuids))
	tenantKeys := make([]string, 0, len(leaseUuids))
	creditAccounts := make(map[string]types.CreditAccount)
	tenantOrder := make([]string, 0, len(leaseUuids))
	var providerUUID string

	for _, uuid := range leaseUuids {
		lease, err := ms.k.GetLease(ctx, uuid)
		if err != nil {
			if !errors.Is(err, types.ErrLeaseNotFound) {
				return nil, err
			}
			return nil, types.ErrLeaseNotFound.Wrapf("lease %s not found", uuid)
		}

		if lease.State != types.LEASE_STATE_PENDING {
			return nil, types.ErrLeaseNotPending.Wrapf("lease %s is not in PENDING state", uuid)
		}

		tenantAddr, err := sdk.AccAddressFromBech32(lease.Tenant)
		if err != nil {
			return nil, types.ErrInvalidLease.Wrapf("lease %s has invalid tenant address: %s", uuid, err)
		}
		tenantKey := tenantAddr.String()

		// All leases must belong to same provider
		if providerUUID == "" {
			providerUUID = lease.ProviderUuid
		} else if lease.ProviderUuid != providerUUID {
			return nil, types.ErrMixedProviders.Wrapf("lease %s belongs to provider %s, expected %s", uuid, lease.ProviderUuid, providerUUID)
		}

		// Validate credit account exists for this tenant (only fetch once per tenant)
		if _, exists := creditAccounts[tenantKey]; !exists {
			creditAccount, err := ms.k.GetCreditAccount(ctx, tenantKey)
			if err != nil {
				if !errors.Is(err, types.ErrCreditAccountNotFound) {
					return nil, err
				}
				return nil, types.ErrCreditAccountNotFound.Wrapf(
					"credit account not found for tenant %s (lease %s): data integrity issue",
					lease.Tenant,
					uuid,
				)
			}
			creditAccounts[tenantKey] = creditAccount
			tenantOrder = append(tenantOrder, tenantKey)
		}

		leases = append(leases, lease)
		tenantKeys = append(tenantKeys, tenantKey)
	}

	return &pendingLeaseBatchResult{
		leases:         leases,
		tenantKeys:     tenantKeys,
		creditAccounts: creditAccounts,
		tenantOrder:    tenantOrder,
		providerUUID:   providerUUID,
	}, nil
}

// validateProviderAuthorization verifies the sender is authorized for provider operations.
// It returns both the provider and the sender's canonical SDK Bech32 spelling
// for use in address-valued event attributes.
func (ms msgServer) validateProviderAuthorization(ctx context.Context, sender, providerUUID, operation string) (skutypes.Provider, string, error) {
	provider, err := ms.k.skuKeeper.GetProvider(ctx, providerUUID)
	if err != nil {
		if !errors.Is(err, skutypes.ErrProviderNotFound) {
			return skutypes.Provider{}, "", err
		}
		return skutypes.Provider{}, "", types.ErrProviderNotFound.Wrapf("provider_uuid %s not found", providerUUID)
	}

	senderAddr, err := sdk.AccAddressFromBech32(sender)
	if err != nil {
		return skutypes.Provider{}, "", err
	}
	providerAddr, err := sdk.AccAddressFromBech32(provider.Address)
	if err != nil {
		return skutypes.Provider{}, "", err
	}
	authorityAddr, err := sdk.AccAddressFromBech32(ms.k.GetAuthority())
	if err != nil {
		return skutypes.Provider{}, "", err
	}

	if !senderAddr.Equals(providerAddr) && !senderAddr.Equals(authorityAddr) {
		return skutypes.Provider{}, "", types.ErrUnauthorized.Wrapf(
			"sender %s is not authorized to %s leases for provider %s",
			sender,
			operation,
			providerUUID,
		)
	}

	return provider, senderAddr.String(), nil
}

// validateLeaseActivationGates revalidates the time and tenant-cap constraints that
// must hold when PENDING leases become ACTIVE. It performs no writes so the entire
// acknowledgement batch fails before any state or event changes are attempted.
func validateLeaseActivationGates(blockTime time.Time, params types.Params, validated *pendingLeaseBatchResult) error {
	activationsByTenant := make(map[string]uint64, len(validated.creditAccounts))

	for i := range validated.leases {
		lease := &validated.leases[i]
		if params.PendingLeaseDeadlineExceeded(blockTime, lease.CreatedAt) {
			deadline := params.PendingLeaseDeadline(lease.CreatedAt)
			return types.ErrLeaseAcknowledgementDeadlineExceeded.Wrapf(
				"lease %s deadline %s passed at block time %s",
				lease.Uuid,
				deadline.UTC().Format(time.RFC3339Nano),
				blockTime.UTC().Format(time.RFC3339Nano),
			)
		}

		activationsByTenant[validated.tenantKeys[i]]++
	}

	// Iterate in the validated batch's deterministic tenant order. The first
	// condition protects the subtraction in the second condition from underflow
	// if imported or legacy state already exceeds the configured active cap.
	for _, tenant := range validated.tenantOrder {
		creditAccount := validated.creditAccounts[tenant]
		activations := activationsByTenant[tenant]
		if creditAccount.ActiveLeaseCount > params.MaxLeasesPerTenant ||
			activations > params.MaxLeasesPerTenant-creditAccount.ActiveLeaseCount {
			return types.ErrLeaseAcknowledgementActiveCapExceeded.Wrapf(
				"tenant %s has %d active leases and cannot activate %d more, max is %d",
				tenant,
				creditAccount.ActiveLeaseCount,
				activations,
				params.MaxLeasesPerTenant,
			)
		}
	}

	return nil
}

// AcknowledgeLease allows a provider to acknowledge one or more PENDING leases.
// This transitions the leases to ACTIVE state and starts billing after revalidating
// the hard pending deadline, each tenant's post-batch active lease count, and
// payout eligibility for every tenant in the batch.
// All leases must belong to the same provider. This is an atomic operation:
// all leases succeed or all fail.
func (ms msgServer) AcknowledgeLease(ctx context.Context, msg *types.MsgAcknowledgeLease) (*types.MsgAcknowledgeLeaseResponse, error) {
	if err := msg.ValidateBasic(); err != nil {
		return nil, err
	}

	sdkCtx := sdk.UnwrapSDKContext(ctx)
	blockTime := sdkCtx.BlockTime()

	// Phase 1: Validate all leases and authorization (fail-fast)
	validated, err := ms.validatePendingLeaseBatch(ctx, msg.LeaseUuids)
	if err != nil {
		return nil, err
	}

	provider, acknowledgedBy, err := ms.validateProviderAuthorization(ctx, msg.Sender, validated.providerUUID, "acknowledge")
	if err != nil {
		return nil, err
	}

	params, err := ms.k.GetParams(ctx)
	if err != nil {
		return nil, err
	}

	if err := validateLeaseActivationGates(blockTime, params, validated); err != nil {
		return nil, err
	}

	// Pending leases may predate payout validation, and provider settings can
	// change after admission. Recheck before accrual starts; cancel and reject
	// remain available while an ineligible payout is awaiting repair.
	payoutAddress, err := storedProviderPayoutAddress(provider)
	if err != nil {
		return nil, err
	}
	for _, tenant := range validated.tenantOrder {
		creditAddress, err := types.DeriveCreditAddressFromBech32(tenant)
		if err != nil {
			return nil, err
		}
		if err := ms.k.validatePayoutRecipient(payoutAddress, creditAddress); err != nil {
			return nil, err
		}
	}

	leases := validated.leases
	creditAccounts := validated.creditAccounts

	// Phase 2: Apply all changes atomically using CacheContext
	// This ensures that if any operation fails, all changes are rolled back.
	cacheCtx, writeCache := sdkCtx.CacheContext()

	// Track acknowledgement events to emit after successful commit.
	type leaseEvent struct {
		uuid         string
		tenant       string
		providerUUID string
	}
	leaseEvents := make([]leaseEvent, 0, len(leases))

	for i := range leases {
		// Transition lease to ACTIVE state
		leases[i].State = types.LEASE_STATE_ACTIVE
		leases[i].AcknowledgedAt = &blockTime
		leases[i].LastSettledAt = blockTime // Billing starts from acknowledgement

		if err := ms.k.SetLease(cacheCtx, leases[i]); err != nil {
			return nil, types.ErrInvalidLease.Wrapf("failed to update lease %s: %s", leases[i].Uuid, err)
		}

		// Update lease counts: decrement pending, increment active
		// Credit account existence was validated in Phase 1
		creditAccount := creditAccounts[validated.tenantKeys[i]]
		ms.k.DecrementPendingLeaseCount(&creditAccount, leases[i].Uuid)
		creditAccount.ActiveLeaseCount++
		creditAccounts[validated.tenantKeys[i]] = creditAccount // Update map with new counts

		// Queue event for emission after successful commit
		leaseEvents = append(leaseEvents, leaseEvent{
			uuid:         leases[i].Uuid,
			tenant:       validated.tenantKeys[i],
			providerUUID: leases[i].ProviderUuid,
		})
	}

	// Persist all credit account updates to the cache context.
	// Use validated.tenantOrder (insertion-order slice) instead of ranging over the map.
	for _, tenant := range validated.tenantOrder {
		if err := ms.k.SetCreditAccount(cacheCtx, creditAccounts[tenant]); err != nil {
			return nil, err
		}
	}

	// All operations succeeded - commit the cache to the main context
	writeCache()

	// Emit per-lease events after successful commit (events go to the original context)
	for _, ev := range leaseEvents {
		sdkCtx.EventManager().EmitEvent(
			sdk.NewEvent(
				types.EventTypeLeaseAcknowledged,
				sdk.NewAttribute(types.AttributeKeyLeaseUUID, ev.uuid),
				sdk.NewAttribute(types.AttributeKeyTenant, ev.tenant),
				sdk.NewAttribute(types.AttributeKeyProviderUUID, ev.providerUUID),
				sdk.NewAttribute(types.AttributeKeyAcknowledgedBy, acknowledgedBy),
			),
		)
	}

	// Emit batch summary event when multiple leases are acknowledged
	if len(leases) > 1 {
		sdkCtx.EventManager().EmitEvent(
			sdk.NewEvent(
				types.EventTypeBatchAcknowledged,
				sdk.NewAttribute(types.AttributeKeyLeaseCount, strconv.FormatUint(uint64(len(leases)), 10)),
				sdk.NewAttribute(types.AttributeKeyProviderUUID, validated.providerUUID),
				sdk.NewAttribute(types.AttributeKeyAcknowledgedBy, acknowledgedBy),
			),
		)
	}

	return &types.MsgAcknowledgeLeaseResponse{
		AcknowledgedAt:    blockTime,
		AcknowledgedCount: uint64(len(leases)),
	}, nil
}

// RejectLease allows a provider to reject one or more PENDING leases.
// All leases must belong to the same provider and be in PENDING state.
// This is an atomic operation: all leases succeed or all fail.
func (ms msgServer) RejectLease(ctx context.Context, msg *types.MsgRejectLease) (*types.MsgRejectLeaseResponse, error) {
	if err := msg.ValidateBasic(); err != nil {
		return nil, err
	}

	sdkCtx := sdk.UnwrapSDKContext(ctx)
	blockTime := sdkCtx.BlockTime()

	// Phase 1: Validate all leases and authorization (fail-fast)
	validated, err := ms.validatePendingLeaseBatch(ctx, msg.LeaseUuids)
	if err != nil {
		return nil, err
	}

	_, rejectedBy, err := ms.validateProviderAuthorization(ctx, msg.Sender, validated.providerUUID, "reject")
	if err != nil {
		return nil, err
	}

	leases := validated.leases
	creditAccounts := validated.creditAccounts

	// Phase 2: Apply all changes atomically using CacheContext
	// This ensures that if any operation fails, all changes are rolled back.
	cacheCtx, writeCache := sdkCtx.CacheContext()

	// Track rejection events to emit after successful commit.
	type leaseEvent struct {
		uuid         string
		tenant       string
		providerUUID string
	}
	leaseEvents := make([]leaseEvent, 0, len(leases))

	for i := range leases {
		// Transition lease to REJECTED state
		leases[i].State = types.LEASE_STATE_REJECTED
		leases[i].RejectedAt = &blockTime
		leases[i].RejectionReason = msg.Reason

		// Update lease counts: decrement pending
		// Credit account existence was validated in Phase 1
		creditAccount := creditAccounts[validated.tenantKeys[i]]
		ms.k.DecrementPendingLeaseCount(&creditAccount, leases[i].Uuid)

		// Release reservation for this lease (PENDING leases have reservations)
		if err := ms.k.ReleaseLeaseReservation(cacheCtx, &creditAccount, &leases[i]); err != nil {
			return nil, err
		}
		if err := ms.k.SetLease(cacheCtx, leases[i]); err != nil {
			return nil, types.ErrInvalidLease.Wrapf("failed to update lease %s: %s", leases[i].Uuid, err)
		}

		creditAccounts[validated.tenantKeys[i]] = creditAccount // Update map with new counts

		// Queue event for emission after successful commit
		leaseEvents = append(leaseEvents, leaseEvent{
			uuid:         leases[i].Uuid,
			tenant:       validated.tenantKeys[i],
			providerUUID: leases[i].ProviderUuid,
		})
	}

	// Persist all credit account updates to the cache context.
	// Use validated.tenantOrder (insertion-order slice) instead of ranging over the map.
	for _, tenant := range validated.tenantOrder {
		if err := ms.k.SetCreditAccount(cacheCtx, creditAccounts[tenant]); err != nil {
			return nil, err
		}
	}

	// All operations succeeded - commit the cache to the main context
	writeCache()

	// Emit per-lease events after successful commit (events go to the original context)
	// NOTE: We sanitize the rejection reason to prevent log injection attacks.
	for _, ev := range leaseEvents {
		sdkCtx.EventManager().EmitEvent(
			sdk.NewEvent(
				types.EventTypeLeaseRejected,
				sdk.NewAttribute(types.AttributeKeyLeaseUUID, ev.uuid),
				sdk.NewAttribute(types.AttributeKeyTenant, ev.tenant),
				sdk.NewAttribute(types.AttributeKeyProviderUUID, ev.providerUUID),
				sdk.NewAttribute(types.AttributeKeyRejectedBy, rejectedBy),
				sdk.NewAttribute(types.AttributeKeyRejectionReason, sanitize.EventAttribute(msg.Reason)),
			),
		)
	}

	// Emit batch summary event when multiple leases are rejected
	if len(leases) > 1 {
		sdkCtx.EventManager().EmitEvent(
			sdk.NewEvent(
				types.EventTypeBatchRejected,
				sdk.NewAttribute(types.AttributeKeyLeaseCount, strconv.FormatUint(uint64(len(leases)), 10)),
				sdk.NewAttribute(types.AttributeKeyProviderUUID, validated.providerUUID),
				sdk.NewAttribute(types.AttributeKeyRejectedBy, rejectedBy),
			),
		)
	}

	return &types.MsgRejectLeaseResponse{
		RejectedAt:    blockTime,
		RejectedCount: uint64(len(leases)),
	}, nil
}

// CancelLease allows a tenant to cancel one or more of their own PENDING leases.
// All leases must belong to the tenant and be in PENDING state.
// This is an atomic operation: all leases succeed or all fail.
func (ms msgServer) CancelLease(ctx context.Context, msg *types.MsgCancelLease) (*types.MsgCancelLeaseResponse, error) {
	if err := msg.ValidateBasic(); err != nil {
		return nil, err
	}

	sdkCtx := sdk.UnwrapSDKContext(ctx)
	blockTime := sdkCtx.BlockTime()

	tenantAddr, err := sdk.AccAddressFromBech32(msg.Tenant)
	if err != nil {
		return nil, err
	}
	tenantKey := tenantAddr.String()

	// Phase 1: Validate ALL leases first (fail-fast on any error)
	// Check lease existence and ownership before getting credit account
	leases := make([]types.Lease, 0, len(msg.LeaseUuids))

	for _, leaseUUID := range msg.LeaseUuids {
		// Get lease
		lease, err := ms.k.GetLease(ctx, leaseUUID)
		if err != nil {
			return nil, err
		}

		// Verify tenant owns this lease (check ownership before state)
		leaseTenantAddr, err := sdk.AccAddressFromBech32(lease.Tenant)
		if err != nil {
			return nil, types.ErrInvalidLease.Wrapf("lease %s has invalid tenant address: %s", leaseUUID, err)
		}
		if !tenantAddr.Equals(leaseTenantAddr) {
			return nil, types.ErrUnauthorized.Wrapf(
				"sender %s is not the tenant of lease %s (owned by %s)",
				msg.Tenant,
				leaseUUID,
				lease.Tenant,
			)
		}

		// Verify lease is in PENDING state
		if lease.State != types.LEASE_STATE_PENDING {
			return nil, types.ErrLeaseNotPending.Wrapf("lease %s is not in PENDING state", leaseUUID)
		}

		leases = append(leases, lease)
	}

	// Get and cache the tenant's credit account (after ownership validation)
	creditAccount, err := ms.k.GetCreditAccount(ctx, tenantKey)
	if err != nil {
		if !errors.Is(err, types.ErrCreditAccountNotFound) {
			return nil, err
		}
		return nil, types.ErrCreditAccountNotFound.Wrapf(
			"credit account not found for tenant %s",
			msg.Tenant,
		)
	}

	// Phase 2: Apply all changes atomically using CacheContext
	cacheCtx, writeCache := sdkCtx.CacheContext()

	for i := range leases {
		// Transition lease to REJECTED state (cancelled by tenant)
		leases[i].State = types.LEASE_STATE_REJECTED
		leases[i].RejectedAt = &blockTime
		leases[i].RejectionReason = types.RejectionReasonCancelledByTenant

		// Decrement pending lease count in credit account
		ms.k.DecrementPendingLeaseCount(&creditAccount, leases[i].Uuid)

		// Release reservation for this lease (PENDING leases have reservations)
		if err := ms.k.ReleaseLeaseReservation(cacheCtx, &creditAccount, &leases[i]); err != nil {
			return nil, err
		}
		if err := ms.k.SetLease(cacheCtx, leases[i]); err != nil {
			return nil, types.ErrInvalidLease.Wrapf("failed to update lease %s: %s", leases[i].Uuid, err)
		}
	}

	// Save credit account with updated pending count and released reservations
	if err := ms.k.SetCreditAccount(cacheCtx, creditAccount); err != nil {
		return nil, err
	}

	// All operations succeeded - commit the cache to the main context
	writeCache()

	// Phase 3: Emit events after successful commit
	for i := range leases {
		sdkCtx.EventManager().EmitEvent(
			sdk.NewEvent(
				types.EventTypeLeaseCancelled,
				sdk.NewAttribute(types.AttributeKeyLeaseUUID, leases[i].Uuid),
				sdk.NewAttribute(types.AttributeKeyTenant, tenantKey),
				sdk.NewAttribute(types.AttributeKeyProviderUUID, leases[i].ProviderUuid),
				sdk.NewAttribute(types.AttributeKeyCancelledBy, tenantKey),
			),
		)
	}

	// Emit batch event if multiple leases cancelled
	if len(leases) > 1 {
		sdkCtx.EventManager().EmitEvent(
			sdk.NewEvent(
				types.EventTypeBatchCancelled,
				sdk.NewAttribute(types.AttributeKeyLeaseCount, strconv.FormatUint(uint64(len(leases)), 10)),
				sdk.NewAttribute(types.AttributeKeyTenant, tenantKey),
				sdk.NewAttribute(types.AttributeKeyCancelledBy, tenantKey),
			),
		)
	}

	return &types.MsgCancelLeaseResponse{
		CancelledAt:    blockTime,
		CancelledCount: uint64(len(leases)),
	}, nil
}
