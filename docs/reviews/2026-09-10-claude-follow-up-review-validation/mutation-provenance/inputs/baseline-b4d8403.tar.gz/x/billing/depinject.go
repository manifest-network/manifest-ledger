// Package module wires the billing module into the application.
package module

import (
	"cosmossdk.io/core/appmodule"
	"cosmossdk.io/core/store"
	"cosmossdk.io/depinject"
	"cosmossdk.io/log"

	"github.com/cosmos/cosmos-sdk/codec"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	govtypes "github.com/cosmos/cosmos-sdk/x/gov/types"

	modulev1 "github.com/manifest-network/manifest-ledger/api/liftedinit/billing/module/v1"
	"github.com/manifest-network/manifest-ledger/x/billing/keeper"
	billingtypes "github.com/manifest-network/manifest-ledger/x/billing/types"
	skukeeper "github.com/manifest-network/manifest-ledger/x/sku/keeper"
)

var _ appmodule.AppModule = AppModule{}

// IsOnePerModuleType implements the depinject.OnePerModuleType interface.
func (am AppModule) IsOnePerModuleType() {}

// IsAppModule implements the appmodule.AppModule interface.
func (am AppModule) IsAppModule() {}

func init() {
	appmodule.Register(
		&modulev1.Module{},
		appmodule.Provide(ProvideModule),
	)
}

// ModuleInputs defines the inputs required for providing the module.
//
//nolint:revive
type ModuleInputs struct {
	depinject.In

	Cdc           codec.Codec
	StoreService  store.KVStoreService
	Logger        log.Logger
	SKUKeeper     skukeeper.Keeper
	BankKeeper    billingtypes.BankKeeper
	AccountKeeper billingtypes.AccountKeeper
}

// ModuleOutputs defines the outputs provided by the module.
//
//nolint:revive
type ModuleOutputs struct {
	depinject.Out

	Module appmodule.AppModule
	Keeper keeper.Keeper
}

// ProvideModule provides the module with its dependencies.
func ProvideModule(in ModuleInputs) ModuleOutputs {
	k := keeper.NewKeeper(
		in.Cdc,
		in.StoreService,
		in.Logger,
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
		&in.SKUKeeper,
		in.BankKeeper,
		in.AccountKeeper,
	)
	m := NewAppModule(in.Cdc, k, in.SKUKeeper)

	return ModuleOutputs{Module: m, Keeper: k, Out: depinject.Out{}}
}
