package types_test

import (
	"fmt"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/require"

	"cosmossdk.io/math"

	"github.com/cosmos/cosmos-sdk/testutil/testdata"
	sdk "github.com/cosmos/cosmos-sdk/types"

	"github.com/manifest-network/manifest-ledger/x/billing/types"
)

func TestIsValidFQDN(t *testing.T) {
	cases := []struct {
		name    string
		domain  string
		wantErr bool
	}{
		{"valid", "app.example.com", false},
		{"valid_subdomain", "a.b.c.example.test", false},
		{"valid_with_hyphen", "my-app.example.com", false},
		{"valid_max_label", strings.Repeat("a", 63) + ".com", false},
		{"empty", "", true},
		{"too_long", strings.Repeat("a", 254), true},
		{"uppercase", "App.Example.Com", true},
		{"with_scheme", "https://example.com", true},
		{"with_path", "example.com/foo", true},
		{"with_space", "ex ample.com", true},
		{"with_at", "user@example.com", true},
		{"with_wildcard", "*.example.com", true},
		{"with_question", "example.com?x=1", true},
		{"with_hash", "example.com#frag", true},
		{"leading_dot", ".example.com", true},
		{"trailing_dot", "example.com.", true},
		{"no_dot", "localhost", true},
		{"label_too_long", strings.Repeat("a", 64) + ".com", true},
		{"label_leading_hyphen", "-foo.example.com", true},
		{"label_trailing_hyphen", "foo-.example.com", true},
		{"empty_label", "foo..example.com", true},
		{"all_numeric_tld", "192.168.1.1", true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			err := types.IsValidFQDN(tc.domain)
			if tc.wantErr {
				require.Error(t, err, "expected error for %q", tc.domain)
			} else {
				require.NoError(t, err, "unexpected error for %q: %v", tc.domain, err)
			}
		})
	}
}

func TestMatchesReservedSuffix(t *testing.T) {
	reserved := []string{".barney0.manifest0.net", ".barney8.manifest0.net"}

	cases := []struct {
		name   string
		domain string
		match  bool
	}{
		{"subdomain_match", "app.barney0.manifest0.net", true},
		{"deeper_subdomain_match", "x.y.z.barney0.manifest0.net", true},
		{"apex_match", "barney0.manifest0.net", true},
		{"second_suffix_match", "app.barney8.manifest0.net", true},
		{"case_insensitive", "App.BARNEY0.manifest0.net", true},
		{"non_match_no_boundary", "xbarney0.manifest0.net", false},
		{"non_match_unrelated", "app.example.com", false},
		{"non_match_partial_apex", "manifest0.net", false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			require.Equal(t, tc.match, types.MatchesReservedSuffix(tc.domain, reserved))
		})
	}
}

func TestMatchesReservedSuffix_FailsClosedOnMalformedEntries(t *testing.T) {
	// Entries that should be rejected by Params.Validate (no leading dot, or
	// shorter than 2 characters) are treated as a match — fail-closed for a
	// security check. The matcher is reached only if a malformed entry slipped
	// past validation, in which case refusing the claim is the safe default.
	require.True(t, types.MatchesReservedSuffix("app.barney0.manifest0.net", []string{"barney0.manifest0.net"}))
	require.True(t, types.MatchesReservedSuffix("app.example.com", []string{"."}))
}

func TestParamsValidate_ReservedDomainSuffixes(t *testing.T) {
	base := types.DefaultParams()

	cases := []struct {
		name     string
		suffixes []string
		wantErr  bool
	}{
		{"empty_ok", nil, false},
		{"valid_single", []string{".example.com"}, false},
		{"valid_multi", []string{".a.example.com", ".b.example.com"}, false},
		{"missing_leading_dot", []string{"example.com"}, true},
		{"only_dot", []string{"."}, true},
		{"invalid_fqdn_after_dot", []string{".."}, true},
		{"uppercase", []string{".Example.Com"}, true},
		{"duplicate", []string{".example.com", ".example.com"}, true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			p := base
			p.ReservedDomainSuffixes = tc.suffixes
			err := p.Validate()
			if tc.wantErr {
				require.Error(t, err)
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestParamsValidateReservedDomainSuffixCardinality(t *testing.T) {
	atLimit := types.DefaultParams()
	atLimit.ReservedDomainSuffixes = make([]string, types.MaxReservedDomainSuffixEntries)
	for i := range atLimit.ReservedDomainSuffixes {
		atLimit.ReservedDomainSuffixes[i] = fmt.Sprintf(".zone-%03d.example.com", i)
	}
	require.NoError(t, atLimit.Validate())

	overLimit := types.DefaultParams()
	overLimit.ReservedDomainSuffixes = append(
		[]string(nil),
		atLimit.ReservedDomainSuffixes...,
	)
	overLimit.ReservedDomainSuffixes = append(
		overLimit.ReservedDomainSuffixes,
		".overflow.example.com",
	)
	err := overLimit.Validate()
	require.ErrorIs(t, err, types.ErrInvalidParams)
	require.Contains(t, err.Error(), "reserved domain suffix list has 101 entries, maximum allowed is 100")
}

func TestGenesisValidate_RejectsAmbiguousCustomDomain(t *testing.T) {
	// Multi-item legacy lease (no service_names) with a custom_domain on one
	// item is unaddressable. The new defensive check must reject it before any
	// downstream credit-account check fires. Constructing a fully-valid happy-
	// path genesis is covered by the keeper-level genesis tests; this focuses
	// on the new rejection branch.
	now := time.Now().UTC()
	const leaseUUID = "01912345-6789-7abc-8def-aaaaaaaaaaaa"
	const skuUUID1 = "01912345-6789-7abc-8def-bbbbbbbbbbbb"
	const skuUUID2 = "01912345-6789-7abc-8def-cccccccccccc"
	const providerUUID = "01912345-6789-7abc-8def-dddddddddddd"
	_, _, tenantAddr := testdata.KeyTestPubAddr()

	gs := types.GenesisState{
		Params: types.DefaultParams(),
		Leases: []types.Lease{{
			Uuid:         leaseUUID,
			Tenant:       tenantAddr.String(),
			ProviderUuid: providerUUID,
			Items: []types.LeaseItem{
				{SkuUuid: skuUUID1, Quantity: 1, LockedPrice: sdk.NewCoin("umfx", math.NewInt(1)), CustomDomain: "x.example.com"},
				{SkuUuid: skuUUID2, Quantity: 1, LockedPrice: sdk.NewCoin("umfx", math.NewInt(1))},
			},
			State:         types.LEASE_STATE_PENDING,
			CreatedAt:     now,
			LastSettledAt: now,
		}},
	}
	err := gs.Validate()
	require.Error(t, err)
	require.ErrorIs(t, err, types.ErrAmbiguousLeaseItem)
}

func TestGenesisValidate_RejectsDuplicateLiveCustomDomain(t *testing.T) {
	now := time.Now().UTC()
	_, _, tenantAddr := testdata.KeyTestPubAddr()
	const domain = "shared.example.com"
	const providerUUID = "01912345-6789-7abc-8def-dddddddddddd"
	const skuUUID = "01912345-6789-7abc-8def-bbbbbbbbbbbb"

	newLease := func(uuid, serviceName string, state types.LeaseState) types.Lease {
		return types.Lease{
			Uuid:         uuid,
			Tenant:       tenantAddr.String(),
			ProviderUuid: providerUUID,
			Items: []types.LeaseItem{{
				SkuUuid:      skuUUID,
				Quantity:     1,
				LockedPrice:  sdk.NewCoin("umfx", math.NewInt(1)),
				ServiceName:  serviceName,
				CustomDomain: domain,
			}},
			State:         state,
			CreatedAt:     now,
			LastSettledAt: now,
		}
	}

	for _, validate := range []struct {
		name string
		fn   func(*types.GenesisState) error
	}{
		{name: "import", fn: (*types.GenesisState).Validate},
		{name: "strict", fn: (*types.GenesisState).ValidateStrict},
	} {
		t.Run(validate.name, func(t *testing.T) {
			gs := &types.GenesisState{
				Params: types.DefaultParams(),
				Leases: []types.Lease{
					newLease("01912345-6789-7abc-8def-aaaaaaaaaaa1", "web", types.LEASE_STATE_PENDING),
					newLease("01912345-6789-7abc-8def-aaaaaaaaaaa2", "api", types.LEASE_STATE_ACTIVE),
				},
				LeaseSequence: 2,
			}

			err := validate.fn(gs)
			require.ErrorIs(t, err, types.ErrCustomDomainAlreadyClaimed)
			require.Contains(t, err.Error(), domain)
			require.Contains(t, err.Error(), gs.Leases[0].Uuid)
			require.Contains(t, err.Error(), gs.Leases[1].Uuid)
		})
	}

	t.Run("terminal audit fields do not own the domain", func(t *testing.T) {
		gs := &types.GenesisState{
			Params: types.DefaultParams(),
			Leases: []types.Lease{
				newLease("01912345-6789-7abc-8def-aaaaaaaaaaa1", "web", types.LEASE_STATE_REJECTED),
				newLease("01912345-6789-7abc-8def-aaaaaaaaaaa2", "api", types.LEASE_STATE_EXPIRED),
			},
			LeaseSequence: 2,
		}

		require.NoError(t, gs.Validate())
		require.NoError(t, gs.ValidateStrict())
	})
}

// TestGenesisValidateStrict_RejectsReservedSuffixCustomDomain verifies that
// strict authoring validation refuses a custom_domain claim that falls under a
// reserved provider suffix in the same Params.ReservedDomainSuffixes list.
// Without this check, newly authored state could contain a claim the msg layer
// would reject at runtime.
func TestGenesisValidateStrict_RejectsReservedSuffixCustomDomain(t *testing.T) {
	now := time.Now().UTC()
	const leaseUUID = "01912345-6789-7abc-8def-eeeeeeeeeeee"
	const skuUUID = "01912345-6789-7abc-8def-ffffffffffff"
	const providerUUID = "01912345-6789-7abc-8def-ffffffffeeee"
	_, _, tenantAddr := testdata.KeyTestPubAddr()

	params := types.DefaultParams()
	params.ReservedDomainSuffixes = []string{".barney0.manifest0.net"}

	gs := types.GenesisState{
		Params: params,
		Leases: []types.Lease{{
			Uuid:         leaseUUID,
			Tenant:       tenantAddr.String(),
			ProviderUuid: providerUUID,
			Items: []types.LeaseItem{
				{
					SkuUuid:      skuUUID,
					Quantity:     1,
					LockedPrice:  sdk.NewCoin("umfx", math.NewInt(1)),
					CustomDomain: "app.barney0.manifest0.net",
				},
			},
			State:         types.LEASE_STATE_PENDING,
			CreatedAt:     now,
			LastSettledAt: now,
		}},
	}
	err := gs.ValidateStrict()
	require.Error(t, err)
	require.ErrorIs(t, err, types.ErrInvalidCustomDomain)
	require.Contains(t, err.Error(), "reserved provider suffix")
}

func TestMsgSetItemCustomDomain_ValidateBasic(t *testing.T) {
	const validUUID = "01912345-6789-7abc-8def-0123456789ab"
	_, _, addr := testdata.KeyTestPubAddr()
	validAddr := addr.String()

	cases := []struct {
		name    string
		msg     types.MsgSetItemCustomDomain
		wantErr bool
	}{
		{
			name:    "valid_set_with_service_name",
			msg:     types.MsgSetItemCustomDomain{Sender: validAddr, LeaseUuid: validUUID, ServiceName: "web", CustomDomain: "app.example.com"},
			wantErr: false,
		},
		{
			name:    "valid_set_empty_service_name_for_legacy_lease",
			msg:     types.MsgSetItemCustomDomain{Sender: validAddr, LeaseUuid: validUUID, ServiceName: "", CustomDomain: "app.example.com"},
			wantErr: false,
		},
		{
			name:    "valid_clear",
			msg:     types.MsgSetItemCustomDomain{Sender: validAddr, LeaseUuid: validUUID, ServiceName: "web", CustomDomain: ""},
			wantErr: false,
		},
		{
			name:    "invalid_sender",
			msg:     types.MsgSetItemCustomDomain{Sender: "not-bech32", LeaseUuid: validUUID, ServiceName: "web", CustomDomain: "x.com"},
			wantErr: true,
		},
		{
			name:    "empty_uuid",
			msg:     types.MsgSetItemCustomDomain{Sender: validAddr, LeaseUuid: "", ServiceName: "web", CustomDomain: "x.com"},
			wantErr: true,
		},
		{
			name:    "bad_uuid",
			msg:     types.MsgSetItemCustomDomain{Sender: validAddr, LeaseUuid: "not-a-uuid", ServiceName: "web", CustomDomain: "x.com"},
			wantErr: true,
		},
		{
			name:    "bad_service_name_uppercase",
			msg:     types.MsgSetItemCustomDomain{Sender: validAddr, LeaseUuid: validUUID, ServiceName: "Web", CustomDomain: "x.com"},
			wantErr: true,
		},
		{
			name:    "bad_service_name_too_long",
			msg:     types.MsgSetItemCustomDomain{Sender: validAddr, LeaseUuid: validUUID, ServiceName: strings.Repeat("a", 64), CustomDomain: "x.com"},
			wantErr: true,
		},
		{
			name:    "bad_fqdn",
			msg:     types.MsgSetItemCustomDomain{Sender: validAddr, LeaseUuid: validUUID, ServiceName: "web", CustomDomain: "NoUpper.com"},
			wantErr: true,
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.wantErr {
				require.Error(t, err)
			} else {
				require.NoError(t, err)
			}
		})
	}
}
