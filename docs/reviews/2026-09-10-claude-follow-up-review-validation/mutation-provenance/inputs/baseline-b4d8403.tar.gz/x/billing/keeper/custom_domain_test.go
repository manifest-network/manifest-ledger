package keeper_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	"cosmossdk.io/collections"
	errorsmod "cosmossdk.io/errors"
	sdkmath "cosmossdk.io/math"
	storetypes "cosmossdk.io/store/types"

	sdk "github.com/cosmos/cosmos-sdk/types"

	"github.com/manifest-network/manifest-ledger/x/billing/keeper"
	"github.com/manifest-network/manifest-ledger/x/billing/types"
	skutypes "github.com/manifest-network/manifest-ledger/x/sku/types"
)

// Service names carried by the multi-item fixtures below. Declared as constants
// because they are also compared and switched on, not just passed as arguments.
const (
	serviceWeb = "web"
	serviceDB  = "db"
)

// customDomainSetup spins up a fixture with one tenant + provider, an active
// lease, and an allowed-list account. The default lease is 1-item legacy mode
// (item.service_name = ""), addressable via msg.service_name = "".
type customDomainSetup struct {
	f            *testFixture
	msgServer    types.MsgServer
	tenant       sdk.AccAddress
	provider     skutypes.Provider
	providerAddr sdk.AccAddress
	allowed      sdk.AccAddress
	stranger     sdk.AccAddress
	sku          skutypes.SKU
	leaseUUID    string
}

func setupCustomDomain(t *testing.T) *customDomainSetup {
	t.Helper()
	f := initFixture(t)
	msgServer := keeper.NewMsgServerImpl(f.App.BillingKeeper)

	tenant := f.TestAccs[0]
	providerAddr := f.TestAccs[1]
	payoutAddr := f.TestAccs[2]
	allowed := f.TestAccs[3]
	stranger := f.TestAccs[4]

	provider := f.createTestProvider(t, providerAddr.String(), payoutAddr.String())
	sku := f.createTestSKU(t, provider.Uuid, 3600)

	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(testDenom, sdkmath.NewInt(100_000_000))))
	require.NoError(t, f.App.BillingKeeper.SetCreditAccount(f.Ctx, types.CreditAccount{
		Tenant:        tenant.String(),
		CreditAddress: creditAddr.String(),
	}))

	params, err := f.App.BillingKeeper.GetParams(f.Ctx)
	require.NoError(t, err)
	params.AllowedList = []string{allowed.String()}
	require.NoError(t, f.App.BillingKeeper.SetParams(f.Ctx, params))

	leaseUUID := f.createAndAcknowledgeLease(t, msgServer, tenant, providerAddr, []types.LeaseItemInput{
		{SkuUuid: sku.Uuid, Quantity: 1},
	})

	return &customDomainSetup{
		f: f, msgServer: msgServer,
		tenant: tenant, provider: provider, providerAddr: providerAddr,
		allowed: allowed, stranger: stranger,
		sku: sku, leaseUUID: leaseUUID,
	}
}

func TestCustomDomainOperationalReadsClassifyCorruption(t *testing.T) {
	assertCorruption := func(t *testing.T, err error) {
		t.Helper()
		require.ErrorIs(t, err, types.ErrInternalCorruption)
		codespace, code, _ := errorsmod.ABCIInfo(err, false)
		require.Equal(t, types.ModuleName, codespace)
		require.Equal(t, uint32(40), code)
	}
	corruptTarget := func(t *testing.T, s *customDomainSetup, domain string) {
		t.Helper()
		key, err := collections.EncodeKeyWithPrefix(
			types.CustomDomainIndexKey.Bytes(),
			collections.StringKey,
			domain,
		)
		require.NoError(t, err)
		s.f.Ctx.KVStore(s.f.App.GetKey(types.StoreKey)).Set(key, []byte{0xff})
	}

	t.Run("assignment pre-flight", func(t *testing.T) {
		s := setupCustomDomain(t)
		const domain = "corrupt-preflight.example.com"
		corruptTarget(t, s, domain)

		_, err := s.f.App.BillingKeeper.SetItemCustomDomain(
			s.f.Ctx, s.tenant.String(), s.leaseUUID, "", domain,
		)
		assertCorruption(t, err)

		lease, getErr := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.leaseUUID)
		require.NoError(t, getErr)
		require.Empty(t, lease.Items[0].CustomDomain)
	})

	t.Run("reconcile release", func(t *testing.T) {
		s := setupCustomDomain(t)
		const domain = "corrupt-release.example.com"
		_, err := s.f.App.BillingKeeper.SetItemCustomDomain(
			s.f.Ctx, s.tenant.String(), s.leaseUUID, "", domain,
		)
		require.NoError(t, err)
		corruptTarget(t, s, domain)

		_, err = s.f.App.BillingKeeper.SetItemCustomDomain(
			s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "",
		)
		assertCorruption(t, err)

		lease, getErr := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.leaseUUID)
		require.NoError(t, getErr)
		require.Equal(t, domain, lease.Items[0].CustomDomain, "failed reconcile must not commit the lease mutation")
	})

	t.Run("reconcile install", func(t *testing.T) {
		s := setupCustomDomain(t)
		const domain = "corrupt-install.example.com"
		corruptTarget(t, s, domain)
		lease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.leaseUUID)
		require.NoError(t, err)
		lease.Items[0].CustomDomain = domain

		err = s.f.App.BillingKeeper.SetLease(s.f.Ctx, lease)
		assertCorruption(t, err)

		stored, getErr := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.leaseUUID)
		require.NoError(t, getErr)
		require.Empty(t, stored.Items[0].CustomDomain, "failed reconcile must not commit the lease mutation")
	})

	t.Run("query lookup", func(t *testing.T) {
		s := setupCustomDomain(t)
		const domain = "corrupt-query.example.com"
		corruptTarget(t, s, domain)

		_, _, _, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, domain)
		assertCorruption(t, err)
	})
}

// createMultiItemLease creates a multi-item ACTIVE lease in service-name mode
// with two items keyed by `web` and `db`. Returns the lease UUID.
func (s *customDomainSetup) createMultiItemLease(t *testing.T) string {
	t.Helper()
	return s.f.createAndAcknowledgeLease(t, s.msgServer, s.tenant, s.providerAddr, []types.LeaseItemInput{
		{SkuUuid: s.sku.Uuid, Quantity: 1, ServiceName: "web"},
		{SkuUuid: s.sku.Uuid, Quantity: 1, ServiceName: "db"},
	})
}

// createMultiItemLegacyLease creates a multi-item ACTIVE lease in legacy mode
// (no service_names). Two items with distinct SKUs to satisfy the legacy
// uniqueness rule. Returns the lease UUID and a second SKU we created.
func (s *customDomainSetup) createMultiItemLegacyLease(t *testing.T) (string, skutypes.SKU) {
	t.Helper()
	sku2 := s.f.createTestSKU(t, s.provider.Uuid, 3600)
	uuid := s.f.createAndAcknowledgeLease(t, s.msgServer, s.tenant, s.providerAddr, []types.LeaseItemInput{
		{SkuUuid: s.sku.Uuid, Quantity: 1},
		{SkuUuid: sku2.Uuid, Quantity: 1},
	})
	return uuid, sku2
}

// --- 1-item legacy lease (the default fixture) ---

func TestSetItemCustomDomain_LegacyOneItem_HappyPath(t *testing.T) {
	s := setupCustomDomain(t)

	role, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "app.example.com")
	require.NoError(t, err)
	require.Equal(t, types.AttributeValueRoleTenant, role)

	lease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.leaseUUID)
	require.NoError(t, err)
	require.Equal(t, "app.example.com", lease.Items[0].CustomDomain)

	got, serviceName, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "app.example.com")
	require.NoError(t, err)
	require.True(t, has)
	require.Equal(t, s.leaseUUID, got.Uuid)
	require.Equal(t, "", serviceName, "1-item legacy returns empty service_name in reverse lookup")
}

func TestSetItemCustomDomain_LegacyOneItem_NormalisesInput(t *testing.T) {
	s := setupCustomDomain(t)
	// Keeper-level normalises whitespace + case (ValidateBasic at msg layer
	// would reject uppercase outright; the keeper's normalisation is defence
	// for direct callers like genesis).
	role, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", " App.Example.COM ")
	require.NoError(t, err)
	require.Equal(t, types.AttributeValueRoleTenant, role)

	got, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "app.example.com")
	require.NoError(t, err)
	require.True(t, has)
	require.Equal(t, s.leaseUUID, got.Uuid)
}

func TestSetItemCustomDomain_LegacyOneItem_NonEmptyServiceName_NotFound(t *testing.T) {
	s := setupCustomDomain(t)
	// 1-item legacy lease has item.service_name = ""; passing "web" doesn't match.
	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "web", "x.example.com")
	require.Error(t, err)
	require.ErrorIs(t, err, types.ErrLeaseItemNotFound)
}

func TestSetItemCustomDomain_ClearAllowsReclaim(t *testing.T) {
	s := setupCustomDomain(t)

	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "app.example.com")
	require.NoError(t, err)

	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "")
	require.NoError(t, err)

	lease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.leaseUUID)
	require.NoError(t, err)
	require.Empty(t, lease.Items[0].CustomDomain)

	_, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "app.example.com")
	require.NoError(t, err)
	require.False(t, has)

	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "app.example.com")
	require.NoError(t, err)
}

func TestSetItemCustomDomain_AuthorisationMatrix(t *testing.T) {
	cases := []struct {
		name     string
		who      func(s *customDomainSetup) sdk.AccAddress
		wantRole string
		wantErr  bool
	}{
		{"tenant", func(s *customDomainSetup) sdk.AccAddress { return s.tenant }, types.AttributeValueRoleTenant, false},
		{"authority", func(s *customDomainSetup) sdk.AccAddress { return s.f.Authority }, types.AttributeValueRoleAuthority, false},
		{"allowed", func(s *customDomainSetup) sdk.AccAddress { return s.allowed }, types.AttributeValueRoleAllowed, false},
		{"stranger", func(s *customDomainSetup) sdk.AccAddress { return s.stranger }, "", true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			s := setupCustomDomain(t)
			role, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, tc.who(s).String(), s.leaseUUID, "", "x.example.com")
			if tc.wantErr {
				require.Error(t, err)
				require.ErrorIs(t, err, types.ErrUnauthorized)
				return
			}
			require.NoError(t, err)
			require.Equal(t, tc.wantRole, role)
		})
	}
}

func TestSetItemCustomDomain_ReservedSuffix(t *testing.T) {
	cases := []struct {
		name    string
		domain  string
		wantErr bool
	}{
		{"subdomain_blocked", "app.barney0.manifest0.net", true},
		{"apex_blocked", "barney0.manifest0.net", true},
		{"no_boundary_allowed", "xbarney0.manifest0.net", false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			s := setupCustomDomain(t)
			params, err := s.f.App.BillingKeeper.GetParams(s.f.Ctx)
			require.NoError(t, err)
			params.ReservedDomainSuffixes = []string{".barney0.manifest0.net"}
			require.NoError(t, s.f.App.BillingKeeper.SetParams(s.f.Ctx, params))

			_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", tc.domain)
			if tc.wantErr {
				require.Error(t, err)
				require.ErrorIs(t, err, types.ErrInvalidCustomDomain)
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestSetItemCustomDomain_RejectedOnTerminalState(t *testing.T) {
	s := setupCustomDomain(t)
	_, err := s.msgServer.CloseLease(s.f.Ctx, &types.MsgCloseLease{
		Sender:     s.tenant.String(),
		LeaseUuids: []string{s.leaseUUID},
	})
	require.NoError(t, err)

	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "x.example.com")
	require.Error(t, err)
	require.ErrorIs(t, err, types.ErrLeaseNotEditable)

	// Even authority cannot bypass the state check.
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.f.Authority.String(), s.leaseUUID, "", "x.example.com")
	require.Error(t, err)
	require.ErrorIs(t, err, types.ErrLeaseNotEditable)
}

// --- multi-item service-mode lease ---

func TestSetItemCustomDomain_MultiItemServiceMode_PerItemDomains(t *testing.T) {
	s := setupCustomDomain(t)
	leaseUUID := s.createMultiItemLease(t)

	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "web", "web.example.com")
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "db", "db.example.com")
	require.NoError(t, err)

	got, serviceName, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "web.example.com")
	require.NoError(t, err)
	require.True(t, has)
	require.Equal(t, leaseUUID, got.Uuid)
	require.Equal(t, "web", serviceName)

	got, serviceName, has, err = s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "db.example.com")
	require.NoError(t, err)
	require.True(t, has)
	require.Equal(t, leaseUUID, got.Uuid)
	require.Equal(t, "db", serviceName)

	// Lease record carries both per-item domains.
	lease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUID)
	require.NoError(t, err)
	domainsByService := map[string]string{}
	for _, item := range lease.Items {
		domainsByService[item.ServiceName] = item.CustomDomain
	}
	require.Equal(t, "web.example.com", domainsByService["web"])
	require.Equal(t, "db.example.com", domainsByService["db"])
}

func TestSetItemCustomDomain_MultiItemServiceMode_NonMatchingServiceName(t *testing.T) {
	s := setupCustomDomain(t)
	leaseUUID := s.createMultiItemLease(t)

	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "missing", "x.example.com")
	require.Error(t, err)
	require.ErrorIs(t, err, types.ErrLeaseItemNotFound)

	// Empty service_name must NOT match in service-mode multi-item lease (no
	// items have empty service_name).
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "", "x.example.com")
	require.Error(t, err)
	require.ErrorIs(t, err, types.ErrLeaseItemNotFound)
}

func TestSetItemCustomDomain_MultiItemLegacy_AmbiguousLookup(t *testing.T) {
	s := setupCustomDomain(t)
	leaseUUID, _ := s.createMultiItemLegacyLease(t)

	// Empty service_name matches both items → ambiguous, rejected.
	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "", "x.example.com")
	require.Error(t, err)
	require.ErrorIs(t, err, types.ErrAmbiguousLeaseItem)
}

func TestSetItemCustomDomain_PreFlightUniqueness(t *testing.T) {
	s := setupCustomDomain(t)
	leaseUUID := s.createMultiItemLease(t)

	// Claim web → some.example.com.
	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "web", "some.example.com")
	require.NoError(t, err)

	t.Run("idempotent re-set on same item", func(t *testing.T) {
		_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "web", "some.example.com")
		require.NoError(t, err)
	})

	t.Run("same lease different item → claimed by another item", func(t *testing.T) {
		_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "db", "some.example.com")
		require.Error(t, err)
		require.ErrorIs(t, err, types.ErrCustomDomainAlreadyClaimed)
		require.Contains(t, err.Error(), `item "web" on this lease`, "error must identify the conflicting sibling item")
	})

	t.Run("different lease → claimed by other lease", func(t *testing.T) {
		// Need another tenant with credit + a lease — use the default 1-item lease.
		_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "some.example.com")
		require.Error(t, err)
		require.ErrorIs(t, err, types.ErrCustomDomainAlreadyClaimed)
	})
}

func TestSetItemCustomDomain_RenameWithinItem(t *testing.T) {
	s := setupCustomDomain(t)
	leaseUUID := s.createMultiItemLease(t)

	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "web", "old.example.com")
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "web", "new.example.com")
	require.NoError(t, err)

	_, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "old.example.com")
	require.NoError(t, err)
	require.False(t, has, "old domain must be released on rename")

	got, serviceName, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "new.example.com")
	require.NoError(t, err)
	require.True(t, has)
	require.Equal(t, leaseUUID, got.Uuid)
	require.Equal(t, "web", serviceName)
}

func TestSetItemCustomDomain_ClearOneItemLeavesSiblingsIntact(t *testing.T) {
	s := setupCustomDomain(t)
	leaseUUID := s.createMultiItemLease(t)

	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "web", "web.example.com")
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "db", "db.example.com")
	require.NoError(t, err)

	// Clear only web's domain.
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "web", "")
	require.NoError(t, err)

	_, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "web.example.com")
	require.NoError(t, err)
	require.False(t, has)

	got, serviceName, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "db.example.com")
	require.NoError(t, err)
	require.True(t, has)
	require.Equal(t, leaseUUID, got.Uuid)
	require.Equal(t, "db", serviceName)
}

func TestSetItemCustomDomain_AcknowledgePreservesMultiItemIndex(t *testing.T) {
	s := setupCustomDomain(t)

	// Create a fresh PENDING multi-item lease (the helper acknowledges, so
	// build it manually here to keep PENDING state).
	pendingResp, err := s.msgServer.CreateLease(s.f.Ctx, &types.MsgCreateLease{
		Tenant: s.tenant.String(),
		Items: []types.LeaseItemInput{
			{SkuUuid: s.sku.Uuid, Quantity: 1, ServiceName: "web"},
			{SkuUuid: s.sku.Uuid, Quantity: 1, ServiceName: "db"},
		},
	})
	require.NoError(t, err)

	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), pendingResp.LeaseUuid, "web", "web.example.com")
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), pendingResp.LeaseUuid, "db", "db.example.com")
	require.NoError(t, err)

	// Acknowledge → PENDING → ACTIVE flips through SetLease and reconcile.
	_, err = s.msgServer.AcknowledgeLease(s.f.Ctx, &types.MsgAcknowledgeLease{
		Sender:     s.providerAddr.String(),
		LeaseUuids: []string{pendingResp.LeaseUuid},
	})
	require.NoError(t, err)

	for _, dom := range []string{"web.example.com", "db.example.com"} {
		got, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, dom)
		require.NoError(t, err)
		require.True(t, has, "index entry must persist for %s across acknowledge", dom)
		require.Equal(t, pendingResp.LeaseUuid, got.Uuid)
	}
}

func TestSetItemCustomDomain_LifecycleCleanupWalksAllItems(t *testing.T) {
	s := setupCustomDomain(t)
	leaseUUID := s.createMultiItemLease(t)

	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "web", "web.example.com")
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "db", "db.example.com")
	require.NoError(t, err)

	_, err = s.msgServer.CloseLease(s.f.Ctx, &types.MsgCloseLease{
		Sender:     s.tenant.String(),
		LeaseUuids: []string{leaseUUID},
	})
	require.NoError(t, err)

	for _, dom := range []string{"web.example.com", "db.example.com"} {
		_, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, dom)
		require.NoError(t, err)
		require.False(t, has, "index entry for %s must be released on close", dom)
	}

	// Lease record preserves CustomDomain on each item for audit.
	closed, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_CLOSED, closed.State)
	domainsByService := map[string]string{}
	for _, item := range closed.Items {
		domainsByService[item.ServiceName] = item.CustomDomain
	}
	require.Equal(t, "web.example.com", domainsByService["web"])
	require.Equal(t, "db.example.com", domainsByService["db"])
}

func TestSetItemCustomDomain_LifecycleCleanup_Cancel(t *testing.T) {
	s := setupCustomDomain(t)
	pendingResp, err := s.msgServer.CreateLease(s.f.Ctx, &types.MsgCreateLease{
		Tenant: s.tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: s.sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), pendingResp.LeaseUuid, "", "cancel.example.com")
	require.NoError(t, err)

	_, err = s.msgServer.CancelLease(s.f.Ctx, &types.MsgCancelLease{
		Tenant:     s.tenant.String(),
		LeaseUuids: []string{pendingResp.LeaseUuid},
	})
	require.NoError(t, err)

	_, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "cancel.example.com")
	require.NoError(t, err)
	require.False(t, has)
}

func TestSetItemCustomDomain_LifecycleCleanup_Reject(t *testing.T) {
	s := setupCustomDomain(t)
	pendingResp, err := s.msgServer.CreateLease(s.f.Ctx, &types.MsgCreateLease{
		Tenant: s.tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: s.sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), pendingResp.LeaseUuid, "", "reject.example.com")
	require.NoError(t, err)

	_, err = s.msgServer.RejectLease(s.f.Ctx, &types.MsgRejectLease{
		Sender:     s.providerAddr.String(),
		LeaseUuids: []string{pendingResp.LeaseUuid},
	})
	require.NoError(t, err)

	_, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "reject.example.com")
	require.NoError(t, err)
	require.False(t, has)
}

func TestSetItemCustomDomain_LifecycleCleanup_AutoCloseLease(t *testing.T) {
	s := setupCustomDomain(t)

	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "auto.example.com")
	require.NoError(t, err)

	s.f.Ctx = s.f.Ctx.WithBlockTime(s.f.Ctx.BlockTime().Add(200_000_000 * time.Second))

	lease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.leaseUUID)
	require.NoError(t, err)
	creditAccount := s.f.creditAccountForLease(t, &lease)
	shouldClose, closeTime, err := s.f.App.BillingKeeper.ShouldAutoCloseLease(s.f.Ctx, &lease, creditAccount)
	require.NoError(t, err)
	require.True(t, shouldClose)

	_, err = s.f.App.BillingKeeper.AutoCloseLease(s.f.Ctx, &lease, creditAccount, closeTime)
	require.NoError(t, err)

	_, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "auto.example.com")
	require.NoError(t, err)
	require.False(t, has, "index entry must be removed on auto-close")
}

func TestSetItemCustomDomain_LifecycleCleanup_EndBlockerExpiry(t *testing.T) {
	s := setupCustomDomain(t)

	params, err := s.f.App.BillingKeeper.GetParams(s.f.Ctx)
	require.NoError(t, err)
	params.PendingTimeout = 60
	require.NoError(t, s.f.App.BillingKeeper.SetParams(s.f.Ctx, params))

	pendingResp, err := s.msgServer.CreateLease(s.f.Ctx, &types.MsgCreateLease{
		Tenant: s.tenant.String(),
		Items:  []types.LeaseItemInput{{SkuUuid: s.sku.Uuid, Quantity: 1}},
	})
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), pendingResp.LeaseUuid, "", "expire.example.com")
	require.NoError(t, err)

	s.f.Ctx = s.f.Ctx.WithBlockTime(s.f.Ctx.BlockTime().Add(61 * time.Second))
	require.NoError(t, s.f.App.BillingKeeper.EndBlocker(s.f.Ctx))

	expired, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, pendingResp.LeaseUuid)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_EXPIRED, expired.State)

	_, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "expire.example.com")
	require.NoError(t, err)
	require.False(t, has)
}

// --- genesis ---

func TestInitGenesis_RebuildsCustomDomainIndex(t *testing.T) {
	f := initFixture(t)
	provider := f.createTestProvider(t, f.TestAccs[1].String(), f.TestAccs[2].String())
	sku := f.createTestSKU(t, provider.Uuid, 100)
	tenant := f.TestAccs[0]

	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(testDenom, sdkmath.NewInt(1_000_000))))

	now := f.Ctx.BlockTime()
	gs := &types.GenesisState{
		Params: types.DefaultParams(),
		Leases: []types.Lease{{
			Uuid:         "01912345-6789-7abc-8def-aaaaaaaaaaa1",
			Tenant:       tenant.String(),
			ProviderUuid: provider.Uuid,
			Items: []types.LeaseItem{
				{SkuUuid: sku.Uuid, Quantity: 1, LockedPrice: sdk.NewCoin(testDenom, sdkmath.NewInt(1)), ServiceName: "web", CustomDomain: "web.example.com"},
				{SkuUuid: sku.Uuid, Quantity: 1, LockedPrice: sdk.NewCoin(testDenom, sdkmath.NewInt(1)), ServiceName: "db"},
			},
			State:                      types.LEASE_STATE_PENDING,
			CreatedAt:                  now,
			LastSettledAt:              now,
			MinLeaseDurationAtCreation: 3600,
		}},
		CreditAccounts: []types.CreditAccount{
			{
				Tenant:            tenant.String(),
				CreditAddress:     creditAddr.String(),
				PendingLeaseCount: 1,
				ReservedAmounts:   sdk.NewCoins(sdk.NewCoin(testDenom, sdkmath.NewInt(7_200))),
			},
		},
		LeaseSequence: 1,
	}

	require.NoError(t, f.App.BillingKeeper.InitGenesis(f.Ctx, gs))

	got, serviceName, has, err := f.App.BillingKeeper.GetLeaseByCustomDomain(f.Ctx, "web.example.com")
	require.NoError(t, err)
	require.True(t, has)
	require.Equal(t, "01912345-6789-7abc-8def-aaaaaaaaaaa1", got.Uuid)
	require.Equal(t, "web", serviceName)
}

// TestInitGenesis_RebuildsExistingDomainMatchingNewReservedSuffix verifies that
// an exported domain claim remains importable after governance reserves its
// suffix. Reserved suffixes gate new claims; they do not retroactively remove
// existing domains.
func TestInitGenesis_RebuildsExistingDomainMatchingNewReservedSuffix(t *testing.T) {
	f := initFixture(t)
	provider := f.createTestProvider(t, f.TestAccs[1].String(), f.TestAccs[2].String())
	sku := f.createTestSKU(t, provider.Uuid, 100)
	tenant := f.TestAccs[0]

	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(testDenom, sdkmath.NewInt(1_000_000))))

	const domain = "web.legacy.example"
	params := types.DefaultParams()
	params.ReservedDomainSuffixes = []string{".legacy.example"}
	now := f.Ctx.BlockTime()
	lease := types.Lease{
		Uuid:         "01912345-6789-7abc-8def-aaaaaaaaaaa2",
		Tenant:       tenant.String(),
		ProviderUuid: provider.Uuid,
		Items: []types.LeaseItem{{
			SkuUuid:      sku.Uuid,
			Quantity:     1,
			LockedPrice:  sdk.NewCoin(testDenom, sdkmath.NewInt(1)),
			ServiceName:  "web",
			CustomDomain: domain,
		}},
		State:                      types.LEASE_STATE_PENDING,
		CreatedAt:                  now,
		LastSettledAt:              now,
		MinLeaseDurationAtCreation: params.MinLeaseDuration,
	}
	reservation := calculateLeaseReservation(t, lease.Items, lease.MinLeaseDurationAtCreation)
	genesisState := &types.GenesisState{
		Params: params,
		Leases: []types.Lease{lease},
		CreditAccounts: []types.CreditAccount{{
			Tenant:            tenant.String(),
			CreditAddress:     creditAddr.String(),
			PendingLeaseCount: 1,
			ReservedAmounts:   reservation,
		}},
		LeaseSequence: 1,
	}

	// Strict validation applies the current claim-time suffix policy and rejects
	// the export even though this domain was valid when originally claimed.
	require.ErrorIs(t, genesisState.ValidateStrict(), types.ErrInvalidCustomDomain)
	require.NoError(t, genesisState.Validate())
	require.NoError(t, genesisState.ValidateWithBlockTime(now))

	require.NoError(t, f.App.BillingKeeper.InitGenesis(f.Ctx, genesisState))

	got, serviceName, has, err := f.App.BillingKeeper.GetLeaseByCustomDomain(f.Ctx, domain)
	require.NoError(t, err)
	require.True(t, has)
	require.Equal(t, lease.Uuid, got.Uuid)
	require.Equal(t, "web", serviceName)
}

func TestInitGenesis_DuplicateCustomDomainFails(t *testing.T) {
	f := initFixture(t)
	beforeParams := types.DefaultParams()
	beforeParams.MaxLeasesPerTenant++
	require.NoError(t, f.App.BillingKeeper.SetParams(f.Ctx, beforeParams))

	provider := f.createTestProvider(t, f.TestAccs[1].String(), f.TestAccs[2].String())
	sku := f.createTestSKU(t, provider.Uuid, 100)
	tenant := f.TestAccs[0]

	creditAddr, err := types.DeriveCreditAddressFromBech32(tenant.String())
	require.NoError(t, err)
	f.fundAccount(t, creditAddr, sdk.NewCoins(sdk.NewCoin(testDenom, sdkmath.NewInt(1_000_000))))

	now := f.Ctx.BlockTime()
	mkLease := func(uuid string) types.Lease {
		return types.Lease{
			Uuid:         uuid,
			Tenant:       tenant.String(),
			ProviderUuid: provider.Uuid,
			Items: []types.LeaseItem{
				{SkuUuid: sku.Uuid, Quantity: 1, LockedPrice: sdk.NewCoin(testDenom, sdkmath.NewInt(1)), CustomDomain: "dup.example.com"},
			},
			State:                      types.LEASE_STATE_PENDING,
			CreatedAt:                  now,
			LastSettledAt:              now,
			MinLeaseDurationAtCreation: 3600,
		}
	}
	gs := &types.GenesisState{
		Params: types.DefaultParams(),
		Leases: []types.Lease{
			mkLease("01912345-6789-7abc-8def-bbbbbbbbbbb1"),
			mkLease("01912345-6789-7abc-8def-bbbbbbbbbbb2"),
		},
		CreditAccounts: []types.CreditAccount{
			{
				Tenant:            tenant.String(),
				CreditAddress:     creditAddr.String(),
				PendingLeaseCount: 2,
				ReservedAmounts:   sdk.NewCoins(sdk.NewCoin(testDenom, sdkmath.NewInt(7_200))),
			},
		},
		LeaseSequence: 2,
	}

	err = f.App.BillingKeeper.InitGenesis(f.Ctx, gs)
	require.Error(t, err)
	require.ErrorIs(t, err, types.ErrCustomDomainAlreadyClaimed)

	// Duplicate live claims are rejected by the read-only genesis preflight,
	// before Params, primary leases, or derived indexes are written.
	afterParams, getErr := f.App.BillingKeeper.GetParams(f.Ctx)
	require.NoError(t, getErr)
	require.Equal(t, beforeParams, afterParams)
	leasingState, getErr := f.App.BillingKeeper.GetAllLeases(f.Ctx)
	require.NoError(t, getErr)
	require.Empty(t, leasingState)
	creditAccounts, getErr := f.App.BillingKeeper.GetAllCreditAccounts(f.Ctx)
	require.NoError(t, getErr)
	require.Empty(t, creditAccounts)
	_, _, has, getErr := f.App.BillingKeeper.GetLeaseByCustomDomain(f.Ctx, "dup.example.com")
	require.NoError(t, getErr)
	require.False(t, has)
}

// TestMigrate1to2 verifies the v1→v2 migration is a true no-op: it must not
// touch Params.ReservedDomainSuffixes regardless of the pre-migration value.
// Operators seed the list at upgrade time or via post-upgrade MsgUpdateParams.
func TestMigrate1to2(t *testing.T) {
	f := initFixture(t)

	// Empty starting state stays empty.
	require.NoError(t, f.App.BillingKeeper.SetParams(f.Ctx, types.DefaultParams()))
	require.NoError(t, keeper.NewMigrator(f.App.BillingKeeper).Migrate1to2(f.Ctx))
	params, err := f.App.BillingKeeper.GetParams(f.Ctx)
	require.NoError(t, err)
	require.Empty(t, params.ReservedDomainSuffixes, "migration must not seed defaults")

	// Pre-existing operator values are preserved unchanged.
	custom := []string{".operator.zone"}
	params.ReservedDomainSuffixes = custom
	require.NoError(t, f.App.BillingKeeper.SetParams(f.Ctx, params))
	require.NoError(t, keeper.NewMigrator(f.App.BillingKeeper).Migrate1to2(f.Ctx))
	params, err = f.App.BillingKeeper.GetParams(f.Ctx)
	require.NoError(t, err)
	require.Equal(t, custom, params.ReservedDomainSuffixes)
}

// --- direct SetLease coverage (defence-in-depth and reconcile edges) ---

// TestSetLease_StorageLevelUniquenessRejection exercises the storage-level
// ErrCustomDomainAlreadyClaimed branch inside reconcileCustomDomainIndex via a
// direct SetLease call (bypassing SetItemCustomDomain's pre-flight). This
// branch is otherwise reachable only through genesis import.
func TestSetLease_StorageLevelUniquenessRejection(t *testing.T) {
	s := setupCustomDomain(t)

	// First lease (the fixture's 1-item legacy lease) claims a domain via the
	// supported path.
	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "shared.example.com")
	require.NoError(t, err)

	// Build a second multi-item lease and try to set the same domain on its
	// "web" item via direct SetLease. The pre-flight check in
	// SetItemCustomDomain would catch this; we deliberately bypass it.
	secondUUID := s.createMultiItemLease(t)
	leaseBeforeAttempt, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, secondUUID)
	require.NoError(t, err)
	mutated := leaseBeforeAttempt
	mutated.Items = append([]types.LeaseItem(nil), leaseBeforeAttempt.Items...)
	for i := range mutated.Items {
		if mutated.Items[i].ServiceName == serviceWeb {
			mutated.Items[i].CustomDomain = "shared.example.com"
		}
	}

	err = s.f.App.BillingKeeper.SetLease(s.f.Ctx, mutated)
	require.Error(t, err)
	require.ErrorIs(t, err, types.ErrCustomDomainAlreadyClaimed)
	require.Contains(t, err.Error(), s.leaseUUID, "error must identify the conflicting lease")

	// SetLease is atomic — the failed write must not have mutated the lease
	// record. The second lease's items should still have empty CustomDomain.
	leaseAfterAttempt, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, secondUUID)
	require.NoError(t, err)
	require.Equal(t, leaseBeforeAttempt, leaseAfterAttempt, "rejected SetLease must not mutate the lease record")
}

// TestSetLease_StorageLevelUniqueness_SameLeaseCrossItem exercises the new
// "same lease different item" branch in reconcileCustomDomainIndex, which
// must produce a more helpful error than the generic cross-lease form.
func TestSetLease_StorageLevelUniqueness_SameLeaseCrossItem(t *testing.T) {
	s := setupCustomDomain(t)
	leaseUUID := s.createMultiItemLease(t)

	// Set web → some.example.com via the supported path.
	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "web", "some.example.com")
	require.NoError(t, err)

	// Mutate the lease so db ALSO carries some.example.com (web still has it).
	// Direct SetLease bypasses the pre-flight; reconcile must reject with the
	// "this lease, item X" message rather than "lease Y item X".
	leaseBeforeAttempt, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUID)
	require.NoError(t, err)
	mutated := leaseBeforeAttempt
	mutated.Items = append([]types.LeaseItem(nil), leaseBeforeAttempt.Items...)
	for i := range mutated.Items {
		if mutated.Items[i].ServiceName == serviceDB {
			mutated.Items[i].CustomDomain = "some.example.com"
		}
	}
	err = s.f.App.BillingKeeper.SetLease(s.f.Ctx, mutated)
	require.Error(t, err)
	require.ErrorIs(t, err, types.ErrCustomDomainAlreadyClaimed)
	require.Contains(t, err.Error(), "on this lease", "must use the same-lease error variant")

	// Atomicity: the rejected SetLease must not have mutated the lease record.
	// The "db" item must still carry its empty CustomDomain.
	leaseAfterAttempt, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUID)
	require.NoError(t, err)
	require.Equal(t, leaseBeforeAttempt, leaseAfterAttempt, "rejected SetLease must not mutate the lease record")
}

// leaseClaimingDomains builds a fresh multi-item lease and returns it with the
// given domains pinned onto its db and web items, WITHOUT writing it. Passing
// the result to SetLease directly bypasses the pre-flight uniqueness check in
// SetItemCustomDomain, which is what lets these tests reach the storage-level
// check inside reconcileCustomDomainIndex.
func (s *customDomainSetup) leaseClaimingDomains(t *testing.T, dbDomain, webDomain string) types.Lease {
	t.Helper()
	lease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.createMultiItemLease(t))
	require.NoError(t, err)
	for i := range lease.Items {
		switch lease.Items[i].ServiceName {
		case serviceDB:
			lease.Items[i].CustomDomain = dbDomain
		case serviceWeb:
			lease.Items[i].CustomDomain = webDomain
		}
	}
	return lease
}

// replayRejectedSetLease calls SetLease n times on a lease expected to be
// rejected, metering each attempt separately, and returns the distinct
// GasConsumed readings and distinct error strings observed.
//
// Go randomises map iteration order per range statement, so replaying the same
// write in one process is what surfaces order-dependence. SetLease is atomic —
// a rejected attempt discards its cache context — so every attempt starts from
// identical state and the readings are directly comparable. Gas, however, is
// metered on the parent context and is NOT rolled back, which is exactly why
// order-dependent gas on a failing tx is consensus-critical.
func replayRejectedSetLease(t *testing.T, s *customDomainSetup, lease types.Lease, n int) (map[uint64]int, map[string]int) {
	t.Helper()
	gasSeen := map[uint64]int{}
	errSeen := map[string]int{}
	for range n {
		meter := storetypes.NewGasMeter(500_000_000)
		err := s.f.App.BillingKeeper.SetLease(s.f.Ctx.WithGasMeter(meter), lease)
		require.ErrorIs(t, err, types.ErrCustomDomainAlreadyClaimed)
		gasSeen[meter.GasConsumed()]++
		errSeen[err.Error()]++
	}
	return gasSeen, errSeen
}

// TestSetLease_FreeAndConflictingDomain_DeterministicGas is the direct ENG-645
// regression. A single SetLease carries one free domain and one already-claimed
// domain. Ranging over the map, the install loop either did Get→Set→Get before
// returning (free domain visited first) or just Get (conflict visited first) —
// the same rejected tx charging different gas on different validators. Since
// CometBFT hashes GasUsed into LastResultsHash, that is an apphash divergence.
// Sorted iteration fixes the order, so GasConsumed must be single-valued.
func TestSetLease_FreeAndConflictingDomain_DeterministicGas(t *testing.T) {
	s := setupCustomDomain(t)

	// The holder parks web's domain only; db's stays unclaimed.
	holderUUID := s.createMultiItemLease(t)
	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), holderUUID, serviceWeb, "w.example.com")
	require.NoError(t, err)

	victim := s.leaseClaimingDomains(t, "free.example.com", "w.example.com")

	gasSeen, errSeen := replayRejectedSetLease(t, s, victim, 100)
	require.Len(t, gasSeen, 1, "GasUsed on a rejected write must not depend on map iteration order, saw %v", gasSeen)
	require.Len(t, errSeen, 1, "the reported conflict must be stable, saw %v", errSeen)

	// Sorted order visits db (free) before web (conflicting), so the reported
	// conflict is always web's domain.
	for msg := range errSeen {
		require.Contains(t, msg, "w.example.com")
	}

	// The free domain must never survive a rejected write.
	_, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "free.example.com")
	require.NoError(t, err)
	require.False(t, has, "rejected SetLease must not leak the free domain into the index")
}

// TestSetLease_ConflictingDomains_DeterministicRejection covers the two-conflict
// case, where both loops trip on their first entry so the op COUNT is the same
// either way. Gas still diverged pre-fix, because a read is charged per byte and
// the two index values differ in length (service_name "db" vs "web"), and the
// reported conflict flipped between the two domains. Sorted iteration pins both:
// the lowest-sorted service ("db") is always the one reported.
func TestSetLease_ConflictingDomains_DeterministicRejection(t *testing.T) {
	s := setupCustomDomain(t)

	// A holder lease parks both domains via the supported path.
	holderUUID := s.createMultiItemLease(t)
	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), holderUUID, serviceDB, "d.example.com")
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), holderUUID, serviceWeb, "w.example.com")
	require.NoError(t, err)

	victim := s.leaseClaimingDomains(t, "d.example.com", "w.example.com")

	gasSeen, errSeen := replayRejectedSetLease(t, s, victim, 100)
	require.Len(t, gasSeen, 1, "GasUsed on a rejected write must not depend on map iteration order, saw %v", gasSeen)
	require.Len(t, errSeen, 1, "the reported conflict must be stable, saw %v", errSeen)

	for msg := range errSeen {
		require.Contains(t, msg, "d.example.com", "reconcile must always trip on the lowest-sorted service (db)")
		require.NotContains(t, msg, "w.example.com", "web must never be the reported conflict")
	}
}

// TestSetLease_CrossSwap covers a single SetLease call that swaps domains
// between two items: web's previous value moves to db, and web takes a new
// value. The reconcile must release web's old entry before installing it on
// db, otherwise the install would observe its own previous value and fail
// uniqueness.
func TestSetLease_CrossSwap(t *testing.T) {
	s := setupCustomDomain(t)
	leaseUUID := s.createMultiItemLease(t)

	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "web", "a.example.com")
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "db", "b.example.com")
	require.NoError(t, err)

	// Swap: web now carries b.example.com (db's old value), db carries
	// c.example.com (new). Direct SetLease so both moves land in one reconcile.
	lease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUID)
	require.NoError(t, err)
	for i := range lease.Items {
		switch lease.Items[i].ServiceName {
		case serviceWeb:
			lease.Items[i].CustomDomain = "b.example.com"
		case serviceDB:
			lease.Items[i].CustomDomain = "c.example.com"
		}
	}
	require.NoError(t, s.f.App.BillingKeeper.SetLease(s.f.Ctx, lease))

	// Reverse-lookup confirms the new shape.
	got, serviceName, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "b.example.com")
	require.NoError(t, err)
	require.True(t, has)
	require.Equal(t, leaseUUID, got.Uuid)
	require.Equal(t, "web", serviceName, "b.example.com must now belong to web")

	got, serviceName, has, err = s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "c.example.com")
	require.NoError(t, err)
	require.True(t, has)
	require.Equal(t, leaseUUID, got.Uuid)
	require.Equal(t, "db", serviceName)

	// a.example.com (web's pre-swap domain) is gone.
	_, _, has, err = s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "a.example.com")
	require.NoError(t, err)
	require.False(t, has, "a.example.com must be released after web's domain changed")
}

// --- event attribute coverage ---

// findEvent returns the most recent event with the given type from the
// fixture's event manager, or fails the test if not found.
func findEvent(t *testing.T, ctx sdk.Context, eventType string) sdk.Event {
	t.Helper()
	events := ctx.EventManager().Events()
	for i := len(events) - 1; i >= 0; i-- {
		if events[i].Type == eventType {
			return events[i]
		}
	}
	t.Fatalf("event %q not found among %d emitted events", eventType, len(events))
	return sdk.Event{}
}

// attrValue returns the value of the named attribute from an event, or fails.
func attrValue(t *testing.T, ev sdk.Event, key string) string {
	t.Helper()
	for _, a := range ev.Attributes {
		if a.Key == key {
			return a.Value
		}
	}
	t.Fatalf("attribute %q not found on event %q", key, ev.Type)
	return ""
}

func TestSetItemCustomDomain_SetEvent_Attributes_Legacy(t *testing.T) {
	s := setupCustomDomain(t)

	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "evt.example.com")
	require.NoError(t, err)

	ev := findEvent(t, s.f.Ctx, types.EventTypeLeaseCustomDomainSet)
	require.Equal(t, s.leaseUUID, attrValue(t, ev, types.AttributeKeyLeaseUUID))
	require.Equal(t, s.tenant.String(), attrValue(t, ev, types.AttributeKeyTenant))
	require.Equal(t, s.provider.Uuid, attrValue(t, ev, types.AttributeKeyProviderUUID))
	require.Equal(t, "", attrValue(t, ev, types.AttributeKeyServiceName), "1-item legacy emits empty service_name")
	require.Equal(t, "evt.example.com", attrValue(t, ev, types.AttributeKeyCustomDomain))
	require.Equal(t, types.AttributeValueRoleTenant, attrValue(t, ev, types.AttributeKeySetBy))
}

func TestSetItemCustomDomain_SetEvent_Attributes_MultiItem(t *testing.T) {
	s := setupCustomDomain(t)
	leaseUUID := s.createMultiItemLease(t)

	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.f.Authority.String(), leaseUUID, "web", "evt.example.com")
	require.NoError(t, err)

	ev := findEvent(t, s.f.Ctx, types.EventTypeLeaseCustomDomainSet)
	require.Equal(t, leaseUUID, attrValue(t, ev, types.AttributeKeyLeaseUUID))
	lease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUID)
	require.NoError(t, err)
	require.Equal(t, lease.ProviderUuid, attrValue(t, ev, types.AttributeKeyProviderUUID))
	require.Equal(t, "web", attrValue(t, ev, types.AttributeKeyServiceName))
	require.Equal(t, "evt.example.com", attrValue(t, ev, types.AttributeKeyCustomDomain))
	require.Equal(t, types.AttributeValueRoleAuthority, attrValue(t, ev, types.AttributeKeySetBy), "authority sender attribution")
}

func TestSetItemCustomDomain_ClearEvent_Attributes(t *testing.T) {
	s := setupCustomDomain(t)
	leaseUUID := s.createMultiItemLease(t)

	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "web", "to-clear.example.com")
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseUUID, "web", "")
	require.NoError(t, err)

	ev := findEvent(t, s.f.Ctx, types.EventTypeLeaseCustomDomainCleared)
	require.Equal(t, leaseUUID, attrValue(t, ev, types.AttributeKeyLeaseUUID))
	lease, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, leaseUUID)
	require.NoError(t, err)
	require.Equal(t, lease.ProviderUuid, attrValue(t, ev, types.AttributeKeyProviderUUID))
	require.Equal(t, "web", attrValue(t, ev, types.AttributeKeyServiceName))
	require.Equal(t, "to-clear.example.com", attrValue(t, ev, types.AttributeKeyCustomDomain),
		"cleared event reports the previous domain for audit consumers")
	require.Equal(t, types.AttributeValueRoleTenant, attrValue(t, ev, types.AttributeKeySetBy))
}

// --- multi-item lifecycle cleanup beyond Close ---

func TestSetItemCustomDomain_LifecycleCleanup_MultiItem_Cancel(t *testing.T) {
	s := setupCustomDomain(t)

	pendingResp, err := s.msgServer.CreateLease(s.f.Ctx, &types.MsgCreateLease{
		Tenant: s.tenant.String(),
		Items: []types.LeaseItemInput{
			{SkuUuid: s.sku.Uuid, Quantity: 1, ServiceName: "web"},
			{SkuUuid: s.sku.Uuid, Quantity: 1, ServiceName: "db"},
		},
	})
	require.NoError(t, err)

	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), pendingResp.LeaseUuid, "web", "cancel-web.example.com")
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), pendingResp.LeaseUuid, "db", "cancel-db.example.com")
	require.NoError(t, err)

	_, err = s.msgServer.CancelLease(s.f.Ctx, &types.MsgCancelLease{
		Tenant:     s.tenant.String(),
		LeaseUuids: []string{pendingResp.LeaseUuid},
	})
	require.NoError(t, err)

	for _, dom := range []string{"cancel-web.example.com", "cancel-db.example.com"} {
		_, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, dom)
		require.NoError(t, err)
		require.False(t, has, "all per-item index entries must release on cancel; %q still resolved", dom)
	}
}

func TestSetItemCustomDomain_LifecycleCleanup_MultiItem_Reject(t *testing.T) {
	s := setupCustomDomain(t)

	pendingResp, err := s.msgServer.CreateLease(s.f.Ctx, &types.MsgCreateLease{
		Tenant: s.tenant.String(),
		Items: []types.LeaseItemInput{
			{SkuUuid: s.sku.Uuid, Quantity: 1, ServiceName: "web"},
			{SkuUuid: s.sku.Uuid, Quantity: 1, ServiceName: "db"},
		},
	})
	require.NoError(t, err)

	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), pendingResp.LeaseUuid, "web", "reject-web.example.com")
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), pendingResp.LeaseUuid, "db", "reject-db.example.com")
	require.NoError(t, err)

	_, err = s.msgServer.RejectLease(s.f.Ctx, &types.MsgRejectLease{
		Sender:     s.providerAddr.String(),
		LeaseUuids: []string{pendingResp.LeaseUuid},
	})
	require.NoError(t, err)

	for _, dom := range []string{"reject-web.example.com", "reject-db.example.com"} {
		_, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, dom)
		require.NoError(t, err)
		require.False(t, has, "all per-item index entries must release on reject; %q still resolved", dom)
	}
}

func TestSetItemCustomDomain_LifecycleCleanup_MultiItem_EndBlockerExpiry(t *testing.T) {
	s := setupCustomDomain(t)

	params, err := s.f.App.BillingKeeper.GetParams(s.f.Ctx)
	require.NoError(t, err)
	params.PendingTimeout = 60
	require.NoError(t, s.f.App.BillingKeeper.SetParams(s.f.Ctx, params))

	pendingResp, err := s.msgServer.CreateLease(s.f.Ctx, &types.MsgCreateLease{
		Tenant: s.tenant.String(),
		Items: []types.LeaseItemInput{
			{SkuUuid: s.sku.Uuid, Quantity: 1, ServiceName: "web"},
			{SkuUuid: s.sku.Uuid, Quantity: 1, ServiceName: "db"},
		},
	})
	require.NoError(t, err)

	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), pendingResp.LeaseUuid, "web", "expire-web.example.com")
	require.NoError(t, err)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), pendingResp.LeaseUuid, "db", "expire-db.example.com")
	require.NoError(t, err)

	s.f.Ctx = s.f.Ctx.WithBlockTime(s.f.Ctx.BlockTime().Add(61 * time.Second))
	require.NoError(t, s.f.App.BillingKeeper.EndBlocker(s.f.Ctx))

	expired, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, pendingResp.LeaseUuid)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_EXPIRED, expired.State)

	for _, dom := range []string{"expire-web.example.com", "expire-db.example.com"} {
		_, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, dom)
		require.NoError(t, err)
		require.False(t, has, "all per-item index entries must release on EndBlocker expiry; %q still resolved", dom)
	}
}

// --- idempotency: no state change + no event for no-op operations ---

// countEvents returns how many events of the given type the context has emitted.
func countEvents(ctx sdk.Context, eventType string) int {
	n := 0
	for _, ev := range ctx.EventManager().Events() {
		if ev.Type == eventType {
			n++
		}
	}
	return n
}

// TestSetItemCustomDomain_IdempotentClear verifies that clearing a domain
// on an item whose CustomDomain is already empty is a true no-op: no SetLease
// write, no Cleared event, no state mutation. Caller still receives the role.
func TestSetItemCustomDomain_IdempotentClear(t *testing.T) {
	s := setupCustomDomain(t)

	leaseBefore, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.leaseUUID)
	require.NoError(t, err)
	require.Empty(t, leaseBefore.Items[0].CustomDomain, "fixture lease starts with no custom_domain")

	clearedBefore := countEvents(s.f.Ctx, types.EventTypeLeaseCustomDomainCleared)

	role, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "")
	require.NoError(t, err)
	require.Equal(t, types.AttributeValueRoleTenant, role, "role still returned for authorisation confirmation")

	// No Cleared event emitted for the no-op.
	require.Equal(t, clearedBefore, countEvents(s.f.Ctx, types.EventTypeLeaseCustomDomainCleared),
		"idempotent clear must not emit a lease_custom_domain_cleared event")

	// Lease record byte-for-byte identical.
	leaseAfter, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.leaseUUID)
	require.NoError(t, err)
	require.Equal(t, leaseBefore, leaseAfter, "idempotent clear must not mutate the lease record")
}

// TestSetItemCustomDomain_IdempotentReSet verifies that re-setting the
// same domain on the same item is a true no-op: no SetLease write, no Set
// event, no state mutation. Caller still receives the role.
func TestSetItemCustomDomain_IdempotentReSet(t *testing.T) {
	s := setupCustomDomain(t)

	// Initial set produces a Set event and a state change.
	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "idem.example.com")
	require.NoError(t, err)

	leaseBefore, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.leaseUUID)
	require.NoError(t, err)
	setBefore := countEvents(s.f.Ctx, types.EventTypeLeaseCustomDomainSet)

	// Re-set with the same domain: no-op.
	role, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "idem.example.com")
	require.NoError(t, err)
	require.Equal(t, types.AttributeValueRoleTenant, role)

	require.Equal(t, setBefore, countEvents(s.f.Ctx, types.EventTypeLeaseCustomDomainSet),
		"idempotent re-set must not emit a lease_custom_domain_set event")

	leaseAfter, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.leaseUUID)
	require.NoError(t, err)
	require.Equal(t, leaseBefore, leaseAfter, "idempotent re-set must not mutate the lease record")

	// Reverse-lookup still resolves correctly.
	got, _, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, "idem.example.com")
	require.NoError(t, err)
	require.True(t, has)
	require.Equal(t, s.leaseUUID, got.Uuid)
}

// TestGetLeaseByCustomDomain_NormalisesInput verifies that the keeper-level
// reverse-lookup function normalises its input (lowercase + trim) so callers
// who skip the msg-server / querier layers (future IBC handlers, internal
// hooks, etc.) get consistent matching with the canonical-form index keys.
func TestGetLeaseByCustomDomain_NormalisesInput(t *testing.T) {
	s := setupCustomDomain(t)
	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", "norm.example.com")
	require.NoError(t, err)

	cases := []string{
		"norm.example.com",
		"NORM.example.com",
		"  norm.example.com  ",
		"\tNorm.Example.COM\n",
	}
	for _, q := range cases {
		t.Run(q, func(t *testing.T) {
			got, serviceName, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, q)
			require.NoError(t, err)
			require.True(t, has, "non-canonical input %q must still match the canonical index entry", q)
			require.Equal(t, s.leaseUUID, got.Uuid)
			require.Equal(t, "", serviceName)
		})
	}
}

// TestQuerier_LeaseByCustomDomain_WhitespaceRejectedAsInvalidArgument verifies
// that whitespace-only requests produce a single InvalidArgument error rather
// than passing the empty check, normalising to "", and returning a misleading
// NotFound for an empty domain.
func TestQuerier_LeaseByCustomDomain_WhitespaceRejectedAsInvalidArgument(t *testing.T) {
	s := setupCustomDomain(t)
	q := keeper.NewQuerier(s.f.App.BillingKeeper)

	cases := []string{"", "   ", "\t", "\n  \t"}
	for _, in := range cases {
		t.Run("input="+in, func(t *testing.T) {
			_, err := q.LeaseByCustomDomain(s.f.Ctx, &types.QueryLeaseByCustomDomainRequest{CustomDomain: in})
			require.Error(t, err)
			require.Equal(t, codes.InvalidArgument, status.Code(err),
				"whitespace-only input must canonicalise to empty and be rejected as InvalidArgument, not NotFound")
		})
	}
}

// TestSetLease_TerminalReconcileDoesNotPoisonAnotherLeasesIndexEntry is a
// regression for a cross-lease index-poisoning bug: terminal-state leases
// preserve LeaseItem.CustomDomain for audit, so a subsequent SetLease on the
// same closed lease (e.g. post-close withdraw settlement) used to fire an
// unconditional Remove against the still-populated prev domain — silently
// deleting whatever lease had legitimately re-claimed that domain in the
// meantime. The fix gates the Remove on an ownership check; this test asserts
// a re-claim by lease B survives a second SetLease on the closed lease A.
func TestSetLease_TerminalReconcileDoesNotPoisonAnotherLeasesIndexEntry(t *testing.T) {
	s := setupCustomDomain(t)
	const sharedDomain = "shared.example.com"

	// Lease A claims the domain.
	_, err := s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), s.leaseUUID, "", sharedDomain)
	require.NoError(t, err)

	// Lease A closes. The first SetLease reconcile correctly removes the
	// index entry; the LeaseItem.CustomDomain field stays populated for audit.
	_, err = s.msgServer.CloseLease(s.f.Ctx, &types.MsgCloseLease{
		Sender:     s.tenant.String(),
		LeaseUuids: []string{s.leaseUUID},
	})
	require.NoError(t, err)
	closedA, err := s.f.App.BillingKeeper.GetLease(s.f.Ctx, s.leaseUUID)
	require.NoError(t, err)
	require.Equal(t, types.LEASE_STATE_CLOSED, closedA.State)
	require.Equal(t, sharedDomain, closedA.Items[0].CustomDomain, "audit field preserved on close")

	// Lease B (different tenant, fresh fixture state) re-claims the now-free
	// domain. We simulate this by creating a second active lease for the same
	// fixture's tenant on a fresh provider/sku — the lease UUID differs.
	leaseB := s.createMultiItemLease(t)
	_, err = s.f.App.BillingKeeper.SetItemCustomDomain(s.f.Ctx, s.tenant.String(), leaseB, "web", sharedDomain)
	require.NoError(t, err)
	got, sn, has, err := s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, sharedDomain)
	require.NoError(t, err)
	require.True(t, has)
	require.Equal(t, leaseB, got.Uuid, "after re-claim, index points at lease B")
	require.Equal(t, "web", sn)

	// Now simulate a post-close settlement on lease A: SetLease is called on
	// the still-CLOSED lease (e.g. withdrawFromLeases updating LastSettledAt
	// after PerformSettlement on the residual accrual between LastSettledAt
	// and ClosedAt). Pre-fix, this would Remove(sharedDomain) unconditionally
	// because closedA.Items[0].CustomDomain is still set and editable=false.
	require.NoError(t, s.f.App.BillingKeeper.SetLease(s.f.Ctx, closedA))

	// The fix asserts: lease B's index entry must survive the spurious
	// reconcile pass on lease A.
	got, sn, has, err = s.f.App.BillingKeeper.GetLeaseByCustomDomain(s.f.Ctx, sharedDomain)
	require.NoError(t, err)
	require.True(t, has, "lease B's index entry must survive a SetLease on the closed lease A")
	require.Equal(t, leaseB, got.Uuid)
	require.Equal(t, "web", sn)
}
