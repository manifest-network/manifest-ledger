# Modules

## Table of Contents

<!-- TOC -->

- [Manifest Module](#manifest-module)
  - [Module Functionality](#module-functionality)
    - [Commands](#commands)
      - [Mint and disburse native tokens (payout):](#mint-and-disburse-native-tokens-payout)
      - [Burn native tokens (burn-coins):](#burn-native-tokens-burn-coins)
- [Proof of Authority Module](#proof-of-authority-module)
  - [Module Functionality](#module-functionality-1)
    - [Validator Management:](#validator-management)
    - [Administrative Rights:](#administrative-rights)
    - [Commands](#commands-1)
      - [Update Staking Parameters (update-staking-params):](#update-staking-parameters-update-staking-params)
      - [Set Voting Power (set-power):](#set-voting-power-set-power)
      - [Remove Pending Validator (remove-pending):](#remove-pending-validator-remove-pending)
      - [Remove Validator (remove):](#remove-validator-remove)
- [Token Factory Module](#token-factory-module)
  - [Module Functionality](#module-functionality-2)
    - [Token Minting:](#token-minting)
    - [Token Burning:](#token-burning)
    - [Token Administration:](#token-administration)
    - [Metadata Management:](#metadata-management)
    - [Commands](#commands-2)
      - [Burn (burn):](#burn-burn)
      - [Burn From (burn-from):](#burn-from-burn-from)
      - [Mint (mint):](#mint-mint)
      - [Change Admin (change-admin):](#change-admin-change-admin)
      - [Create Denom (create-denom):](#create-denom-create-denom)
      - [Force Transfer (force-transfer):](#force-transfer-force-transfer)
      - [Modify Metadata (modify-metadata):](#modify-metadata-modify-metadata)
- [COSM WASM Module](#cosm-wasm-module)
  - [Module Functionality](#module-functionality-3)
    - [Commands](#commands-3)
      - [Upload Contract (upload-contract):](#upload-contract-upload-contract)
      - [Instantiate Contract (instantiate-contract):](#instantiate-contract-instantiate-contract)
      - [Execute Contract (execute-contract):](#execute-contract-execute-contract)
- [SKU Module](#sku-module)
  - [Module Functionality](#module-functionality-4)
    - [Commands](#commands-4)
- [Billing Module](#billing-module)
  - [Module Functionality](#module-functionality-5)
    - [Commands](#commands-5)
      - [Fund Credit (fund-credit)](#fund-credit-fund-credit)
      - [Create Lease (create-lease)](#create-lease-create-lease)
      - [Create Lease For Tenant (create-lease-for-tenant)](#create-lease-for-tenant-create-lease-for-tenant)
      - [Acknowledge Lease (acknowledge-lease)](#acknowledge-lease-acknowledge-lease)
      - [Reject Lease (reject-lease)](#reject-lease-reject-lease)
      - [Cancel Lease (cancel-lease)](#cancel-lease-cancel-lease)
      - [Close Lease (close-lease)](#close-lease-close-lease)
      - [Withdraw (withdraw)](#withdraw-withdraw)
      - [Set Item Custom Domain (set-item-custom-domain)](#set-item-custom-domain-set-item-custom-domain)
      - [Update Params (update-params)](#update-params-update-params-1)

<!-- TOC -->

## Manifest Module

The Manifest module is responsible for handling manual minting and coin burning events. Below is a structured breakdown of its components and functionalities:

### Module Functionality

- Manual Minting: The PoA admin can manually mint and disburse a specified amount of tokens.
- Manual Burning: The PoA admin can manually burn tokens from the PoA admin account.

#### Commands

##### Mint and disburse native tokens (payout):

- Syntax: `manifestd tx manifest payout [address:coin_amount,...]`

  - Parameters:

    - `address:coin_amount`: Pair of destination address and amount of coin to mint.

  **Example:** `manifestd tx manifest payout manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct:777umfx,manifest1efd63aw40lxf3n4mhf7dzhjkr453axurm6rp3z:1000umfx`

##### Burn native tokens (burn-coins):

- Syntax: `manifestd tx manifest burn-coins [coins,...]`

  - Parameters:

    - `coins`: The amount of coins to burn from the POA admin account.

  **Example:** `manifestd tx manifest burn-coins 777umfx,1000othercoin`

## Proof of Authority Module

The PoA module is responsible for handling admin actions like adding and removing other administrators, setting the staking parameters of the chain, controlling voting power, and allowing/blocking validators. Below is a structured breakdown of its components and functionalities:

### Module Functionality

The PoA admin has several capabilities for managing the chain and its validators:

#### Validator Management:

- Remove validators from the active set.
- Remove validators pending addition to the active set.
- Specify the voting power for each validator.
- Approve the addition of new validators.

#### Administrative Rights:

- Assign or revoke administrative privileges.
- Determine if validators have the ability to self-revoke.

#### Commands

##### Update Staking Parameters (update-staking-params):

Updates the defaults of the staking module from the PoA admin. For most cases, this should never be touched when using PoA.

- Syntax: `manifestd tx poa update-staking-params [unbondingTime] [maxVals] [maxEntries] [historicalEntries] [bondDenom] [minCommissionRate]`

  - Parameters:

    - `unbondingTime`: The time period for tokens to move from a bonded to released state. Not applicable for Proof of Authority.
    - `maxVals`: The maximum number of validators in the active set who can sign blocks. Default is 100
    - `maxEntries`: The maximum number of unbonding entries a delegator can have during the unbonding time. Not applicable for Proof of Authority.
    - `historicalEntries`: The number of historical staking entries to account for. Not applicable for Proof of Authority.
    - `bondDenom`: The denomination for bonding and staking. Not applicable for Proof of Authority.
    - `minCommissionRate`: The minimum commission rate for validators to get a percent cut of fees generated. Not applicable for Proof of Authority.

  **Example:** `manifestd tx poa update-staking-params 1814400 100 7 1000 umfx 0.01`

##### Set Voting Power (set-power):

Update a validators vote power weighting in the network. A higher vote power results in more blocks being signed. This also accepts pending validators into the active set as an approval from the PoA admin.

- Syntax: `manifestd tx poa set-power [validator] [power] [--unsafe]`

  - Parameters:

    - `validator`: The validator's operator address.
    - `power`: The voting power to give the validator. This is relative to the total current power of all PoA validators on the network. Uses 10^6 exponent.

    **Example:** `manifestd tx poa set-power manifestvaloper1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct 1000000`

    **NOTE**: A network of 2 validators each with 1_000_000 power will have a total power of 2_000_000. So each have 50% of the network. If one validator increases, then the others network percentage decreases, but remains at the same fixed 1_000_000 power as before.

##### Remove Pending Validator (remove-pending):

In PoA networks, any user (validator) can submit to the chain a transaction to signal intent of becoming a chain validator. Since the PoA admin has the final say on who becomes a validator, they can remove any pending validators from the list who they wish not to add. This command is used to remove a pending validator from the list.

- Syntax: `manifestd tx poa remove-pending [validator]`

  - Parameters:

    - `validator`: The validator's operator address.

    **Example:** `manifestd tx poa remove-pending manifestvaloper1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct`

##### Remove Validator (remove):

If the PoA admin decides they no longer wish for a validator to be signing blocks on the network, they can forcably remove them from the active set for signing blocks. This command removes the validator from signing blocks.

- Syntax: `manifestd tx poa remove [validator]`

  - Parameters:

    - `validator`: The validator's operator address.

    **Example:** `manifestd tx poa remove manifestvaloper1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct`

## Token Factory Module

The Token Factory module as it is implemented on the Manifest Network, allows any user to have granular control over the creation and management of tokens on the Manifest Network. The creator can mint, burn, edit, and force-transfer its denomination, subject to application bank policy. Manifest rejects tokenfactory `BurnFrom` and `ForceTransfer` debits from every registered billing credit address, including unreserved credit. Ordinary wallets retain issuer clawback exposure; funding, minting into credit, and authorized billing payouts continue.

> _note:_ The module is designed to work with tokens created by the module itself.

### Module Functionality

#### Token Minting:

- Create a token with a specific denom
- Mint a token with a specific amount and denom to your account
- Mint a token with a specific amount and denom to another account

#### Token Burning:

- Burn a token with a specific amount and denom from your account
- Burn a token with a specific amount and denom from another account

#### Token Administration:

- Change the admin address for a factory-created denom
- Force transfer tokens from one address to another address

#### Metadata Management:

- Change the base metadata for a factory-created denom

#### Commands

##### Burn (burn):

- Syntax: `manifestd tx token-factory burn [amount]`

  - Parameters:
    - `amount`: The amount and denom of the token you would like to burn from your account.

  **Example:** `manifestd tx tokenfactory burn 1<denom>`

##### Burn From (burn-from):

- Syntax: `manifestd tx token-factory burn-from [address] [amount]`

  - Parameters:
    - `address`: The address of the account you would like to burn the tokens from.
    - `amount`: The amount and denom of the token you would like to burn.

  **Example:** `manifestd tx tokenfactory burn-from manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct 1<denom>`

##### Mint (mint):

- Syntax: `manifestd tx token-factory mint [amount]`

  - Parameters:
    - `amount`: The amount and denom of the token you would like to mint to your account.

  **Example:** `manifestd tx tokenfactory mint 1<denom>`

##### Change Admin (change-admin):

- Syntax: `manifestd tx token-factory change-admin [denom] [new-admin-address]`

  - Parameters:
    - `denom`: The denom of the token that you would like to change the admin for.
    - `new-admin-address`: The new admin's wallet address.

  **Example:** `manifestd tx tokenfactory change-admin <denom> manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct`

##### Create Denom (create-denom):

- Syntax: `manifestd tx token-factory create-denom [subdenom]`

> _note:_ the createor of the denom is the denoms admin.

- Parameters:
  - `subdenom`: The smallest denomination for your token e.g. udenom.

**Example:** `manifestd tx tokenfactory create-denom <subdenom>`

##### Force Transfer (force-transfer):

- Syntax: `manifestd tx token-factory force-transfer  [amount] [transfer-from-address] [transfer-to-address]`

  - Parameters:
    - `amount`: The amount and denom of the token you would like to transfer.
    - `transfer-from-address`: The address of the account you would like to transfer the tokens from.
    - `transfer-to-address`: The address of the account you would like to transfer the tokens to.

  **Example:** `manifestd tx tokenfactory force-transfer 1<denom> manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct`

##### Modify Metadata (modify-metadata):

- Syntax: `manifestd tx token-factory modify-metadata [denom] [ticker-symbol] [description] [exponent]`

  - Parameters:
    - `denom`: The denom of the token you are modifying.
    - `ticker-symbol`: The ticker symbol for the token.
    - `description`: A description of the token.
    - `exponent`: The exponent for the token e.g. how many zeros.

  **Example:** `manifestd tx tokenfactory modify-metadata utoken TOKEN "A token" 6`

## COSM WASM Module

The WASM module is responsible for handling the deployment and execution of WASM contracts on the Manifest Network.

### Module Functionality

The WASM module provides several key functionalities for managing smart contracts:

#### Contract Deployment:

- Upload WASM contract code to the blockchain
- Instantiate contracts with initial parameters
- Support for predictable contract addresses using instantiate2

#### Contract Administration:

- Set and clear contract administrators
- Migrate contracts to new code versions
- Update contract labels and configurations
- Manage instantiation permissions

#### Contract Execution:

- Execute contract functions with custom messages
- Support for contract-to-contract calls
- Handle contract queries and responses

#### Commands

##### Upload Contract (upload-contract):

- Syntax: `manifestd tx wasm store [wasm-file] [flags]`

  - Parameters:
    - `wasm-file`: Path to the .wasm contract file to upload
    - Optional flags for instantiation permissions and access control

  **Example:** `manifestd tx wasm store contract.wasm --from mykey`

##### Instantiate Contract (instantiate-contract):

- Syntax: `manifestd tx wasm instantiate [code-id] [json-encoded-args] --label [text] [flags]`

  - Parameters:
    - `code-id`: The ID of the uploaded contract code
    - `json-encoded-args`: Init message for the contract in JSON format
    - `label`: Human-readable label for the contract instance
    - Optional flags for admin, funds, and other parameters

  **Example:** `manifestd tx wasm instantiate 1 '{"count": 0}' --label "counter" --from mykey`

##### Execute Contract (execute-contract):

- Syntax: `manifestd tx wasm execute [contract-addr] [json-encoded-args] [flags]`

  - Parameters:
    - `contract-addr`: The address of the instantiated contract
    - `json-encoded-args`: Execute message in JSON format
    - Optional flags for sending funds with execution

  **Example:** `manifestd tx wasm execute manifest14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s0phg4d '{"increment":{}}' --from mykey`

## SKU Module

The SKU module manages providers (service entities) and SKUs (Stock Keeping Units - billable items). It provides the foundation for the billing system by defining what can be leased and at what price.

> For detailed documentation, see [x/sku/README.md](./x/sku/README.md) and [x/sku/docs/](./x/sku/docs/).

### Module Functionality

#### Provider Management:

- Create and manage service providers with unique UUIDv7 identifiers
- Configure provider metadata, API URLs, and payout addresses
- Activate/deactivate providers (cascade deactivates associated SKUs)

#### SKU Management:

- Create billable items with per-hour or per-day pricing
- Support multiple denominations for pricing flexibility
- Activate/deactivate SKUs independently

#### Commands

##### Create Provider (create-provider):

- Syntax: `manifestd tx sku create-provider [address] [payout-address] [flags]`

  - Parameters:
    - `address`: The provider's operator address
    - `payout-address`: Address to receive lease payments; protected bank destinations are rejected. The governance (`gov`) module account is the sole module-account receiving exemption.
  - Flags:
    - `--meta-hash`: Hex-encoded hash of off-chain metadata (optional)
    - `--api-url`: Provider's HTTPS API endpoint URL (optional)

  **Example:** `manifestd tx sku create-provider manifest1abc... manifest1xyz... --api-url https://api.provider.com --from authority`

##### Create SKU (create-sku):

- Syntax: `manifestd tx sku create-sku [provider-uuid] [name] [unit] [base-price] [flags]`

  - Parameters:
    - `provider-uuid`: UUID of the provider
    - `name`: Human-readable SKU name
    - `unit`: Pricing unit integer (`1` = per hour, `2` = per day)
    - `base-price`: Price per unit (e.g., `3600upwr` for 1 token/second when hourly)
  - Flags:
    - `--meta-hash`: Hex-encoded hash of off-chain metadata (optional)

  **Example:** `manifestd tx sku create-sku 01912345-6789-7abc-8def-0123456789ab "GPU Instance" 1 3600upwr --meta-hash deadbeef --from authority`

##### Update Provider (update-provider):

- Syntax: `manifestd tx sku update-provider [uuid] [address] [payout-address] [active] [flags]`

  - Parameters:
    - `uuid`: Provider UUID
    - `address`: The provider's operator address
    - `payout-address`: Address to receive lease payments; protected bank destinations are rejected. The governance (`gov`) module account is the sole module-account receiving exemption.
    - `active`: `true` keeps the provider active or reactivates it after its SKU deactivation cascade is complete. `false` preserves an already-inactive provider; use `deactivate-provider` to deactivate an active one.
  - Flags:
    - `--meta-hash`: Hex-encoded hash of off-chain metadata (optional)
    - `--api-url`: New HTTPS API endpoint URL; omit to preserve the current URL
    - `--clear-api-url`: Remove the current URL; cannot be combined with a nonempty `--api-url`

  **Example:** `manifestd tx sku update-provider 01912345-6789-7abc-8def-0123456789ab manifest1abc... manifest1def... true --api-url https://api.provider.com --meta-hash [current-meta-hash-hex] --from authority`

  For payout repairs, preserve the provider's current `active` value. An
  inactive provider can be repaired with `false` during a partial deactivation
  cascade. Reactivation requires repeating `deactivate-provider` until
  a committed-height `skus-by-provider --active-only --limit 1` query is empty,
  reactivating the provider with `update-provider`, and then
  reactivating desired SKUs individually.

##### Update SKU (update-sku):

- Syntax: `manifestd tx sku update-sku [uuid] [provider-uuid] [name] [unit] [base-price] [active] [flags]`

  - Parameters:
    - `uuid`: SKU UUID
    - `provider-uuid`: Provider UUID
    - `name`: Human-readable SKU name
    - `unit`: Pricing unit integer (`1` = per hour, `2` = per day)
    - `base-price`: Positive price exactly divisible by the unit's seconds (e.g., `86400umfx` daily for `1umfx` per second)
    - `active`: `true` keeps the SKU active or reactivates it if its provider is active. `false` preserves an already-inactive SKU; use `deactivate-sku` to deactivate an active one.
  - Flags:
    - `--meta-hash`: Hex-encoded hash of off-chain metadata (optional)

  **Example:** `manifestd tx sku update-sku 01912345-6789-7abc-8def-0123456789ab 01912345-6789-7abc-8def-0123456789ab "Updated Name" 2 86400umfx true --meta-hash deadbeef --from authority`

##### Deactivate Provider (deactivate-provider):

- Syntax: `manifestd tx sku deactivate-provider [uuid] [flags]`

  - Parameters:
    - `uuid`: Provider UUID
  - Flags:
    - `--limit`: Maximum SKUs to deactivate per call (default 50, max 100). After committed success, query `skus-by-provider --active-only --limit 1` at that height and repeat while the result is nonempty; the CLI does not print the protobuf `has_more` response. See the [resumable cascade recipe](x/sku/docs/API.md#complete-a-provider-deactivation-cascade).

  **Example:** `manifestd tx sku deactivate-provider 01912345-6789-7abc-8def-0123456789ab --limit 50 --from authority`

##### Deactivate SKU (deactivate-sku):

- Syntax: `manifestd tx sku deactivate-sku [uuid] [flags]`

  - Parameters:
    - `uuid`: SKU UUID

  **Example:** `manifestd tx sku deactivate-sku 01912345-6789-7abc-8def-0123456789ab --from authority`

##### Update Params (update-params):

- Syntax: `manifestd tx sku update-params [flags]`

  - Flags:
    - `--allowed-list`: Comma-separated list of addresses allowed to manage SKUs

  **Example:** `manifestd tx sku update-params --allowed-list manifest1abc...,manifest1def... --from authority`

## Billing Module

The Billing module implements a credit-based leasing system for AI infrastructure resources. Tenants fund credit accounts, create leases for SKUs, and providers withdraw earned funds.

> For detailed documentation, see [x/billing/README.md](./x/billing/README.md) and [x/billing/docs/](./x/billing/docs/).

### Module Functionality

#### Credit Management:

- Fund tenant credit accounts with any supported denomination
- Deterministic credit address derivation from tenant address
- Multi-denomination support per credit account

#### Lease Lifecycle:

- Two-phase commit: tenant creates (PENDING), provider acknowledges (ACTIVE) only while the hard pending deadline, post-batch tenant active cap, and current payout eligibility checks still pass
- Price locking at lease creation for predictable billing
- Lazy settlement (on-touch) for scalability
- Auto-close when credit is exhausted

#### Provider Operations:

- Withdraw earned funds from individual leases or all leases at once
- Reject pending leases with optional reason
- Close leases and trigger final settlement

#### Commands

##### Fund Credit (fund-credit):

- Syntax: `manifestd tx billing fund-credit [tenant] [amount] [flags]`

  - Parameters:
    - `tenant`: Bech32 address of the tenant
    - `amount`: Amount to fund (e.g., `1000000upwr`)

  **Example:** `manifestd tx billing fund-credit manifest1abc... 1000000upwr --from mykey`

##### Create Lease (create-lease):

- Syntax: `manifestd tx billing create-lease [sku-uuid:quantity[:service_name]] ... [flags]`

  - Parameters:
    - `items`: Space-separated list of `sku-uuid:quantity` or `sku-uuid:quantity:service_name` triples
    - `--meta-hash`: Optional hex-encoded hash/reference to off-chain deployment data (max 64 bytes)

  **Example:** `manifestd tx billing create-lease 01912345-6789-7abc-8def-0123456789ab:2 --from tenant`
  **Example (stack):** `manifestd tx billing create-lease 01912345-6789-7abc-8def-0123456789ab:1:web 01912345-6789-7abc-8def-0123456789ab:1:db --from tenant`

  The provider must be active and its payout must be permitted by bank policy
  and distinct from this tenant's derived credit address. The same checks apply
  to `create-lease-for-tenant` before reserving credit or allocating a lease UUID.

##### Create Lease For Tenant (create-lease-for-tenant):

- Syntax: `manifestd tx billing create-lease-for-tenant [tenant] [sku-uuid:quantity[:service_name]] ... [flags]`

  - Parameters:
    - `tenant`: Bech32 address of the tenant
    - `items`: Space-separated list of `sku-uuid:quantity` or `sku-uuid:quantity:service_name` triples

  **Example:** `manifestd tx billing create-lease-for-tenant manifest1abc... 01912345-6789-7abc-8def-0123456789ab:2 --from authority`

##### Acknowledge Lease (acknowledge-lease):

- Syntax: `manifestd tx billing acknowledge-lease [lease-uuid...] [flags]`

  - Revalidates the current `pending_timeout` as a hard deadline (exact cutoff allowed) and each tenant's `max_leases_per_tenant` against the full batch. Any failure leaves the whole batch unchanged.
  - Rechecks the current provider payout against bank policy and each tenant's
    derived credit address before activating any lease. Pending leases can
    still be cancelled or rejected to release reservations while a payout
    requires repair.

  **Example:** `manifestd tx billing acknowledge-lease 01912345-6789-7abc-8def-0123456789ab --from provider`

##### Reject Lease (reject-lease):

- Syntax: `manifestd tx billing reject-lease [lease-uuid...] [flags]`

  - Parameters:
    - `--reason`: Optional rejection reason (max 256 UTF-8 bytes)

  **Example:** `manifestd tx billing reject-lease 01912345-6789-7abc-8def-0123456789ab --reason "insufficient resources" --from provider`

##### Cancel Lease (cancel-lease):

- Syntax: `manifestd tx billing cancel-lease [lease-uuid...] [flags]`

  **Example:** `manifestd tx billing cancel-lease 01912345-6789-7abc-8def-0123456789ab --from tenant`

##### Close Lease (close-lease):

- Syntax: `manifestd tx billing close-lease [lease-uuid...] [flags]`

  - Parameters:
    - `--reason`: Optional closure reason (max 256 UTF-8 bytes)

  **Example:** `manifestd tx billing close-lease 01912345-6789-7abc-8def-0123456789ab --from tenant`

##### Withdraw (withdraw):

- Syntax: `manifestd tx billing withdraw [lease-uuid...] [flags]`
- Or: `manifestd tx billing withdraw --provider [provider-uuid] [flags]`

  `--limit` and `--key` are only accepted with `--provider`; the CLI rejects
  either flag alongside specific lease UUIDs.

  **Example:** `manifestd tx billing withdraw 01912345-6789-7abc-8def-0123456789ab --from provider`

##### Set Item Custom Domain (set-item-custom-domain):

Set or clear the custom domain on a specific lease item. Authorised senders are
the lease tenant, the module authority, or any address in `params.allowed_list`.
For a 1-item legacy lease (no `service_name` set), pass `""` for `service-name`.
Multi-item legacy leases cannot use custom_domain — recreate the lease in
service-name mode.

- Syntax: `manifestd tx billing set-item-custom-domain [lease-uuid] [service-name] [domain] [flags]`

  - Parameters:
    - `lease-uuid`: UUID of the lease
    - `service-name`: Service name on the targeted item (`""` for a 1-item legacy lease)
    - `domain`: FQDN to set, or `""` to clear

  **Example (1-item lease):** `manifestd tx billing set-item-custom-domain 01912345-6789-7abc-8def-0123456789ab "" app.example.com --from tenant`
  **Example (multi-item):** `manifestd tx billing set-item-custom-domain 01912345-6789-7abc-8def-0123456789ab web app.example.com --from tenant`
  **Example (clear):** `manifestd tx billing set-item-custom-domain 01912345-6789-7abc-8def-0123456789ab web "" --from tenant`

##### Update Params (update-params):

- Syntax: `manifestd tx billing update-params [max-leases-per-tenant] [max-items-per-lease] [min-lease-duration] [max-pending-leases-per-tenant] [pending-timeout] [flags]`

  - Parameters:
    - `max-leases-per-tenant`: Maximum active leases per tenant
    - `max-items-per-lease`: Maximum SKU items per lease
    - `min-lease-duration`: Seconds of billing credit to reserve when creating a lease; does not enforce a minimum elapsed runtime
    - `max-pending-leases-per-tenant`: Maximum pending leases per tenant
    - `pending-timeout`: Pending lease timeout in seconds (60-86400)
  - Flags:
    - `--allowed-list`: Comma-separated list of addresses allowed to create leases for tenants. When omitted, the value is queried at construction time and embedded in the transaction. Pass an empty value (`--allowed-list=""`) to explicitly clear it.
    - `--reserved-domain-suffixes`: Comma-separated list of reserved domain suffixes (each must begin with `.`). Used to gate `set-item-custom-domain`. Same construction-time snapshot semantics as `--allowed-list`.

  Omitted lists are snapshots, not preservation at execution. Use `--height`
  to pin the query (0 means latest); the CLI prints resolved lists to stderr.
  Governance execution replaces every parameter. Recheck all fields and
  rebuild a stale proposal if another parameter change lands while voting.

  **Example (numeric only, omitted lists snapshotted):** `manifestd tx billing update-params 100 20 3600 10 1800 --from authority`
  **Example (set reserved suffixes):** `manifestd tx billing update-params 100 20 3600 10 1800 --reserved-domain-suffixes ".manifest.network,.lifted.app" --from authority`
